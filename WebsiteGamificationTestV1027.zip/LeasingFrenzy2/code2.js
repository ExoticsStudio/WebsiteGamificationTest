gdjs.GameplayCode = {};
gdjs.GameplayCode.GDCar_95Dealership_951Objects2_1final = [];

gdjs.GameplayCode.GDCar_95Dealership_952Objects2_1final = [];

gdjs.GameplayCode.GDCar_95Dealership_953Objects2_1final = [];

gdjs.GameplayCode.GDCollider_95FinishObjects2_1final = [];

gdjs.GameplayCode.repeatCount3 = 0;

gdjs.GameplayCode.repeatCount5 = 0;

gdjs.GameplayCode.repeatCount6 = 0;

gdjs.GameplayCode.repeatIndex3 = 0;

gdjs.GameplayCode.repeatIndex5 = 0;

gdjs.GameplayCode.repeatIndex6 = 0;

gdjs.GameplayCode.GDUpgrade_95UIObjects1= [];
gdjs.GameplayCode.GDUpgrade_95UIObjects2= [];
gdjs.GameplayCode.GDUpgrade_95UIObjects3= [];
gdjs.GameplayCode.GDUpgrade_95UIObjects4= [];
gdjs.GameplayCode.GDUpgrade_95UIObjects5= [];
gdjs.GameplayCode.GDUpgrade_95UIObjects6= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects1= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects2= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5= [];
gdjs.GameplayCode.GDUpgrade_95UI_952Objects6= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects1= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5= [];
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects6= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects1= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5= [];
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects6= [];
gdjs.GameplayCode.GDButton_95CloseObjects1= [];
gdjs.GameplayCode.GDButton_95CloseObjects2= [];
gdjs.GameplayCode.GDButton_95CloseObjects3= [];
gdjs.GameplayCode.GDButton_95CloseObjects4= [];
gdjs.GameplayCode.GDButton_95CloseObjects5= [];
gdjs.GameplayCode.GDButton_95CloseObjects6= [];
gdjs.GameplayCode.GDButton_95Close_952Objects1= [];
gdjs.GameplayCode.GDButton_95Close_952Objects2= [];
gdjs.GameplayCode.GDButton_95Close_952Objects3= [];
gdjs.GameplayCode.GDButton_95Close_952Objects4= [];
gdjs.GameplayCode.GDButton_95Close_952Objects5= [];
gdjs.GameplayCode.GDButton_95Close_952Objects6= [];
gdjs.GameplayCode.GDButton_95AddObjects1= [];
gdjs.GameplayCode.GDButton_95AddObjects2= [];
gdjs.GameplayCode.GDButton_95AddObjects3= [];
gdjs.GameplayCode.GDButton_95AddObjects4= [];
gdjs.GameplayCode.GDButton_95AddObjects5= [];
gdjs.GameplayCode.GDButton_95AddObjects6= [];
gdjs.GameplayCode.GDButton_95Add_952Objects1= [];
gdjs.GameplayCode.GDButton_95Add_952Objects2= [];
gdjs.GameplayCode.GDButton_95Add_952Objects3= [];
gdjs.GameplayCode.GDButton_95Add_952Objects4= [];
gdjs.GameplayCode.GDButton_95Add_952Objects5= [];
gdjs.GameplayCode.GDButton_95Add_952Objects6= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects1= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects2= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects3= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects4= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects5= [];
gdjs.GameplayCode.GDUpgrade_95BarObjects6= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects1= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5= [];
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects6= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects1= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects2= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects3= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects4= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects5= [];
gdjs.GameplayCode.GDMaxLevelReachedObjects6= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects1= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects2= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects3= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects4= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects5= [];
gdjs.GameplayCode.GDMaxLevelReached_952Objects6= [];
gdjs.GameplayCode.GDMIFObjects1= [];
gdjs.GameplayCode.GDMIFObjects2= [];
gdjs.GameplayCode.GDMIFObjects3= [];
gdjs.GameplayCode.GDMIFObjects4= [];
gdjs.GameplayCode.GDMIFObjects5= [];
gdjs.GameplayCode.GDMIFObjects6= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects1= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects2= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5= [];
gdjs.GameplayCode.GDMIF_95ThumbnailObjects6= [];
gdjs.GameplayCode.GDDealershipObjects1= [];
gdjs.GameplayCode.GDDealershipObjects2= [];
gdjs.GameplayCode.GDDealershipObjects3= [];
gdjs.GameplayCode.GDDealershipObjects4= [];
gdjs.GameplayCode.GDDealershipObjects5= [];
gdjs.GameplayCode.GDDealershipObjects6= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects1= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects2= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5= [];
gdjs.GameplayCode.GDDealership_95ThumbnailObjects6= [];
gdjs.GameplayCode.GDCollider_95FinishObjects1= [];
gdjs.GameplayCode.GDCollider_95FinishObjects2= [];
gdjs.GameplayCode.GDCollider_95FinishObjects3= [];
gdjs.GameplayCode.GDCollider_95FinishObjects4= [];
gdjs.GameplayCode.GDCollider_95FinishObjects5= [];
gdjs.GameplayCode.GDCollider_95FinishObjects6= [];
gdjs.GameplayCode.GDCollider_95House_951Objects1= [];
gdjs.GameplayCode.GDCollider_95House_951Objects2= [];
gdjs.GameplayCode.GDCollider_95House_951Objects3= [];
gdjs.GameplayCode.GDCollider_95House_951Objects4= [];
gdjs.GameplayCode.GDCollider_95House_951Objects5= [];
gdjs.GameplayCode.GDCollider_95House_951Objects6= [];
gdjs.GameplayCode.GDCollider_95House_952Objects1= [];
gdjs.GameplayCode.GDCollider_95House_952Objects2= [];
gdjs.GameplayCode.GDCollider_95House_952Objects3= [];
gdjs.GameplayCode.GDCollider_95House_952Objects4= [];
gdjs.GameplayCode.GDCollider_95House_952Objects5= [];
gdjs.GameplayCode.GDCollider_95House_952Objects6= [];
gdjs.GameplayCode.GDCollider_95House_953Objects1= [];
gdjs.GameplayCode.GDCollider_95House_953Objects2= [];
gdjs.GameplayCode.GDCollider_95House_953Objects3= [];
gdjs.GameplayCode.GDCollider_95House_953Objects4= [];
gdjs.GameplayCode.GDCollider_95House_953Objects5= [];
gdjs.GameplayCode.GDCollider_95House_953Objects6= [];
gdjs.GameplayCode.GDCollider_95House_954Objects1= [];
gdjs.GameplayCode.GDCollider_95House_954Objects2= [];
gdjs.GameplayCode.GDCollider_95House_954Objects3= [];
gdjs.GameplayCode.GDCollider_95House_954Objects4= [];
gdjs.GameplayCode.GDCollider_95House_954Objects5= [];
gdjs.GameplayCode.GDCollider_95House_954Objects6= [];
gdjs.GameplayCode.GDCollider_95House_955Objects1= [];
gdjs.GameplayCode.GDCollider_95House_955Objects2= [];
gdjs.GameplayCode.GDCollider_95House_955Objects3= [];
gdjs.GameplayCode.GDCollider_95House_955Objects4= [];
gdjs.GameplayCode.GDCollider_95House_955Objects5= [];
gdjs.GameplayCode.GDCollider_95House_955Objects6= [];
gdjs.GameplayCode.GDCollider_95House_956Objects1= [];
gdjs.GameplayCode.GDCollider_95House_956Objects2= [];
gdjs.GameplayCode.GDCollider_95House_956Objects3= [];
gdjs.GameplayCode.GDCollider_95House_956Objects4= [];
gdjs.GameplayCode.GDCollider_95House_956Objects5= [];
gdjs.GameplayCode.GDCollider_95House_956Objects6= [];
gdjs.GameplayCode.GDCollider_95MIFObjects1= [];
gdjs.GameplayCode.GDCollider_95MIFObjects2= [];
gdjs.GameplayCode.GDCollider_95MIFObjects3= [];
gdjs.GameplayCode.GDCollider_95MIFObjects4= [];
gdjs.GameplayCode.GDCollider_95MIFObjects5= [];
gdjs.GameplayCode.GDCollider_95MIFObjects6= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects1= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects2= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects3= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects4= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects5= [];
gdjs.GameplayCode.GDCollider_95DealershipObjects6= [];
gdjs.GameplayCode.GDCollider_95UpObjects1= [];
gdjs.GameplayCode.GDCollider_95UpObjects2= [];
gdjs.GameplayCode.GDCollider_95UpObjects3= [];
gdjs.GameplayCode.GDCollider_95UpObjects4= [];
gdjs.GameplayCode.GDCollider_95UpObjects5= [];
gdjs.GameplayCode.GDCollider_95UpObjects6= [];
gdjs.GameplayCode.GDCollider_95DownObjects1= [];
gdjs.GameplayCode.GDCollider_95DownObjects2= [];
gdjs.GameplayCode.GDCollider_95DownObjects3= [];
gdjs.GameplayCode.GDCollider_95DownObjects4= [];
gdjs.GameplayCode.GDCollider_95DownObjects5= [];
gdjs.GameplayCode.GDCollider_95DownObjects6= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects1= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects3= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects4= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects5= [];
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects6= [];
gdjs.GameplayCode.GDCollider_95LeftObjects1= [];
gdjs.GameplayCode.GDCollider_95LeftObjects2= [];
gdjs.GameplayCode.GDCollider_95LeftObjects3= [];
gdjs.GameplayCode.GDCollider_95LeftObjects4= [];
gdjs.GameplayCode.GDCollider_95LeftObjects5= [];
gdjs.GameplayCode.GDCollider_95LeftObjects6= [];
gdjs.GameplayCode.GDCollider_95RightObjects1= [];
gdjs.GameplayCode.GDCollider_95RightObjects2= [];
gdjs.GameplayCode.GDCollider_95RightObjects3= [];
gdjs.GameplayCode.GDCollider_95RightObjects4= [];
gdjs.GameplayCode.GDCollider_95RightObjects5= [];
gdjs.GameplayCode.GDCollider_95RightObjects6= [];
gdjs.GameplayCode.GDCar_95HouseObjects1= [];
gdjs.GameplayCode.GDCar_95HouseObjects2= [];
gdjs.GameplayCode.GDCar_95HouseObjects3= [];
gdjs.GameplayCode.GDCar_95HouseObjects4= [];
gdjs.GameplayCode.GDCar_95HouseObjects5= [];
gdjs.GameplayCode.GDCar_95HouseObjects6= [];
gdjs.GameplayCode.GDCar_95MIFObjects1= [];
gdjs.GameplayCode.GDCar_95MIFObjects2= [];
gdjs.GameplayCode.GDCar_95MIFObjects3= [];
gdjs.GameplayCode.GDCar_95MIFObjects4= [];
gdjs.GameplayCode.GDCar_95MIFObjects5= [];
gdjs.GameplayCode.GDCar_95MIFObjects6= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects1= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects2= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects3= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects4= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects5= [];
gdjs.GameplayCode.GDCar_95Dealership_951Objects6= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects1= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects2= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects3= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects4= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects5= [];
gdjs.GameplayCode.GDCar_95Dealership_952Objects6= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects1= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects2= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects3= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects4= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects5= [];
gdjs.GameplayCode.GDCar_95Dealership_953Objects6= [];
gdjs.GameplayCode.GDHouse_951Objects1= [];
gdjs.GameplayCode.GDHouse_951Objects2= [];
gdjs.GameplayCode.GDHouse_951Objects3= [];
gdjs.GameplayCode.GDHouse_951Objects4= [];
gdjs.GameplayCode.GDHouse_951Objects5= [];
gdjs.GameplayCode.GDHouse_951Objects6= [];
gdjs.GameplayCode.GDHouse_952Objects1= [];
gdjs.GameplayCode.GDHouse_952Objects2= [];
gdjs.GameplayCode.GDHouse_952Objects3= [];
gdjs.GameplayCode.GDHouse_952Objects4= [];
gdjs.GameplayCode.GDHouse_952Objects5= [];
gdjs.GameplayCode.GDHouse_952Objects6= [];
gdjs.GameplayCode.GDHouse_953Objects1= [];
gdjs.GameplayCode.GDHouse_953Objects2= [];
gdjs.GameplayCode.GDHouse_953Objects3= [];
gdjs.GameplayCode.GDHouse_953Objects4= [];
gdjs.GameplayCode.GDHouse_953Objects5= [];
gdjs.GameplayCode.GDHouse_953Objects6= [];
gdjs.GameplayCode.GDHouse_954Objects1= [];
gdjs.GameplayCode.GDHouse_954Objects2= [];
gdjs.GameplayCode.GDHouse_954Objects3= [];
gdjs.GameplayCode.GDHouse_954Objects4= [];
gdjs.GameplayCode.GDHouse_954Objects5= [];
gdjs.GameplayCode.GDHouse_954Objects6= [];
gdjs.GameplayCode.GDHouse_955Objects1= [];
gdjs.GameplayCode.GDHouse_955Objects2= [];
gdjs.GameplayCode.GDHouse_955Objects3= [];
gdjs.GameplayCode.GDHouse_955Objects4= [];
gdjs.GameplayCode.GDHouse_955Objects5= [];
gdjs.GameplayCode.GDHouse_955Objects6= [];
gdjs.GameplayCode.GDHouse_956Objects1= [];
gdjs.GameplayCode.GDHouse_956Objects2= [];
gdjs.GameplayCode.GDHouse_956Objects3= [];
gdjs.GameplayCode.GDHouse_956Objects4= [];
gdjs.GameplayCode.GDHouse_956Objects5= [];
gdjs.GameplayCode.GDHouse_956Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_951Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_952Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_953Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_954Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_955Objects6= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects1= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects2= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects3= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects4= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects5= [];
gdjs.GameplayCode.GDCountdown_95House_956Objects6= [];
gdjs.GameplayCode.GDMoneyObjects1= [];
gdjs.GameplayCode.GDMoneyObjects2= [];
gdjs.GameplayCode.GDMoneyObjects3= [];
gdjs.GameplayCode.GDMoneyObjects4= [];
gdjs.GameplayCode.GDMoneyObjects5= [];
gdjs.GameplayCode.GDMoneyObjects6= [];
gdjs.GameplayCode.GDInfo_95MIFObjects1= [];
gdjs.GameplayCode.GDInfo_95MIFObjects2= [];
gdjs.GameplayCode.GDInfo_95MIFObjects3= [];
gdjs.GameplayCode.GDInfo_95MIFObjects4= [];
gdjs.GameplayCode.GDInfo_95MIFObjects5= [];
gdjs.GameplayCode.GDInfo_95MIFObjects6= [];
gdjs.GameplayCode.GDLevel_95MIFObjects1= [];
gdjs.GameplayCode.GDLevel_95MIFObjects2= [];
gdjs.GameplayCode.GDLevel_95MIFObjects3= [];
gdjs.GameplayCode.GDLevel_95MIFObjects4= [];
gdjs.GameplayCode.GDLevel_95MIFObjects5= [];
gdjs.GameplayCode.GDLevel_95MIFObjects6= [];
gdjs.GameplayCode.GDPrice_95MIFObjects1= [];
gdjs.GameplayCode.GDPrice_95MIFObjects2= [];
gdjs.GameplayCode.GDPrice_95MIFObjects3= [];
gdjs.GameplayCode.GDPrice_95MIFObjects4= [];
gdjs.GameplayCode.GDPrice_95MIFObjects5= [];
gdjs.GameplayCode.GDPrice_95MIFObjects6= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects1= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects2= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects3= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects4= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects5= [];
gdjs.GameplayCode.GDInfo_95DealershipObjects6= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects1= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects2= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects3= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects4= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects5= [];
gdjs.GameplayCode.GDLevel_95DealershipObjects6= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects1= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects2= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects3= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects4= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects5= [];
gdjs.GameplayCode.GDPrice_95DealershipObjects6= [];
gdjs.GameplayCode.GDCar_95Type_951Objects1= [];
gdjs.GameplayCode.GDCar_95Type_951Objects2= [];
gdjs.GameplayCode.GDCar_95Type_951Objects3= [];
gdjs.GameplayCode.GDCar_95Type_951Objects4= [];
gdjs.GameplayCode.GDCar_95Type_951Objects5= [];
gdjs.GameplayCode.GDCar_95Type_951Objects6= [];
gdjs.GameplayCode.GDCar_95Type_952Objects1= [];
gdjs.GameplayCode.GDCar_95Type_952Objects2= [];
gdjs.GameplayCode.GDCar_95Type_952Objects3= [];
gdjs.GameplayCode.GDCar_95Type_952Objects4= [];
gdjs.GameplayCode.GDCar_95Type_952Objects5= [];
gdjs.GameplayCode.GDCar_95Type_952Objects6= [];
gdjs.GameplayCode.GDCar_95Type_953Objects1= [];
gdjs.GameplayCode.GDCar_95Type_953Objects2= [];
gdjs.GameplayCode.GDCar_95Type_953Objects3= [];
gdjs.GameplayCode.GDCar_95Type_953Objects4= [];
gdjs.GameplayCode.GDCar_95Type_953Objects5= [];
gdjs.GameplayCode.GDCar_95Type_953Objects6= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects1= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects4= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects5= [];
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects6= [];
gdjs.GameplayCode.GDRoad_951Objects1= [];
gdjs.GameplayCode.GDRoad_951Objects2= [];
gdjs.GameplayCode.GDRoad_951Objects3= [];
gdjs.GameplayCode.GDRoad_951Objects4= [];
gdjs.GameplayCode.GDRoad_951Objects5= [];
gdjs.GameplayCode.GDRoad_951Objects6= [];
gdjs.GameplayCode.GDRoad_9511Objects1= [];
gdjs.GameplayCode.GDRoad_9511Objects2= [];
gdjs.GameplayCode.GDRoad_9511Objects3= [];
gdjs.GameplayCode.GDRoad_9511Objects4= [];
gdjs.GameplayCode.GDRoad_9511Objects5= [];
gdjs.GameplayCode.GDRoad_9511Objects6= [];
gdjs.GameplayCode.GDRoad_952Objects1= [];
gdjs.GameplayCode.GDRoad_952Objects2= [];
gdjs.GameplayCode.GDRoad_952Objects3= [];
gdjs.GameplayCode.GDRoad_952Objects4= [];
gdjs.GameplayCode.GDRoad_952Objects5= [];
gdjs.GameplayCode.GDRoad_952Objects6= [];
gdjs.GameplayCode.GDRoad_953Objects1= [];
gdjs.GameplayCode.GDRoad_953Objects2= [];
gdjs.GameplayCode.GDRoad_953Objects3= [];
gdjs.GameplayCode.GDRoad_953Objects4= [];
gdjs.GameplayCode.GDRoad_953Objects5= [];
gdjs.GameplayCode.GDRoad_953Objects6= [];
gdjs.GameplayCode.GDRoad_9533Objects1= [];
gdjs.GameplayCode.GDRoad_9533Objects2= [];
gdjs.GameplayCode.GDRoad_9533Objects3= [];
gdjs.GameplayCode.GDRoad_9533Objects4= [];
gdjs.GameplayCode.GDRoad_9533Objects5= [];
gdjs.GameplayCode.GDRoad_9533Objects6= [];
gdjs.GameplayCode.GDRoad_954Objects1= [];
gdjs.GameplayCode.GDRoad_954Objects2= [];
gdjs.GameplayCode.GDRoad_954Objects3= [];
gdjs.GameplayCode.GDRoad_954Objects4= [];
gdjs.GameplayCode.GDRoad_954Objects5= [];
gdjs.GameplayCode.GDRoad_954Objects6= [];
gdjs.GameplayCode.GDApartment_95DecoObjects1= [];
gdjs.GameplayCode.GDApartment_95DecoObjects2= [];
gdjs.GameplayCode.GDApartment_95DecoObjects3= [];
gdjs.GameplayCode.GDApartment_95DecoObjects4= [];
gdjs.GameplayCode.GDApartment_95DecoObjects5= [];
gdjs.GameplayCode.GDApartment_95DecoObjects6= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects1= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects2= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects3= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects4= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects5= [];
gdjs.GameplayCode.GDApartment_95Deco_952Objects6= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects1= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects2= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects3= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects4= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects5= [];
gdjs.GameplayCode.GDApartment_95Deco_953Objects6= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects1= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects2= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects3= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects4= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects5= [];
gdjs.GameplayCode.GDApartment_95Deco_954Objects6= [];
gdjs.GameplayCode.GDRiverObjects1= [];
gdjs.GameplayCode.GDRiverObjects2= [];
gdjs.GameplayCode.GDRiverObjects3= [];
gdjs.GameplayCode.GDRiverObjects4= [];
gdjs.GameplayCode.GDRiverObjects5= [];
gdjs.GameplayCode.GDRiverObjects6= [];
gdjs.GameplayCode.GDBGObjects1= [];
gdjs.GameplayCode.GDBGObjects2= [];
gdjs.GameplayCode.GDBGObjects3= [];
gdjs.GameplayCode.GDBGObjects4= [];
gdjs.GameplayCode.GDBGObjects5= [];
gdjs.GameplayCode.GDBGObjects6= [];
gdjs.GameplayCode.GDTennis_95CourtObjects1= [];
gdjs.GameplayCode.GDTennis_95CourtObjects2= [];
gdjs.GameplayCode.GDTennis_95CourtObjects3= [];
gdjs.GameplayCode.GDTennis_95CourtObjects4= [];
gdjs.GameplayCode.GDTennis_95CourtObjects5= [];
gdjs.GameplayCode.GDTennis_95CourtObjects6= [];
gdjs.GameplayCode.GDUI_95BarObjects1= [];
gdjs.GameplayCode.GDUI_95BarObjects2= [];
gdjs.GameplayCode.GDUI_95BarObjects3= [];
gdjs.GameplayCode.GDUI_95BarObjects4= [];
gdjs.GameplayCode.GDUI_95BarObjects5= [];
gdjs.GameplayCode.GDUI_95BarObjects6= [];
gdjs.GameplayCode.GDBottom_95BarObjects1= [];
gdjs.GameplayCode.GDBottom_95BarObjects2= [];
gdjs.GameplayCode.GDBottom_95BarObjects3= [];
gdjs.GameplayCode.GDBottom_95BarObjects4= [];
gdjs.GameplayCode.GDBottom_95BarObjects5= [];
gdjs.GameplayCode.GDBottom_95BarObjects6= [];
gdjs.GameplayCode.GDReady6Objects1= [];
gdjs.GameplayCode.GDReady6Objects2= [];
gdjs.GameplayCode.GDReady6Objects3= [];
gdjs.GameplayCode.GDReady6Objects4= [];
gdjs.GameplayCode.GDReady6Objects5= [];
gdjs.GameplayCode.GDReady6Objects6= [];
gdjs.GameplayCode.GDReady5Objects1= [];
gdjs.GameplayCode.GDReady5Objects2= [];
gdjs.GameplayCode.GDReady5Objects3= [];
gdjs.GameplayCode.GDReady5Objects4= [];
gdjs.GameplayCode.GDReady5Objects5= [];
gdjs.GameplayCode.GDReady5Objects6= [];
gdjs.GameplayCode.GDReady4Objects1= [];
gdjs.GameplayCode.GDReady4Objects2= [];
gdjs.GameplayCode.GDReady4Objects3= [];
gdjs.GameplayCode.GDReady4Objects4= [];
gdjs.GameplayCode.GDReady4Objects5= [];
gdjs.GameplayCode.GDReady4Objects6= [];
gdjs.GameplayCode.GDReady3Objects1= [];
gdjs.GameplayCode.GDReady3Objects2= [];
gdjs.GameplayCode.GDReady3Objects3= [];
gdjs.GameplayCode.GDReady3Objects4= [];
gdjs.GameplayCode.GDReady3Objects5= [];
gdjs.GameplayCode.GDReady3Objects6= [];
gdjs.GameplayCode.GDReady2Objects1= [];
gdjs.GameplayCode.GDReady2Objects2= [];
gdjs.GameplayCode.GDReady2Objects3= [];
gdjs.GameplayCode.GDReady2Objects4= [];
gdjs.GameplayCode.GDReady2Objects5= [];
gdjs.GameplayCode.GDReady2Objects6= [];
gdjs.GameplayCode.GDReady1Objects1= [];
gdjs.GameplayCode.GDReady1Objects2= [];
gdjs.GameplayCode.GDReady1Objects3= [];
gdjs.GameplayCode.GDReady1Objects4= [];
gdjs.GameplayCode.GDReady1Objects5= [];
gdjs.GameplayCode.GDReady1Objects6= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects1= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects2= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects3= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects4= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects5= [];
gdjs.GameplayCode.GDHouseNum_95TopObjects6= [];
gdjs.GameplayCode.GDHouseNumObjects1= [];
gdjs.GameplayCode.GDHouseNumObjects2= [];
gdjs.GameplayCode.GDHouseNumObjects3= [];
gdjs.GameplayCode.GDHouseNumObjects4= [];
gdjs.GameplayCode.GDHouseNumObjects5= [];
gdjs.GameplayCode.GDHouseNumObjects6= [];
gdjs.GameplayCode.GDOneObjects1= [];
gdjs.GameplayCode.GDOneObjects2= [];
gdjs.GameplayCode.GDOneObjects3= [];
gdjs.GameplayCode.GDOneObjects4= [];
gdjs.GameplayCode.GDOneObjects5= [];
gdjs.GameplayCode.GDOneObjects6= [];
gdjs.GameplayCode.GDVolumeObjects1= [];
gdjs.GameplayCode.GDVolumeObjects2= [];
gdjs.GameplayCode.GDVolumeObjects3= [];
gdjs.GameplayCode.GDVolumeObjects4= [];
gdjs.GameplayCode.GDVolumeObjects5= [];
gdjs.GameplayCode.GDVolumeObjects6= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects1= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects2= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects3= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects4= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects5= [];
gdjs.GameplayCode.GDTutorial_95ButtonObjects6= [];
gdjs.GameplayCode.GDTutorial_95UIObjects1= [];
gdjs.GameplayCode.GDTutorial_95UIObjects2= [];
gdjs.GameplayCode.GDTutorial_95UIObjects3= [];
gdjs.GameplayCode.GDTutorial_95UIObjects4= [];
gdjs.GameplayCode.GDTutorial_95UIObjects5= [];
gdjs.GameplayCode.GDTutorial_95UIObjects6= [];
gdjs.GameplayCode.GDArrow_95RightObjects1= [];
gdjs.GameplayCode.GDArrow_95RightObjects2= [];
gdjs.GameplayCode.GDArrow_95RightObjects3= [];
gdjs.GameplayCode.GDArrow_95RightObjects4= [];
gdjs.GameplayCode.GDArrow_95RightObjects5= [];
gdjs.GameplayCode.GDArrow_95RightObjects6= [];
gdjs.GameplayCode.GDArrow_95LeftObjects1= [];
gdjs.GameplayCode.GDArrow_95LeftObjects2= [];
gdjs.GameplayCode.GDArrow_95LeftObjects3= [];
gdjs.GameplayCode.GDArrow_95LeftObjects4= [];
gdjs.GameplayCode.GDArrow_95LeftObjects5= [];
gdjs.GameplayCode.GDArrow_95LeftObjects6= [];

gdjs.GameplayCode.conditionTrue_0 = {val:false};
gdjs.GameplayCode.condition0IsTrue_0 = {val:false};
gdjs.GameplayCode.condition1IsTrue_0 = {val:false};
gdjs.GameplayCode.condition2IsTrue_0 = {val:false};
gdjs.GameplayCode.condition3IsTrue_0 = {val:false};
gdjs.GameplayCode.condition4IsTrue_0 = {val:false};
gdjs.GameplayCode.condition5IsTrue_0 = {val:false};
gdjs.GameplayCode.condition6IsTrue_0 = {val:false};
gdjs.GameplayCode.condition7IsTrue_0 = {val:false};
gdjs.GameplayCode.condition8IsTrue_0 = {val:false};
gdjs.GameplayCode.conditionTrue_1 = {val:false};
gdjs.GameplayCode.condition0IsTrue_1 = {val:false};
gdjs.GameplayCode.condition1IsTrue_1 = {val:false};
gdjs.GameplayCode.condition2IsTrue_1 = {val:false};
gdjs.GameplayCode.condition3IsTrue_1 = {val:false};
gdjs.GameplayCode.condition4IsTrue_1 = {val:false};
gdjs.GameplayCode.condition5IsTrue_1 = {val:false};
gdjs.GameplayCode.condition6IsTrue_1 = {val:false};
gdjs.GameplayCode.condition7IsTrue_1 = {val:false};
gdjs.GameplayCode.condition8IsTrue_1 = {val:false};


gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects2Objects = Hashtable.newFrom({"House_1": gdjs.GameplayCode.GDHouse_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects2Objects = Hashtable.newFrom({"House_2": gdjs.GameplayCode.GDHouse_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects2Objects = Hashtable.newFrom({"House_3": gdjs.GameplayCode.GDHouse_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects2Objects = Hashtable.newFrom({"House_4": gdjs.GameplayCode.GDHouse_954Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects2Objects = Hashtable.newFrom({"House_5": gdjs.GameplayCode.GDHouse_955Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects1Objects = Hashtable.newFrom({"House_6": gdjs.GameplayCode.GDHouse_956Objects1});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects1Objects = Hashtable.newFrom({"One": gdjs.GameplayCode.GDOneObjects1});
gdjs.GameplayCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Dealership"), gdjs.GameplayCode.GDCollider_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down"), gdjs.GameplayCode.GDCollider_95DownObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down_Dealer"), gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_1"), gdjs.GameplayCode.GDCollider_95House_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_2"), gdjs.GameplayCode.GDCollider_95House_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_3"), gdjs.GameplayCode.GDCollider_95House_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_4"), gdjs.GameplayCode.GDCollider_95House_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_5"), gdjs.GameplayCode.GDCollider_95House_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_6"), gdjs.GameplayCode.GDCollider_95House_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Left"), gdjs.GameplayCode.GDCollider_95LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_MIF"), gdjs.GameplayCode.GDCollider_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Right"), gdjs.GameplayCode.GDCollider_95RightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Up"), gdjs.GameplayCode.GDCollider_95UpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("HouseNum_Top"), gdjs.GameplayCode.GDHouseNum_95TopObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ready1"), gdjs.GameplayCode.GDReady1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ready2"), gdjs.GameplayCode.GDReady2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ready3"), gdjs.GameplayCode.GDReady3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ready4"), gdjs.GameplayCode.GDReady4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ready5"), gdjs.GameplayCode.GDReady5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ready6"), gdjs.GameplayCode.GDReady6Objects2);
{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95FinishObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95FinishObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_951Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_952Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_953Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_954Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_955Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_955Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95House_956Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95House_956Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95MIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95MIFObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95DealershipObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95UpObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95UpObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95DownObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95DownObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95LeftObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95LeftObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCollider_95RightObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCollider_95RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouseNum_95TopObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouseNum_95TopObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady1Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady5Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady5Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady6Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady6Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects2[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("River"), gdjs.GameplayCode.GDRiverObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDRiverObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDRiverObjects2[i].setYOffset(gdjs.GameplayCode.GDRiverObjects2[i].getYOffset() - (0.2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects2[i].setBBText("1");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects2[i].setBBText("2");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects2[i].setBBText("3");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects2[i].setBBText("4");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects2[i].setBBText("5");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects1);
gdjs.copyArray(runtimeScene.getObjects("One"), gdjs.GameplayCode.GDOneObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDOneObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDOneObjects1 */
{for(var i = 0, len = gdjs.GameplayCode.GDOneObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDOneObjects1[i].setBBText("6");
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects2Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects2Objects = Hashtable.newFrom({"Collider_MIF": gdjs.GameplayCode.GDCollider_95MIFObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects2Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects2Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects1Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects1});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects1Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects1});
gdjs.GameplayCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_MIF"), gdjs.GameplayCode.GDCollider_95MIFObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11388916);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13334452);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11391996);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) * 2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11393724);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) * 3);
}}

}


};gdjs.GameplayCode.eventsList2 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BG"), gdjs.GameplayCode.GDBGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Money"), gdjs.GameplayCode.GDMoneyObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDMoneyObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMoneyObjects2[i].setPosition(((( gdjs.GameplayCode.GDBGObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDBGObjects2[0].getWidth()) / 2) - ((gdjs.GameplayCode.GDMoneyObjects2[i].getWidth()) / 2),20);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Money"), gdjs.GameplayCode.GDMoneyObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDMoneyObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMoneyObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))) + " JT");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 1000;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Money"), gdjs.GameplayCode.GDMoneyObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDMoneyObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMoneyObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) / 1000) + " M");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 1000000;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Money"), gdjs.GameplayCode.GDMoneyObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDMoneyObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMoneyObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) / 1000000) + " T");
}
}}

}


{


gdjs.GameplayCode.eventsList1(runtimeScene);
}


};gdjs.GameplayCode.eventsList3 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList4 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Money", "currentMoney");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Money");
}{gdjs.evtTools.storage.readNumberFromJSONFile("Money", "currentMoney", runtimeScene, runtimeScene.getVariables().get("MoneyRealTime"));
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoneyRealTime")));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Money", "currentMoney"));
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Money");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(5000000);
}}

}


{


gdjs.GameplayCode.repeatCount3 = 1;
for(gdjs.GameplayCode.repeatIndex3 = 0;gdjs.GameplayCode.repeatIndex3 < gdjs.GameplayCode.repeatCount3;++gdjs.GameplayCode.repeatIndex3) {

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Money") > 1;
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Money");
}{gdjs.evtTools.storage.writeNumberInJSONFile("Money", "currentMoney", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}}
}

}


{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Dealership_Level", "currentDealershipLevel");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("Dealership_Level", "currentDealershipLevel", runtimeScene, runtimeScene.getVariables().get("DealershipLevelRealTime"));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DealershipLevelRealTime")));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Dealership_Level", "currentDealershipLevel"));
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Dealership_Level");
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}}

}


{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("MIF_Level", "currentMIFLevel");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects2);
{gdjs.evtTools.storage.readNumberFromJSONFile("MIF_Level", "currentMIFLevel", runtimeScene, runtimeScene.getVariables().get("MIFLevelRealTime"));
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MIFLevelRealTime")));
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i].hide();
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("MIF_Level", "currentMIFLevel"));
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MIF_Level");
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(1);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects = Hashtable.newFrom({"Button_Close": gdjs.GameplayCode.GDButton_95CloseObjects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects = Hashtable.newFrom({"Button_Close": gdjs.GameplayCode.GDButton_95CloseObjects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects = Hashtable.newFrom({"Button_Close": gdjs.GameplayCode.GDButton_95CloseObjects4});
gdjs.GameplayCode.asyncCallback11422524 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);

gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects5[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects5[i].hide();
}
}}
gdjs.GameplayCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDButton_95CloseObjects4) asyncObjectsList.addObject("Button_Close", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11422524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMIFObjects3Objects = Hashtable.newFrom({"MIF": gdjs.GameplayCode.GDMIFObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMaxLevelReachedObjects4Objects = Hashtable.newFrom({"MaxLevelReached": gdjs.GameplayCode.GDMaxLevelReachedObjects4});
gdjs.GameplayCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 5;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11425156);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95AddObjects4 */
/* Reuse gdjs.GameplayCode.GDUpgrade_95BarObjects4 */
/* Reuse gdjs.GameplayCode.GDUpgrade_95UIObjects4 */
/* Reuse gdjs.GameplayCode.GDMaxLevelReachedObjects4 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMaxLevelReachedObjects4Objects, -(1090), 550, "UI");
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].setWrappingWidth(300);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UIObjects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UIObjects4[0].getWidth()) / 2 - (gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95BarObjects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects4[0].getPointY("")) + 150);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.asyncCallback11424676 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects4);

{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UIObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UIObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95BarObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95BarObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameplayCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDButton_95AddObjects3) asyncObjectsList.addObject("Button_Add", obj);
for (const obj of gdjs.GameplayCode.GDButton_95CloseObjects3) asyncObjectsList.addObject("Button_Close", obj);
for (const obj of gdjs.GameplayCode.GDInfo_95MIFObjects3) asyncObjectsList.addObject("Info_MIF", obj);
for (const obj of gdjs.GameplayCode.GDLevel_95MIFObjects3) asyncObjectsList.addObject("Level_MIF", obj);
for (const obj of gdjs.GameplayCode.GDMIF_95ThumbnailObjects3) asyncObjectsList.addObject("MIF_Thumbnail", obj);
for (const obj of gdjs.GameplayCode.GDMaxLevelReachedObjects3) asyncObjectsList.addObject("MaxLevelReached", obj);
for (const obj of gdjs.GameplayCode.GDPrice_95MIFObjects3) asyncObjectsList.addObject("Price_MIF", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95BarObjects3) asyncObjectsList.addObject("Upgrade_Bar", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3) asyncObjectsList.addObject("Upgrade_Transparency", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95UIObjects3) asyncObjectsList.addObject("Upgrade_UI", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11424676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95CloseObjects4 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects4[i].getBehavior("Tween").addObjectScaleTween("Down", 0.07, 0.07, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95CloseObjects4 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects4[i].getBehavior("Tween").addObjectScaleTween("Up", 0.075, 0.075, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595CloseObjects4Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11421164);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95CloseObjects4 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Confirm2.wav", 1, false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects4[i].getBehavior("Tween").addObjectScaleTween("Down", 0.07, 0.07, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects4[i].getBehavior("Tween").addObjectScaleTween("Up", 0.075, 0.075, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF"), gdjs.GameplayCode.GDMIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMIFObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition4IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11423844);
}
}}
}
}
}
if (gdjs.GameplayCode.condition4IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "appear-online.ogg", 1, false, 100, 1);
}
{ //Subevents
gdjs.GameplayCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects = Hashtable.newFrom({"Button_Close_2": gdjs.GameplayCode.GDButton_95Close_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects = Hashtable.newFrom({"Button_Close_2": gdjs.GameplayCode.GDButton_95Close_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects = Hashtable.newFrom({"Button_Close_2": gdjs.GameplayCode.GDButton_95Close_952Objects3});
gdjs.GameplayCode.asyncCallback11430748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects4);
gdjs.copyArray(asyncObjectsList.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects4);

gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects4[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects4[i].hide();
}
}}
gdjs.GameplayCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDButton_95Close_952Objects3) asyncObjectsList.addObject("Button_Close_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11430748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDealershipObjects2Objects = Hashtable.newFrom({"Dealership": gdjs.GameplayCode.GDDealershipObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMaxLevelReached_95952Objects3Objects = Hashtable.newFrom({"MaxLevelReached_2": gdjs.GameplayCode.GDMaxLevelReached_952Objects3});
gdjs.GameplayCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 3;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11433780);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Add_952Objects3 */
gdjs.copyArray(asyncObjectsList.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);

/* Reuse gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3 */
/* Reuse gdjs.GameplayCode.GDUpgrade_95UI_952Objects3 */
/* Reuse gdjs.GameplayCode.GDMaxLevelReached_952Objects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMaxLevelReached_95952Objects3Objects, -(1090), 550, "UI");
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].setWrappingWidth(300);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[0].getWidth()) / 2 - (( gdjs.GameplayCode.GDMaxLevelReachedObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDMaxLevelReachedObjects3[0].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointY("")) + 150);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.asyncCallback11432860 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameplayCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDButton_95Add_952Objects2) asyncObjectsList.addObject("Button_Add_2", obj);
for (const obj of gdjs.GameplayCode.GDButton_95Close_952Objects2) asyncObjectsList.addObject("Button_Close_2", obj);
for (const obj of gdjs.GameplayCode.GDDealership_95ThumbnailObjects2) asyncObjectsList.addObject("Dealership_Thumbnail", obj);
for (const obj of gdjs.GameplayCode.GDInfo_95DealershipObjects2) asyncObjectsList.addObject("Info_Dealership", obj);
for (const obj of gdjs.GameplayCode.GDLevel_95DealershipObjects2) asyncObjectsList.addObject("Level_Dealership", obj);
for (const obj of gdjs.GameplayCode.GDMaxLevelReachedObjects2) asyncObjectsList.addObject("MaxLevelReached", obj);
for (const obj of gdjs.GameplayCode.GDMaxLevelReached_952Objects2) asyncObjectsList.addObject("MaxLevelReached_2", obj);
for (const obj of gdjs.GameplayCode.GDPrice_95DealershipObjects2) asyncObjectsList.addObject("Price_Dealership", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2) asyncObjectsList.addObject("Upgrade_Bar_2", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2) asyncObjectsList.addObject("Upgrade_Transparency_2", obj);
for (const obj of gdjs.GameplayCode.GDUpgrade_95UI_952Objects2) asyncObjectsList.addObject("Upgrade_UI_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11432860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Close_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.07, 0.07, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Close_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.075, 0.075, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Close_95952Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11429388);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Close_952Objects3 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Confirm2.wav", 1, false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.07, 0.07, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.075, 0.075, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDealershipObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects2[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects2[k] = gdjs.GameplayCode.GDButton_95CloseObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects2[k] = gdjs.GameplayCode.GDButton_95AddObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects2[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects2[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects2[k] = gdjs.GameplayCode.GDLevel_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects2[k] = gdjs.GameplayCode.GDInfo_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects2[k] = gdjs.GameplayCode.GDPrice_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects2[k] = gdjs.GameplayCode.GDButton_95Close_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects2[k] = gdjs.GameplayCode.GDButton_95Add_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects2[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects2[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects2[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects2[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects2.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition4IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11432028);
}
}}
}
}
}
if (gdjs.GameplayCode.condition4IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "appear-online.ogg", 1, false, 100, 1);
}
{ //Subevents
gdjs.GameplayCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList13 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].setPosition(0,75);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects3[i].setPosition(400,120);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UIObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UIObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].getWidth()) / 2,500);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UIObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UIObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDButton_95AddObjects3[i].getWidth()) / 2,600);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointY("")) - 240);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].setPosition(0,0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95CloseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95CloseObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDInfo_95MIFObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointY("")) - 50);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDPrice_95MIFObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointY("")) - 200);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDLevel_95MIFObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointY("")) - 125);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].setPosition(0,75);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].setPosition(400,120);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UIObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UIObjects3[0].getWidth()) / 2 - (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2,500);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95UIObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95UIObjects3[0].getWidth()) / 2 - (( gdjs.GameplayCode.GDButton_95AddObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDButton_95AddObjects3[0].getWidth()) / 2,600);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointY("")) - 230);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].setPosition(0,0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Close_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Close_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95BarObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95BarObjects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointY("")) - 50);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointY("")) - 200);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].setPosition((( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointX("")) + (( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getWidth()) / 2 - (gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[0].getPointY("")) - 125);
}
}}

}


{


gdjs.GameplayCode.eventsList8(runtimeScene);
}


{


gdjs.GameplayCode.eventsList12(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects = Hashtable.newFrom({"Button_Add": gdjs.GameplayCode.GDButton_95AddObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects = Hashtable.newFrom({"Button_Add": gdjs.GameplayCode.GDButton_95AddObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects = Hashtable.newFrom({"Button_Add": gdjs.GameplayCode.GDButton_95AddObjects3});
gdjs.GameplayCode.asyncCallback11441588 = function (runtimeScene, asyncObjectsList) {
}
gdjs.GameplayCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11441588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95AddObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95AddObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595AddObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3));
}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition5IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11439476);
}
}}
}
}
}
}
if (gdjs.GameplayCode.condition5IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95AddObjects3 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Purchase.wav", 1, false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("MIF_Level", "currentMIFLevel", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95AddObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95AddObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) - 1);
}
}}

}


{



}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects = Hashtable.newFrom({"Button_Add_2": gdjs.GameplayCode.GDButton_95Add_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects = Hashtable.newFrom({"Button_Add_2": gdjs.GameplayCode.GDButton_95Add_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects = Hashtable.newFrom({"Button_Add_2": gdjs.GameplayCode.GDButton_95Add_952Objects2});
gdjs.GameplayCode.asyncCallback11449820 = function (runtimeScene, asyncObjectsList) {
}
gdjs.GameplayCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11449820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Add_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Add_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDButton_9595Add_95952Objects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4));
}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects2[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects2[k] = gdjs.GameplayCode.GDButton_95CloseObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects2[k] = gdjs.GameplayCode.GDButton_95AddObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects2[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects2[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects2[k] = gdjs.GameplayCode.GDLevel_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects2[k] = gdjs.GameplayCode.GDInfo_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects2[k] = gdjs.GameplayCode.GDPrice_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects2.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDButton_95Close_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects2[k] = gdjs.GameplayCode.GDButton_95Close_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDButton_95Add_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects2[k] = gdjs.GameplayCode.GDButton_95Add_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects2[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDLevel_95DealershipObjects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects2[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDInfo_95DealershipObjects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects2[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPrice_95DealershipObjects2[i].isVisible() ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects2[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects2.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition5IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11446116);
}
}}
}
}
}
}
if (gdjs.GameplayCode.condition5IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDButton_95Add_952Objects2 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Purchase.wav", 1, false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("Dealership_Level", "currentDealershipLevel", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDButton_95Add_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDButton_95Add_952Objects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2);
{for(var i = 0, len = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) - 1);
}
}}

}


{



}


};gdjs.GameplayCode.eventsList18 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList13(runtimeScene);
}


{


gdjs.GameplayCode.eventsList15(runtimeScene);
}


{


gdjs.GameplayCode.eventsList17(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects = Hashtable.newFrom({"Tutorial_Button": gdjs.GameplayCode.GDTutorial_95ButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects = Hashtable.newFrom({"Tutorial_Button": gdjs.GameplayCode.GDTutorial_95ButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects = Hashtable.newFrom({"Tutorial_Button": gdjs.GameplayCode.GDTutorial_95ButtonObjects3});
gdjs.GameplayCode.asyncCallback11457500 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects4);

{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects4[i].setVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects4[i].getVariables().get("Open"), true);
}
}}
gdjs.GameplayCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDTutorial_95ButtonObjects3) asyncObjectsList.addObject("Tutorial_Button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11457500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects = Hashtable.newFrom({"Tutorial_Button": gdjs.GameplayCode.GDTutorial_95ButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects2Objects = Hashtable.newFrom({"Tutorial_Button": gdjs.GameplayCode.GDTutorial_95ButtonObjects2});
gdjs.GameplayCode.asyncCallback11461972 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);

{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].setVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariables().get("Open"), false);
}
}}
gdjs.GameplayCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDTutorial_95ButtonObjects2) asyncObjectsList.addObject("Tutorial_Button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11461972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11451940);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects3[i].setPosition(0,80);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects3[i].setPosition(450,280);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects3[i].setPosition(25,280);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].setVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariables().get("Open"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorial_95ButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariables().get("Open"), false) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95ButtonObjects3[k] = gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11454988);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorial_95ButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariables().get("Open"), false) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95ButtonObjects3[k] = gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11456556);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects3);
/* Reuse gdjs.GameplayCode.GDTutorial_95ButtonObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList19(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getVariables().get("Open"), true) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95ButtonObjects3[k] = gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11459412);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorial_95ButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Button"), gdjs.GameplayCode.GDTutorial_95ButtonObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorial_9595ButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95ButtonObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDTutorial_95ButtonObjects2[i].getVariables().get("Open"), true) ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95ButtonObjects2[k] = gdjs.GameplayCode.GDTutorial_95ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95ButtonObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11460868);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects2);
/* Reuse gdjs.GameplayCode.GDTutorial_95ButtonObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95ButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95ButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects2[i].hide();
}
}
{ //Subevents
gdjs.GameplayCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDArrow_9595RightObjects2Objects = Hashtable.newFrom({"Arrow_Right": gdjs.GameplayCode.GDArrow_95RightObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDArrow_9595LeftObjects2Objects = Hashtable.newFrom({"Arrow_Left": gdjs.GameplayCode.GDArrow_95LeftObjects2});
gdjs.GameplayCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].returnVariable(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")).setNumber(0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")) < 6 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects2[k] = gdjs.GameplayCode.GDTutorial_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDArrow_9595RightObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorial_95UIObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].returnVariable(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")) > 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects2[k] = gdjs.GameplayCode.GDTutorial_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDArrow_9595LeftObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorial_95UIObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].returnVariable(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")).sub(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects2[k] = gdjs.GameplayCode.GDTutorial_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects2[i].getVariables().get("Page")) == 6 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects2[k] = gdjs.GameplayCode.GDTutorial_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects1.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects1[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects1[i].getVariables().get("Page")) == 0) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects1[k] = gdjs.GameplayCode.GDTutorial_95UIObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects1.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects1.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects1[i].getVariableNumber(gdjs.GameplayCode.GDTutorial_95UIObjects1[i].getVariables().get("Page")) == 6) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects1[k] = gdjs.GameplayCode.GDTutorial_95UIObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects1.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95RightObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95RightObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDArrow_95LeftObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDArrow_95LeftObjects1[i].hide(false);
}
}}

}


};gdjs.GameplayCode.eventsList23 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList21(runtimeScene);
}


{


gdjs.GameplayCode.eventsList22(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95951Objects4Objects = Hashtable.newFrom({"Car_Type_1": gdjs.GameplayCode.GDCar_95Type_951Objects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95952Objects4Objects = Hashtable.newFrom({"Car_Type_2": gdjs.GameplayCode.GDCar_95Type_952Objects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95953Objects3Objects = Hashtable.newFrom({"Car_Type_3": gdjs.GameplayCode.GDCar_95Type_953Objects3});
gdjs.GameplayCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95951Objects4Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects4[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealershipObjects4[k] = gdjs.GameplayCode.GDDealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects4.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects4[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects4[k] = gdjs.GameplayCode.GDButton_95CloseObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects4[k] = gdjs.GameplayCode.GDButton_95AddObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects4[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects4[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects4[k] = gdjs.GameplayCode.GDLevel_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects4[k] = gdjs.GameplayCode.GDInfo_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects4[k] = gdjs.GameplayCode.GDPrice_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects4.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects4[k] = gdjs.GameplayCode.GDButton_95Close_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects4[k] = gdjs.GameplayCode.GDButton_95Add_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects4[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects4[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects4[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects4[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects4.length = k;}}
}
}
}
if (gdjs.GameplayCode.condition4IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Type_951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects4);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects4[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects4[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects4[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95952Objects4Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects4[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealershipObjects4[k] = gdjs.GameplayCode.GDDealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects4.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects4[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects4[k] = gdjs.GameplayCode.GDButton_95CloseObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects4[k] = gdjs.GameplayCode.GDButton_95AddObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects4[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects4[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects4[k] = gdjs.GameplayCode.GDLevel_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects4[k] = gdjs.GameplayCode.GDInfo_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects4[k] = gdjs.GameplayCode.GDPrice_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects4.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects4[k] = gdjs.GameplayCode.GDButton_95Close_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects4[k] = gdjs.GameplayCode.GDButton_95Add_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects4[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects4[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects4[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects4[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects4.length = k;}}
}
}
}
if (gdjs.GameplayCode.condition4IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects4);
/* Reuse gdjs.GameplayCode.GDCar_95Type_952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects4);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(2);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects4[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects4[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects4[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Type_95953Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition3IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
if (gdjs.GameplayCode.condition4IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
/* Reuse gdjs.GameplayCode.GDCar_95Type_953Objects3 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(3);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(1);
}
}}

}


};gdjs.GameplayCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_951Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_951Objects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_951Objects3[k] = gdjs.GameplayCode.GDCar_95Type_951Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_951Objects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].getAnimation() == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_952Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_952Objects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_952Objects3[k] = gdjs.GameplayCode.GDCar_95Type_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_952Objects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].getAnimation() == 1) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_953Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_953Objects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_953Objects3[k] = gdjs.GameplayCode.GDCar_95Type_953Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_953Objects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].getAnimation() == 2) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_951Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_951Objects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_951Objects3[k] = gdjs.GameplayCode.GDCar_95Type_951Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_951Objects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_952Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_952Objects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_952Objects3[k] = gdjs.GameplayCode.GDCar_95Type_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_952Objects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_953Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_953Objects2[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_953Objects2[k] = gdjs.GameplayCode.GDCar_95Type_953Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_953Objects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2[i].getAnimation() == 2 ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


};gdjs.GameplayCode.eventsList26 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList24(runtimeScene);
}


{


gdjs.GameplayCode.eventsList25(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects5Objects = Hashtable.newFrom({"House_1": gdjs.GameplayCode.GDHouse_951Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects5Objects = Hashtable.newFrom({"House_1": gdjs.GameplayCode.GDHouse_951Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.eventsList27 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList28 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_1");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_1"), gdjs.GameplayCode.GDCountdown_95House_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready1"), gdjs.GameplayCode.GDReady1Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady1Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady1Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_1", runtimeScene, runtimeScene.getVariables().get("Stored_Time_1"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_1")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].resetTimer("House_1_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects5Objects, runtimeScene, true, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_951Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_951Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_951Objects5[k] = gdjs.GameplayCode.GDHouse_951Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_951Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11485996);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_1"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_1"), gdjs.GameplayCode.GDCountdown_95House_951Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_951Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready1"), gdjs.GameplayCode.GDReady1Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 600, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].resetTimer("House_1_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady1Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady1Objects5[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects5Objects, runtimeScene, true, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_951Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_951Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_951Objects5[k] = gdjs.GameplayCode.GDHouse_951Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_951Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11491348);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_1");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_1"), gdjs.GameplayCode.GDCountdown_95House_951Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_951Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready1"), gdjs.GameplayCode.GDReady1Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 600, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].resetTimer("House_1_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady1Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady1Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_1", runtimeScene, runtimeScene.getVariables().get("Stored_Time_1"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount6 = 1;
for(gdjs.GameplayCode.repeatIndex6 = 0;gdjs.GameplayCode.repeatIndex6 < gdjs.GameplayCode.repeatCount6;++gdjs.GameplayCode.repeatIndex6) {
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects6);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_951Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_951Objects6[i].getTimerElapsedTimeInSecondsOrNaN("House_1_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_951Objects6[k] = gdjs.GameplayCode.GDHouse_951Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_951Objects6.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_951Objects6.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHouse_951Objects6[i].getVariableNumber(gdjs.GameplayCode.GDHouse_951Objects6[i].getVariables().get("House_1_Count")) == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_951Objects6[k] = gdjs.GameplayCode.GDHouse_951Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_951Objects6.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects6[i].returnVariable(gdjs.GameplayCode.GDHouse_951Objects6[i].getVariables().get("House_1_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_951Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_951Objects6[i].resetTimer("House_1_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_1", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_951Objects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_951Objects6[0].getVariables()).get("House_1_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_951Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_951Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_951Objects5[i].getVariables().get("House_1_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_951Objects5[k] = gdjs.GameplayCode.GDHouse_951Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_951Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11497780);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_1"), gdjs.GameplayCode.GDCountdown_95House_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready1"), gdjs.GameplayCode.GDReady1Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady1Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady1Objects5[i].hide(false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_1"), gdjs.GameplayCode.GDCountdown_95House_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects4[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_951Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_951Objects4[0].getVariables()).get("House_1_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_951Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_951Objects4[i].setPosition((( gdjs.GameplayCode.GDHouse_951Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_951Objects4[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_951Objects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_951Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_951Objects4[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects5Objects = Hashtable.newFrom({"House_2": gdjs.GameplayCode.GDHouse_952Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects5Objects = Hashtable.newFrom({"House_2": gdjs.GameplayCode.GDHouse_952Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.eventsList29 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList30 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_2");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_2"), gdjs.GameplayCode.GDCountdown_95House_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready2"), gdjs.GameplayCode.GDReady2Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady2Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady2Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_2", runtimeScene, runtimeScene.getVariables().get("Stored_Time_2"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_2")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].resetTimer("House_2_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects5Objects, runtimeScene, true, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_952Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_952Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_952Objects5[k] = gdjs.GameplayCode.GDHouse_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_952Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11504196);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_2"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_2"), gdjs.GameplayCode.GDCountdown_95House_952Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_952Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready2"), gdjs.GameplayCode.GDReady2Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 371, 600, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(2);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].resetTimer("House_2_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady2Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady2Objects5[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects5);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects5Objects, runtimeScene, true, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_952Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_952Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_952Objects5[k] = gdjs.GameplayCode.GDHouse_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_952Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11509388);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95RightObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95RightObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95RightObjects5[k] = gdjs.GameplayCode.GDArrow_95RightObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95RightObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95LeftObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95LeftObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95LeftObjects5[k] = gdjs.GameplayCode.GDArrow_95LeftObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95LeftObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_2");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_2"), gdjs.GameplayCode.GDCountdown_95House_952Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_952Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready2"), gdjs.GameplayCode.GDReady2Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 371, 600, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(2);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].resetTimer("House_2_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady2Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady2Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_2", runtimeScene, runtimeScene.getVariables().get("Stored_Time_2"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount6 = 1;
for(gdjs.GameplayCode.repeatIndex6 = 0;gdjs.GameplayCode.repeatIndex6 < gdjs.GameplayCode.repeatCount6;++gdjs.GameplayCode.repeatIndex6) {
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects6);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_952Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_952Objects6[i].getTimerElapsedTimeInSecondsOrNaN("House_2_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_952Objects6[k] = gdjs.GameplayCode.GDHouse_952Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_952Objects6.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_952Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_952Objects6[i].getVariableNumber(gdjs.GameplayCode.GDHouse_952Objects6[i].getVariables().get("House_2_Count")) == 0 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_952Objects6[k] = gdjs.GameplayCode.GDHouse_952Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_952Objects6.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects6[i].returnVariable(gdjs.GameplayCode.GDHouse_952Objects6[i].getVariables().get("House_2_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_952Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_952Objects6[i].resetTimer("House_2_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_2", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_952Objects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_952Objects6[0].getVariables()).get("House_2_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_952Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_952Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_952Objects5[i].getVariables().get("House_2_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_952Objects5[k] = gdjs.GameplayCode.GDHouse_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_952Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11515796);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_2"), gdjs.GameplayCode.GDCountdown_95House_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready2"), gdjs.GameplayCode.GDReady2Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady2Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady2Objects5[i].hide(false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_2"), gdjs.GameplayCode.GDCountdown_95House_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects4[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_952Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_952Objects4[0].getVariables()).get("House_2_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_952Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_952Objects4[i].setPosition((( gdjs.GameplayCode.GDHouse_952Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_952Objects4[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_952Objects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_952Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_952Objects4[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects5Objects = Hashtable.newFrom({"House_3": gdjs.GameplayCode.GDHouse_953Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects5Objects = Hashtable.newFrom({"House_3": gdjs.GameplayCode.GDHouse_953Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.eventsList31 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList32 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_3");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready3"), gdjs.GameplayCode.GDReady3Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady3Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady3Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_3", runtimeScene, runtimeScene.getVariables().get("Stored_Time_3"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_3")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].resetTimer("House_3_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_953Objects5[k] = gdjs.GameplayCode.GDHouse_953Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_953Objects5[k] = gdjs.GameplayCode.GDHouse_953Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11522532);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_3"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_953Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready3"), gdjs.GameplayCode.GDReady3Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 450, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(3);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].resetTimer("House_3_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady3Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady3Objects5[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_953Objects5[k] = gdjs.GameplayCode.GDHouse_953Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_953Objects5[k] = gdjs.GameplayCode.GDHouse_953Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11528364);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_3");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_953Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready3"), gdjs.GameplayCode.GDReady3Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 450, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(3);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].resetTimer("House_3_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady3Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady3Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_3", runtimeScene, runtimeScene.getVariables().get("Stored_Time_3"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount6 = 1;
for(gdjs.GameplayCode.repeatIndex6 = 0;gdjs.GameplayCode.repeatIndex6 < gdjs.GameplayCode.repeatCount6;++gdjs.GameplayCode.repeatIndex6) {
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects6);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects6[i].getTimerElapsedTimeInSecondsOrNaN("House_3_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_953Objects6[k] = gdjs.GameplayCode.GDHouse_953Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects6.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects6.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHouse_953Objects6[i].getVariableNumber(gdjs.GameplayCode.GDHouse_953Objects6[i].getVariables().get("House_3_Count")) == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_953Objects6[k] = gdjs.GameplayCode.GDHouse_953Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects6.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects6[i].returnVariable(gdjs.GameplayCode.GDHouse_953Objects6[i].getVariables().get("House_3_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects6[i].resetTimer("House_3_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_3", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_953Objects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_953Objects6[0].getVariables()).get("House_3_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_953Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_953Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_953Objects5[i].getVariables().get("House_3_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_953Objects5[k] = gdjs.GameplayCode.GDHouse_953Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_953Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 3;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11534940);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready3"), gdjs.GameplayCode.GDReady3Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady3Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady3Objects5[i].hide(false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_3"), gdjs.GameplayCode.GDCountdown_95House_953Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects4[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_953Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_953Objects4[0].getVariables()).get("House_3_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_953Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_953Objects4[i].setPosition((( gdjs.GameplayCode.GDHouse_953Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_953Objects4[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_953Objects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_953Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_953Objects4[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects5Objects = Hashtable.newFrom({"House_4": gdjs.GameplayCode.GDHouse_954Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects5Objects = Hashtable.newFrom({"House_4": gdjs.GameplayCode.GDHouse_954Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.eventsList33 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList34 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_4");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready4"), gdjs.GameplayCode.GDReady4Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady4Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady4Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_4", runtimeScene, runtimeScene.getVariables().get("Stored_Time_4"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_4")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].resetTimer("House_4_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_954Objects5[k] = gdjs.GameplayCode.GDHouse_954Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_954Objects5[k] = gdjs.GameplayCode.GDHouse_954Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11541404);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_4"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_954Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready4"), gdjs.GameplayCode.GDReady4Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 371, 450, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(4);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].resetTimer("House_4_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady4Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady4Objects5[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_954Objects5[k] = gdjs.GameplayCode.GDHouse_954Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_954Objects5[k] = gdjs.GameplayCode.GDHouse_954Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11547236);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_4");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_954Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready4"), gdjs.GameplayCode.GDReady4Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 371, 450, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(4);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].resetTimer("House_4_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady4Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady4Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_4", runtimeScene, runtimeScene.getVariables().get("Stored_Time_4"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount6 = 1;
for(gdjs.GameplayCode.repeatIndex6 = 0;gdjs.GameplayCode.repeatIndex6 < gdjs.GameplayCode.repeatCount6;++gdjs.GameplayCode.repeatIndex6) {
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects6);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects6[i].getTimerElapsedTimeInSecondsOrNaN("House_4_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_954Objects6[k] = gdjs.GameplayCode.GDHouse_954Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects6.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects6.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHouse_954Objects6[i].getVariableNumber(gdjs.GameplayCode.GDHouse_954Objects6[i].getVariables().get("House_4_Count")) == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_954Objects6[k] = gdjs.GameplayCode.GDHouse_954Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects6.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects6[i].returnVariable(gdjs.GameplayCode.GDHouse_954Objects6[i].getVariables().get("House_4_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects6[i].resetTimer("House_4_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_4", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_954Objects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_954Objects6[0].getVariables()).get("House_4_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_954Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_954Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_954Objects5[i].getVariables().get("House_4_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_954Objects5[k] = gdjs.GameplayCode.GDHouse_954Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_954Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 3;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11553812);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready4"), gdjs.GameplayCode.GDReady4Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDReady4Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady4Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects5[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_4"), gdjs.GameplayCode.GDCountdown_95House_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects4[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_954Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_954Objects4[0].getVariables()).get("House_4_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_954Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_954Objects4[i].setPosition((( gdjs.GameplayCode.GDHouse_954Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_954Objects4[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_954Objects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_954Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_954Objects4[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects5Objects = Hashtable.newFrom({"House_5": gdjs.GameplayCode.GDHouse_955Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects5Objects = Hashtable.newFrom({"House_5": gdjs.GameplayCode.GDHouse_955Objects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects5});
gdjs.GameplayCode.eventsList35 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList36 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_5");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready5"), gdjs.GameplayCode.GDReady5Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady5Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady5Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_5", runtimeScene, runtimeScene.getVariables().get("Stored_Time_5"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_5")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].resetTimer("House_5_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_955Objects5[k] = gdjs.GameplayCode.GDHouse_955Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_955Objects5[k] = gdjs.GameplayCode.GDHouse_955Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11560404);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_5"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_955Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready5"), gdjs.GameplayCode.GDReady5Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 300, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(5);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].resetTimer("House_5_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady5Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady5Objects5[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects5);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects5);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects5);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects5);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects5);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects5Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects5[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_955Objects5[k] = gdjs.GameplayCode.GDHouse_955Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects5.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_955Objects5[k] = gdjs.GameplayCode.GDHouse_955Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects5.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11566236);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects5[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects5[k] = gdjs.GameplayCode.GDButton_95CloseObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects5[k] = gdjs.GameplayCode.GDButton_95AddObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects5[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects5[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects5[k] = gdjs.GameplayCode.GDLevel_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects5[k] = gdjs.GameplayCode.GDInfo_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects5[k] = gdjs.GameplayCode.GDPrice_95MIFObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects5[k] = gdjs.GameplayCode.GDButton_95Close_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects5[k] = gdjs.GameplayCode.GDButton_95Add_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects5[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects5[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects5[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects5[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects5[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects5[k] = gdjs.GameplayCode.GDTutorial_95UIObjects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_5");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects5);
/* Reuse gdjs.GameplayCode.GDHouse_955Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Ready5"), gdjs.GameplayCode.GDReady5Objects5);
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects5Objects, 81, 300, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects5[i].addForce(0, -(150), 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(5);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].resetTimer("House_5_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady5Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady5Objects5[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_5", runtimeScene, runtimeScene.getVariables().get("Stored_Time_5"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount6 = 1;
for(gdjs.GameplayCode.repeatIndex6 = 0;gdjs.GameplayCode.repeatIndex6 < gdjs.GameplayCode.repeatCount6;++gdjs.GameplayCode.repeatIndex6) {
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects6);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects6.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects6[i].getTimerElapsedTimeInSecondsOrNaN("House_5_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_955Objects6[k] = gdjs.GameplayCode.GDHouse_955Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects6.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects6.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHouse_955Objects6[i].getVariableNumber(gdjs.GameplayCode.GDHouse_955Objects6[i].getVariables().get("House_5_Count")) == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_955Objects6[k] = gdjs.GameplayCode.GDHouse_955Objects6[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects6.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects6[i].returnVariable(gdjs.GameplayCode.GDHouse_955Objects6[i].getVariables().get("House_5_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects6.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects6[i].resetTimer("House_5_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_5", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_955Objects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_955Objects6[0].getVariables()).get("House_5_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_955Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_955Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_955Objects5[i].getVariables().get("House_5_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_955Objects5[k] = gdjs.GameplayCode.GDHouse_955Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_955Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 5;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11572684);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ready5"), gdjs.GameplayCode.GDReady5Objects5);
{for(var i = 0, len = gdjs.GameplayCode.GDReady5Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady5Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects5[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_5"), gdjs.GameplayCode.GDCountdown_95House_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects4[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_955Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_955Objects4[0].getVariables()).get("House_5_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_955Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_955Objects4[i].setPosition((( gdjs.GameplayCode.GDHouse_955Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_955Objects4[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_955Objects4[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_955Objects4.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_955Objects4[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects4Objects = Hashtable.newFrom({"House_6": gdjs.GameplayCode.GDHouse_956Objects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects4Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects4Objects = Hashtable.newFrom({"House_6": gdjs.GameplayCode.GDHouse_956Objects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects4Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects4});
gdjs.GameplayCode.eventsList37 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList38 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_6");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ready6"), gdjs.GameplayCode.GDReady6Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady6Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady6Objects4[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_6", runtimeScene, runtimeScene.getVariables().get("Stored_Time_6"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].returnVariable(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stored_Time_6")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].resetTimer("House_6_CD");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects4);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects4Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects4[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_956Objects4[k] = gdjs.GameplayCode.GDHouse_956Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects4.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects4[i].getVariableNumber(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_956Objects4[k] = gdjs.GameplayCode.GDHouse_956Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects4.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11579068);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects4[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects4[k] = gdjs.GameplayCode.GDButton_95CloseObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects4[k] = gdjs.GameplayCode.GDButton_95AddObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects4[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects4[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects4[k] = gdjs.GameplayCode.GDLevel_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects4[k] = gdjs.GameplayCode.GDInfo_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects4[k] = gdjs.GameplayCode.GDPrice_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects4.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects4[k] = gdjs.GameplayCode.GDButton_95Close_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects4[k] = gdjs.GameplayCode.GDButton_95Add_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects4[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects4[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects4[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects4[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects4.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects4[k] = gdjs.GameplayCode.GDTutorial_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95RightObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95RightObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95RightObjects4[k] = gdjs.GameplayCode.GDArrow_95RightObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95RightObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95LeftObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95LeftObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95LeftObjects4[k] = gdjs.GameplayCode.GDArrow_95LeftObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95LeftObjects4.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_6"));
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects4);
/* Reuse gdjs.GameplayCode.GDHouse_956Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Ready6"), gdjs.GameplayCode.GDReady6Objects4);
gdjs.GameplayCode.GDCar_95HouseObjects4.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects4Objects, 371, 300, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects4[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects4[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(6);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].resetTimer("House_6_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].returnVariable(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady6Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady6Objects4[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow_Left"), gdjs.GameplayCode.GDArrow_95LeftObjects4);
gdjs.copyArray(runtimeScene.getObjects("Arrow_Right"), gdjs.GameplayCode.GDArrow_95RightObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects4);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects4);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects4);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects4);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects4);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
gdjs.GameplayCode.condition6IsTrue_0.val = false;
gdjs.GameplayCode.condition7IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects4Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects4[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_956Objects4[k] = gdjs.GameplayCode.GDHouse_956Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects4.length = k;}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects4[i].getVariableNumber(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")) == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_956Objects4[k] = gdjs.GameplayCode.GDHouse_956Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects4.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11585092);
}
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects4[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects4[k] = gdjs.GameplayCode.GDButton_95CloseObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects4[k] = gdjs.GameplayCode.GDButton_95AddObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects4[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects4[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects4[k] = gdjs.GameplayCode.GDLevel_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects4[k] = gdjs.GameplayCode.GDInfo_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition4IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects4[k] = gdjs.GameplayCode.GDPrice_95MIFObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects4.length = k;}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects4[k] = gdjs.GameplayCode.GDButton_95Close_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects4[k] = gdjs.GameplayCode.GDButton_95Add_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects4[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects4[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects4[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_0.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects4[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects4.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTutorial_95UIObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTutorial_95UIObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDTutorial_95UIObjects4[k] = gdjs.GameplayCode.GDTutorial_95UIObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTutorial_95UIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95RightObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95RightObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95RightObjects4[k] = gdjs.GameplayCode.GDArrow_95RightObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95RightObjects4.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDArrow_95LeftObjects4.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDArrow_95LeftObjects4[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_0.val = true;
        gdjs.GameplayCode.GDArrow_95LeftObjects4[k] = gdjs.GameplayCode.GDArrow_95LeftObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDArrow_95LeftObjects4.length = k;}if ( gdjs.GameplayCode.condition6IsTrue_0.val ) {
{
gdjs.GameplayCode.condition7IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Timer_House", "House_6");
}}
}
}
}
}
}
}
if (gdjs.GameplayCode.condition7IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects4);
/* Reuse gdjs.GameplayCode.GDHouse_956Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Ready6"), gdjs.GameplayCode.GDReady6Objects4);
gdjs.GameplayCode.GDCar_95HouseObjects4.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects4Objects, 371, 300, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects4[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects4[i].addForce(0, 150, 1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(6);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].resetTimer("House_6_CD");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDReady6Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady6Objects4[i].hide();
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("Timer_House", "House_6", runtimeScene, runtimeScene.getVariables().get("Stored_Time_6"));
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects4[i].returnVariable(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)));
}
}}

}


{



}


{


gdjs.GameplayCode.repeatCount5 = 1;
for(gdjs.GameplayCode.repeatIndex5 = 0;gdjs.GameplayCode.repeatIndex5 < gdjs.GameplayCode.repeatCount5;++gdjs.GameplayCode.repeatIndex5) {
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects5);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects5.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects5[i].getTimerElapsedTimeInSecondsOrNaN("House_6_CD") > 1 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_956Objects5[k] = gdjs.GameplayCode.GDHouse_956Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects5.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects5.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHouse_956Objects5[i].getVariableNumber(gdjs.GameplayCode.GDHouse_956Objects5[i].getVariables().get("House_6_Count")) == 0) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHouse_956Objects5[k] = gdjs.GameplayCode.GDHouse_956Objects5[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects5.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects5[i].returnVariable(gdjs.GameplayCode.GDHouse_956Objects5[i].getVariables().get("House_6_Count")).sub(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects5[i].resetTimer("House_6_CD");
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("Timer_House", "House_6", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_956Objects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_956Objects5[0].getVariables()).get("House_6_Count"))));
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects4);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHouse_956Objects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHouse_956Objects4[i].getVariableNumber(gdjs.GameplayCode.GDHouse_956Objects4[i].getVariables().get("House_6_Count")) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHouse_956Objects4[k] = gdjs.GameplayCode.GDHouse_956Objects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHouse_956Objects4.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 5;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11592060);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ready6"), gdjs.GameplayCode.GDReady6Objects4);
{for(var i = 0, len = gdjs.GameplayCode.GDReady6Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDReady6Objects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects4[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Countdown_House_6"), gdjs.GameplayCode.GDCountdown_95House_956Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects3);
{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects3[i].setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameplayCode.GDHouse_956Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameplayCode.GDHouse_956Objects3[0].getVariables()).get("House_6_Count"))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCountdown_95House_956Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCountdown_95House_956Objects3[i].setPosition((( gdjs.GameplayCode.GDHouse_956Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_956Objects3[0].getPointX("Center")) - (gdjs.GameplayCode.GDCountdown_95House_956Objects3[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHouse_956Objects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDHouse_956Objects3[0].getPointY("")) - 50);
}
}}

}


};gdjs.GameplayCode.eventsList39 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.eventsList28(runtimeScene);
}


{


gdjs.GameplayCode.eventsList30(runtimeScene);
}


{


gdjs.GameplayCode.eventsList32(runtimeScene);
}


{


gdjs.GameplayCode.eventsList34(runtimeScene);
}


{


gdjs.GameplayCode.eventsList36(runtimeScene);
}


{


gdjs.GameplayCode.eventsList38(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects = Hashtable.newFrom({"Collider_Finish": gdjs.GameplayCode.GDCollider_95FinishObjects3});
gdjs.GameplayCode.eventsList40 = function(runtimeScene) {

{

gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = 0;

gdjs.GameplayCode.GDCollider_95FinishObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects2_1final.length = 0;gdjs.GameplayCode.GDCar_95Dealership_952Objects2_1final.length = 0;gdjs.GameplayCode.GDCar_95Dealership_953Objects2_1final.length = 0;gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects3);
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCar_95Dealership_951Objects2_1final.indexOf(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[j]) === -1 )
            gdjs.GameplayCode.GDCar_95Dealership_951Objects2_1final.push(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDCollider_95FinishObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.indexOf(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]) === -1 )
            gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.push(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects3);
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCar_95Dealership_952Objects2_1final.indexOf(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[j]) === -1 )
            gdjs.GameplayCode.GDCar_95Dealership_952Objects2_1final.push(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDCollider_95FinishObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.indexOf(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]) === -1 )
            gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.push(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Finish"), gdjs.GameplayCode.GDCollider_95FinishObjects3);
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595FinishObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCar_95Dealership_953Objects2_1final.indexOf(gdjs.GameplayCode.GDCar_95Dealership_953Objects3[j]) === -1 )
            gdjs.GameplayCode.GDCar_95Dealership_953Objects2_1final.push(gdjs.GameplayCode.GDCar_95Dealership_953Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDCollider_95FinishObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.indexOf(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]) === -1 )
            gdjs.GameplayCode.GDCollider_95FinishObjects2_1final.push(gdjs.GameplayCode.GDCollider_95FinishObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDCar_95Dealership_951Objects2_1final, gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDCar_95Dealership_952Objects2_1final, gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDCar_95Dealership_953Objects2_1final, gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDCollider_95FinishObjects2_1final, gdjs.GameplayCode.GDCollider_95FinishObjects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}

}


};gdjs.GameplayCode.eventsList41 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList39(runtimeScene);
}


{


gdjs.GameplayCode.eventsList40(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects3Objects = Hashtable.newFrom({"Collider_MIF": gdjs.GameplayCode.GDCollider_95MIFObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects = Hashtable.newFrom({"Car_MIF": gdjs.GameplayCode.GDCar_95MIFObjects3});
gdjs.GameplayCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_MIF"), gdjs.GameplayCode.GDCollider_95MIFObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11600044);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects3 */
gdjs.GameplayCode.GDCar_95MIFObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects, -(60), 200, "Obj");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95MIFObjects3[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 1;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF"), gdjs.GameplayCode.GDMIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIFObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects3[i].setAnimation(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(25);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(600);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].setBBText("Level 2");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].setBBText("100 M");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].setBBText("Income increases to 10 M");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 2;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].setAnimation(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(10);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1000);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(300);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].setBBText("Level 3");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].setBBText("1 T");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].setBBText("Income increases to 50 M");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 3;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF"), gdjs.GameplayCode.GDMIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDMIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIFObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_953Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_954Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_954Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects3[i].setAnimation(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(50);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(20000);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(180);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].setBBText("Level 4");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].setBBText("25 T");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].setBBText("Income increases to 100 M");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 4;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].setAnimation(2);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(100);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(100000);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(120);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects3[i].setBBText("Level 5");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects3[i].setBBText("100 T");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects3[i].setBBText("Income increases to 250 M");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 5;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("MIF"), gdjs.GameplayCode.GDMIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDMIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDMIFObjects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_955Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_955Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouse_956Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouse_956Objects2[i].setAnimation(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(250);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(60);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95MIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95MIFObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95MIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95MIFObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95MIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95MIFObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects = Hashtable.newFrom({"Car_MIF": gdjs.GameplayCode.GDCar_95MIFObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects = Hashtable.newFrom({"Collider_Dealership": gdjs.GameplayCode.GDCollider_95DealershipObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects = Hashtable.newFrom({"Car_MIF": gdjs.GameplayCode.GDCar_95MIFObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects = Hashtable.newFrom({"Collider_Dealership": gdjs.GameplayCode.GDCollider_95DealershipObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects = Hashtable.newFrom({"Car_MIF": gdjs.GameplayCode.GDCar_95MIFObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects = Hashtable.newFrom({"Collider_Dealership": gdjs.GameplayCode.GDCollider_95DealershipObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects3Objects = Hashtable.newFrom({"House_1": gdjs.GameplayCode.GDHouse_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("House_1"), gdjs.GameplayCode.GDHouse_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95951Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11626236);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
/* Reuse gdjs.GameplayCode.GDDealershipObjects3 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects3Objects = Hashtable.newFrom({"House_2": gdjs.GameplayCode.GDHouse_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("House_2"), gdjs.GameplayCode.GDHouse_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95952Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11631684);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
/* Reuse gdjs.GameplayCode.GDDealershipObjects3 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects3Objects = Hashtable.newFrom({"House_3": gdjs.GameplayCode.GDHouse_953Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("House_3"), gdjs.GameplayCode.GDHouse_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95953Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11637460);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
/* Reuse gdjs.GameplayCode.GDDealershipObjects3 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects3Objects = Hashtable.newFrom({"House_4": gdjs.GameplayCode.GDHouse_954Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("House_4"), gdjs.GameplayCode.GDHouse_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95954Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11645668);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
/* Reuse gdjs.GameplayCode.GDDealershipObjects3 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects3Objects = Hashtable.newFrom({"House_5": gdjs.GameplayCode.GDHouse_955Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects3});
gdjs.GameplayCode.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("House_5"), gdjs.GameplayCode.GDHouse_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects3);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects3);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects3[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects3[k] = gdjs.GameplayCode.GDDealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95955Objects3Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects3[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects3[k] = gdjs.GameplayCode.GDButton_95CloseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects3[k] = gdjs.GameplayCode.GDButton_95AddObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects3[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects3[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects3[k] = gdjs.GameplayCode.GDLevel_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects3[k] = gdjs.GameplayCode.GDInfo_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects3[k] = gdjs.GameplayCode.GDPrice_95MIFObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects3[k] = gdjs.GameplayCode.GDButton_95Close_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects3[k] = gdjs.GameplayCode.GDButton_95Add_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects3[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects3[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects3[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects3[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11648924);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
/* Reuse gdjs.GameplayCode.GDDealershipObjects3 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects3Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects3[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects2Objects = Hashtable.newFrom({"House_6": gdjs.GameplayCode.GDHouse_956Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2, "Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2, "Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Add"), gdjs.GameplayCode.GDButton_95AddObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Add_2"), gdjs.GameplayCode.GDButton_95Add_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close"), gdjs.GameplayCode.GDButton_95CloseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Button_Close_2"), gdjs.GameplayCode.GDButton_95Close_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dealership_Thumbnail"), gdjs.GameplayCode.GDDealership_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("House_6"), gdjs.GameplayCode.GDHouse_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Info_MIF"), gdjs.GameplayCode.GDInfo_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_MIF"), gdjs.GameplayCode.GDLevel_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("MIF_Thumbnail"), gdjs.GameplayCode.GDMIF_95ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached"), gdjs.GameplayCode.GDMaxLevelReachedObjects2);
gdjs.copyArray(runtimeScene.getObjects("MaxLevelReached_2"), gdjs.GameplayCode.GDMaxLevelReached_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_MIF"), gdjs.GameplayCode.GDPrice_95MIFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar"), gdjs.GameplayCode.GDUpgrade_95BarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Bar_2"), gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency"), gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Transparency_2"), gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI"), gdjs.GameplayCode.GDUpgrade_95UIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrade_UI_2"), gdjs.GameplayCode.GDUpgrade_95UI_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealershipObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDDealershipObjects2[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealershipObjects2[k] = gdjs.GameplayCode.GDDealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealershipObjects2.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHouse_95956Objects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 6;
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UIObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UIObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UIObjects2[k] = gdjs.GameplayCode.GDUpgrade_95UIObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95CloseObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95CloseObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95CloseObjects2[k] = gdjs.GameplayCode.GDButton_95CloseObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95CloseObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95AddObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95AddObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95AddObjects2[k] = gdjs.GameplayCode.GDButton_95AddObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95AddObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95BarObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95BarObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95BarObjects2[k] = gdjs.GameplayCode.GDUpgrade_95BarObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95BarObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReachedObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReachedObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReachedObjects2[k] = gdjs.GameplayCode.GDMaxLevelReachedObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReachedObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[k] = gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95MIFObjects2[k] = gdjs.GameplayCode.GDLevel_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDMIF_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95MIFObjects2[k] = gdjs.GameplayCode.GDInfo_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95MIFObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95MIFObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95MIFObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition5IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95MIFObjects2[k] = gdjs.GameplayCode.GDPrice_95MIFObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95MIFObjects2.length = k;}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95UI_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Close_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Close_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Close_952Objects2[k] = gdjs.GameplayCode.GDButton_95Close_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Close_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDButton_95Add_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDButton_95Add_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDButton_95Add_952Objects2[k] = gdjs.GameplayCode.GDButton_95Add_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDButton_95Add_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[k] = gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDMaxLevelReached_952Objects2[k] = gdjs.GameplayCode.GDMaxLevelReached_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDLevel_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDLevel_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDLevel_95DealershipObjects2[k] = gdjs.GameplayCode.GDLevel_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDLevel_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[k] = gdjs.GameplayCode.GDDealership_95ThumbnailObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDInfo_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDInfo_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDInfo_95DealershipObjects2[k] = gdjs.GameplayCode.GDInfo_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDInfo_95DealershipObjects2.length = k;for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPrice_95DealershipObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPrice_95DealershipObjects2[i].isVisible()) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPrice_95DealershipObjects2[k] = gdjs.GameplayCode.GDPrice_95DealershipObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPrice_95DealershipObjects2.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11654700);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_1"), gdjs.GameplayCode.GDCar_95Type_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2);
/* Reuse gdjs.GameplayCode.GDDealershipObjects2 */
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = 0;

gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Car horn sound effect (Copyright Free).mp3", 1, false, 25, 1);
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2ObjectsGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, "Car_Dealership_" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), 505, 200, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(-(150), 0, 1);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(3);
}
for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_951Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects2[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_MIF"), gdjs.GameplayCode.GDCar_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Dealership"), gdjs.GameplayCode.GDCollider_95DealershipObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11617236);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95MIFObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95MIFObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_MIF"), gdjs.GameplayCode.GDCar_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Dealership"), gdjs.GameplayCode.GDCollider_95DealershipObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 2;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11619812);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95MIFObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95MIFObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].setAnimation(gdjs.randomInRange(0, 1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_MIF"), gdjs.GameplayCode.GDCar_95MIFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Dealership"), gdjs.GameplayCode.GDCollider_95DealershipObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595MIFObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DealershipObjects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 3;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11622884);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95MIFObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dealership"), gdjs.GameplayCode.GDDealershipObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDDealershipObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDDealershipObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95MIFObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95MIFObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].setAnimation(gdjs.randomInRange(0, 2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].isVisible() ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HouseNum_Top"), gdjs.GameplayCode.GDHouseNum_95TopObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDHouseNum_95TopObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouseNum_95TopObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHouseNum_95TopObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouseNum_95TopObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Type_Choose"), gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i].isVisible()) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[k] = gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HouseNum_Top"), gdjs.GameplayCode.GDHouseNum_95TopObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDHouseNum_95TopObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHouseNum_95TopObjects3[i].hide();
}
}}

}


{



}


{


gdjs.GameplayCode.eventsList43(runtimeScene);
}


{


gdjs.GameplayCode.eventsList44(runtimeScene);
}


{


gdjs.GameplayCode.eventsList45(runtimeScene);
}


{


gdjs.GameplayCode.eventsList46(runtimeScene);
}


{


gdjs.GameplayCode.eventsList47(runtimeScene);
}


{


gdjs.GameplayCode.eventsList48(runtimeScene);
}


};gdjs.GameplayCode.eventsList50 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11660532);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(500);
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects2[i].setBBText("Level 2");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects2[i].setBBText("500 M");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects2[i].setBBText("Unlocks SUV (2x Money)");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 2;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11663468);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects2);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(10000);
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects2[i].setPosition(212,812);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects2[i].setBBText("Level 3");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects2[i].setBBText("10 T");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects2[i].setBBText("Unlocks Sedan (3x Money)");
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 3;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11666660);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_Type_2"), gdjs.GameplayCode.GDCar_95Type_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Car_Type_3"), gdjs.GameplayCode.GDCar_95Type_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Info_Dealership"), gdjs.GameplayCode.GDInfo_95DealershipObjects1);
gdjs.copyArray(runtimeScene.getObjects("Level_Dealership"), gdjs.GameplayCode.GDLevel_95DealershipObjects1);
gdjs.copyArray(runtimeScene.getObjects("Price_Dealership"), gdjs.GameplayCode.GDPrice_95DealershipObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_952Objects1[i].setPosition(212,812);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Type_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Type_953Objects1[i].setPosition(362,812);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLevel_95DealershipObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLevel_95DealershipObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDInfo_95DealershipObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDInfo_95DealershipObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPrice_95DealershipObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPrice_95DealershipObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.eventsList51 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList49(runtimeScene);
}


{


gdjs.GameplayCode.eventsList50(runtimeScene);
}


};gdjs.GameplayCode.eventsList52 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList26(runtimeScene);
}


{


gdjs.GameplayCode.eventsList41(runtimeScene);
}


{


gdjs.GameplayCode.eventsList42(runtimeScene);
}


{


gdjs.GameplayCode.eventsList51(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects3Objects = Hashtable.newFrom({"Collider_Left": gdjs.GameplayCode.GDCollider_95LeftObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DownObjects3Objects = Hashtable.newFrom({"Collider_Down": gdjs.GameplayCode.GDCollider_95DownObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects3Objects = Hashtable.newFrom({"Collider_Right": gdjs.GameplayCode.GDCollider_95RightObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects3Objects = Hashtable.newFrom({"Collider_Up": gdjs.GameplayCode.GDCollider_95UpObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects2Objects = Hashtable.newFrom({"Car_House": gdjs.GameplayCode.GDCar_95HouseObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects2Objects = Hashtable.newFrom({"Collider_MIF": gdjs.GameplayCode.GDCollider_95MIFObjects2});
gdjs.GameplayCode.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Left"), gdjs.GameplayCode.GDCollider_95LeftObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down"), gdjs.GameplayCode.GDCollider_95DownObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595DownObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].addForce(0, 150, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Right"), gdjs.GameplayCode.GDCollider_95RightObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].addForce(150, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_Up"), gdjs.GameplayCode.GDCollider_95UpObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects3[i].addForce(0, -(150), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_House"), gdjs.GameplayCode.GDCar_95HouseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_MIF"), gdjs.GameplayCode.GDCollider_95MIFObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595HouseObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595MIFObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95HouseObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95HouseObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95HouseObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects = Hashtable.newFrom({"Collider_Left": gdjs.GameplayCode.GDCollider_95LeftObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects = Hashtable.newFrom({"Collider_Down_Dealer": gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects = Hashtable.newFrom({"Collider_Right": gdjs.GameplayCode.GDCollider_95RightObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects = Hashtable.newFrom({"Collider_Up": gdjs.GameplayCode.GDCollider_95UpObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects3Objects = Hashtable.newFrom({"Collider_House_1": gdjs.GameplayCode.GDCollider_95House_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects3Objects = Hashtable.newFrom({"Collider_House_2": gdjs.GameplayCode.GDCollider_95House_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects3Objects = Hashtable.newFrom({"Collider_House_3": gdjs.GameplayCode.GDCollider_95House_953Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects3Objects = Hashtable.newFrom({"Collider_House_4": gdjs.GameplayCode.GDCollider_95House_954Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects3Objects = Hashtable.newFrom({"Collider_House_5": gdjs.GameplayCode.GDCollider_95House_955Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects = Hashtable.newFrom({"Car_Dealership_1": gdjs.GameplayCode.GDCar_95Dealership_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects2Objects = Hashtable.newFrom({"Collider_House_6": gdjs.GameplayCode.GDCollider_95House_956Objects2});
gdjs.GameplayCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_1"), gdjs.GameplayCode.GDCollider_95House_951Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_2"), gdjs.GameplayCode.GDCollider_95House_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_3"), gdjs.GameplayCode.GDCollider_95House_953Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_4"), gdjs.GameplayCode.GDCollider_95House_954Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_5"), gdjs.GameplayCode.GDCollider_95House_955Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_6"), gdjs.GameplayCode.GDCollider_95House_956Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 6;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(1);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects = Hashtable.newFrom({"Collider_Left": gdjs.GameplayCode.GDCollider_95LeftObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects = Hashtable.newFrom({"Collider_Down_Dealer": gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects = Hashtable.newFrom({"Collider_Right": gdjs.GameplayCode.GDCollider_95RightObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects = Hashtable.newFrom({"Collider_Up": gdjs.GameplayCode.GDCollider_95UpObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects3Objects = Hashtable.newFrom({"Collider_House_1": gdjs.GameplayCode.GDCollider_95House_951Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects3Objects = Hashtable.newFrom({"Collider_House_2": gdjs.GameplayCode.GDCollider_95House_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects3Objects = Hashtable.newFrom({"Collider_House_3": gdjs.GameplayCode.GDCollider_95House_953Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects3Objects = Hashtable.newFrom({"Collider_House_4": gdjs.GameplayCode.GDCollider_95House_954Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects3Objects = Hashtable.newFrom({"Collider_House_5": gdjs.GameplayCode.GDCollider_95House_955Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects = Hashtable.newFrom({"Car_Dealership_2": gdjs.GameplayCode.GDCar_95Dealership_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects2Objects = Hashtable.newFrom({"Collider_House_6": gdjs.GameplayCode.GDCollider_95House_956Objects2});
gdjs.GameplayCode.eventsList55 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_1"), gdjs.GameplayCode.GDCollider_95House_951Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_2"), gdjs.GameplayCode.GDCollider_95House_952Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_3"), gdjs.GameplayCode.GDCollider_95House_953Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_4"), gdjs.GameplayCode.GDCollider_95House_954Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_5"), gdjs.GameplayCode.GDCollider_95House_955Objects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_6"), gdjs.GameplayCode.GDCollider_95House_956Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 6;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(1);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects = Hashtable.newFrom({"Collider_Left": gdjs.GameplayCode.GDCollider_95LeftObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects = Hashtable.newFrom({"Collider_Down_Dealer": gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects = Hashtable.newFrom({"Collider_Right": gdjs.GameplayCode.GDCollider_95RightObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects = Hashtable.newFrom({"Collider_Up": gdjs.GameplayCode.GDCollider_95UpObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects2Objects = Hashtable.newFrom({"Collider_House_1": gdjs.GameplayCode.GDCollider_95House_951Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects2Objects = Hashtable.newFrom({"Collider_House_2": gdjs.GameplayCode.GDCollider_95House_952Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects2Objects = Hashtable.newFrom({"Collider_House_3": gdjs.GameplayCode.GDCollider_95House_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects2Objects = Hashtable.newFrom({"Collider_House_4": gdjs.GameplayCode.GDCollider_95House_954Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects2Objects = Hashtable.newFrom({"Collider_House_5": gdjs.GameplayCode.GDCollider_95House_955Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects1Objects = Hashtable.newFrom({"Car_Dealership_3": gdjs.GameplayCode.GDCar_95Dealership_953Objects1});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects1Objects = Hashtable.newFrom({"Collider_House_6": gdjs.GameplayCode.GDCollider_95House_956Objects1});
gdjs.GameplayCode.eventsList56 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_1"), gdjs.GameplayCode.GDCollider_95House_951Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95951Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_2"), gdjs.GameplayCode.GDCollider_95House_952Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95952Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_3"), gdjs.GameplayCode.GDCollider_95House_953Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95953Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_4"), gdjs.GameplayCode.GDCollider_95House_954Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95954Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_5"), gdjs.GameplayCode.GDCollider_95House_955Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95955Objects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(-(150), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Collider_House_6"), gdjs.GameplayCode.GDCollider_95House_956Objects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595House_95956Objects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 6;
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects1 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects1[i].setVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects1[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects1[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects1[i].setAnimation(1);
}
}}

}


};gdjs.GameplayCode.eventsList57 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.eventsList53(runtimeScene);
}


{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car_MIF"), gdjs.GameplayCode.GDCar_95MIFObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95MIFObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95MIFObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Left"), gdjs.GameplayCode.GDCollider_95LeftObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_951Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down_Dealer"), gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_951Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(0, 150, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Right"), gdjs.GameplayCode.GDCollider_95RightObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_951Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(150, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_1"), gdjs.GameplayCode.GDCar_95Dealership_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Up"), gdjs.GameplayCode.GDCollider_95UpObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95951Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_951Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_951Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_951Objects2[i].addForce(0, -(150), 1);
}
}}

}


{


gdjs.GameplayCode.eventsList54(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Left"), gdjs.GameplayCode.GDCollider_95LeftObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_952Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down_Dealer"), gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_952Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(0, 150, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Right"), gdjs.GameplayCode.GDCollider_95RightObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_952Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(150, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_2"), gdjs.GameplayCode.GDCar_95Dealership_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Up"), gdjs.GameplayCode.GDCollider_95UpObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95952Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_952Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_952Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_952Objects2[i].addForce(0, -(150), 1);
}
}}

}


{


gdjs.GameplayCode.eventsList55(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Left"), gdjs.GameplayCode.GDCollider_95LeftObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595LeftObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_953Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Down_Dealer"), gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595Down_9595DealerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_953Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(0, 150, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Right"), gdjs.GameplayCode.GDCollider_95RightObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595RightObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_953Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(150, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car_Dealership_3"), gdjs.GameplayCode.GDCar_95Dealership_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Collider_Up"), gdjs.GameplayCode.GDCollider_95UpObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCar_9595Dealership_95953Objects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollider_9595UpObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariableBoolean(gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDCar_95Dealership_953Objects2[k] = gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDCar_95Dealership_953Objects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCar_95Dealership_953Objects2[i].addForce(0, -(150), 1);
}
}}

}


{


gdjs.GameplayCode.eventsList56(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects2});
gdjs.GameplayCode.asyncCallback11673212 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects3);

{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects3[i].setAnimation(0);
}
}}
gdjs.GameplayCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDVolumeObjects2) asyncObjectsList.addObject("Volume", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11673212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects1Objects = Hashtable.newFrom({"Volume": gdjs.GameplayCode.GDVolumeObjects1});
gdjs.GameplayCode.asyncCallback11676900 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].setAnimation(1);
}
}}
gdjs.GameplayCode.eventsList59 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDVolumeObjects1) asyncObjectsList.addObject("Volume", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback11676900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList60 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Shuffliin-Through-Central-Park.mp3", 1, true, 100, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDVolumeObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDVolumeObjects2[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDVolumeObjects2[k] = gdjs.GameplayCode.GDVolumeObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDVolumeObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11671452);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDVolumeObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDVolumeObjects2[i].getAnimation() == 1 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDVolumeObjects2[k] = gdjs.GameplayCode.GDVolumeObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDVolumeObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11672532);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList58(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDVolumeObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDVolumeObjects2[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDVolumeObjects2[k] = gdjs.GameplayCode.GDVolumeObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDVolumeObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11674508);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects2Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Volume"), gdjs.GameplayCode.GDVolumeObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVolumeObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDVolumeObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDVolumeObjects1[i].getAnimation() == 0 ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDVolumeObjects1[k] = gdjs.GameplayCode.GDVolumeObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDVolumeObjects1.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11676220);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDVolumeObjects1 */
{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects1[i].getBehavior("Tween").addObjectScaleTween("Down", 0.5, 0.5, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDVolumeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDVolumeObjects1[i].getBehavior("Tween").addObjectScaleTween("Up", 0.667, 0.667, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList59(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList61 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList0(runtimeScene);
}


{


gdjs.GameplayCode.eventsList2(runtimeScene);
}


{


gdjs.GameplayCode.eventsList4(runtimeScene);
}


{


gdjs.GameplayCode.eventsList18(runtimeScene);
}


{


gdjs.GameplayCode.eventsList23(runtimeScene);
}


{


gdjs.GameplayCode.eventsList52(runtimeScene);
}


{


gdjs.GameplayCode.eventsList57(runtimeScene);
}


{


gdjs.GameplayCode.eventsList60(runtimeScene);
}


{



}


};

gdjs.GameplayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameplayCode.GDUpgrade_95UIObjects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95UIObjects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95UIObjects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95UIObjects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95UIObjects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95UIObjects6.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95UI_952Objects6.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95TransparencyObjects6.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95Transparency_952Objects6.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects1.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects2.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects3.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects4.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects5.length = 0;
gdjs.GameplayCode.GDButton_95CloseObjects6.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects1.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects2.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects3.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects4.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects5.length = 0;
gdjs.GameplayCode.GDButton_95Close_952Objects6.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects1.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects2.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects3.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects4.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects5.length = 0;
gdjs.GameplayCode.GDButton_95AddObjects6.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects1.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects2.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects3.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects4.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects5.length = 0;
gdjs.GameplayCode.GDButton_95Add_952Objects6.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95BarObjects6.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects1.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects2.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects3.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects4.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects5.length = 0;
gdjs.GameplayCode.GDUpgrade_95Bar_952Objects6.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects1.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects2.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects3.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects4.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects5.length = 0;
gdjs.GameplayCode.GDMaxLevelReachedObjects6.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects1.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects2.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects3.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects4.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects5.length = 0;
gdjs.GameplayCode.GDMaxLevelReached_952Objects6.length = 0;
gdjs.GameplayCode.GDMIFObjects1.length = 0;
gdjs.GameplayCode.GDMIFObjects2.length = 0;
gdjs.GameplayCode.GDMIFObjects3.length = 0;
gdjs.GameplayCode.GDMIFObjects4.length = 0;
gdjs.GameplayCode.GDMIFObjects5.length = 0;
gdjs.GameplayCode.GDMIFObjects6.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects1.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects2.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects3.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects4.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects5.length = 0;
gdjs.GameplayCode.GDMIF_95ThumbnailObjects6.length = 0;
gdjs.GameplayCode.GDDealershipObjects1.length = 0;
gdjs.GameplayCode.GDDealershipObjects2.length = 0;
gdjs.GameplayCode.GDDealershipObjects3.length = 0;
gdjs.GameplayCode.GDDealershipObjects4.length = 0;
gdjs.GameplayCode.GDDealershipObjects5.length = 0;
gdjs.GameplayCode.GDDealershipObjects6.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects1.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects2.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects3.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects4.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects5.length = 0;
gdjs.GameplayCode.GDDealership_95ThumbnailObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95FinishObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_951Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_952Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_953Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_954Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_955Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects1.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects2.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects3.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects4.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects5.length = 0;
gdjs.GameplayCode.GDCollider_95House_956Objects6.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95MIFObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95DealershipObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95UpObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95DownObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95Down_95DealerObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95LeftObjects6.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects1.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects2.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects3.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects4.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects5.length = 0;
gdjs.GameplayCode.GDCollider_95RightObjects6.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects1.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects2.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects3.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects4.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects5.length = 0;
gdjs.GameplayCode.GDCar_95HouseObjects6.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects1.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects2.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects3.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects4.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects5.length = 0;
gdjs.GameplayCode.GDCar_95MIFObjects6.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_951Objects6.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_952Objects6.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Dealership_953Objects6.length = 0;
gdjs.GameplayCode.GDHouse_951Objects1.length = 0;
gdjs.GameplayCode.GDHouse_951Objects2.length = 0;
gdjs.GameplayCode.GDHouse_951Objects3.length = 0;
gdjs.GameplayCode.GDHouse_951Objects4.length = 0;
gdjs.GameplayCode.GDHouse_951Objects5.length = 0;
gdjs.GameplayCode.GDHouse_951Objects6.length = 0;
gdjs.GameplayCode.GDHouse_952Objects1.length = 0;
gdjs.GameplayCode.GDHouse_952Objects2.length = 0;
gdjs.GameplayCode.GDHouse_952Objects3.length = 0;
gdjs.GameplayCode.GDHouse_952Objects4.length = 0;
gdjs.GameplayCode.GDHouse_952Objects5.length = 0;
gdjs.GameplayCode.GDHouse_952Objects6.length = 0;
gdjs.GameplayCode.GDHouse_953Objects1.length = 0;
gdjs.GameplayCode.GDHouse_953Objects2.length = 0;
gdjs.GameplayCode.GDHouse_953Objects3.length = 0;
gdjs.GameplayCode.GDHouse_953Objects4.length = 0;
gdjs.GameplayCode.GDHouse_953Objects5.length = 0;
gdjs.GameplayCode.GDHouse_953Objects6.length = 0;
gdjs.GameplayCode.GDHouse_954Objects1.length = 0;
gdjs.GameplayCode.GDHouse_954Objects2.length = 0;
gdjs.GameplayCode.GDHouse_954Objects3.length = 0;
gdjs.GameplayCode.GDHouse_954Objects4.length = 0;
gdjs.GameplayCode.GDHouse_954Objects5.length = 0;
gdjs.GameplayCode.GDHouse_954Objects6.length = 0;
gdjs.GameplayCode.GDHouse_955Objects1.length = 0;
gdjs.GameplayCode.GDHouse_955Objects2.length = 0;
gdjs.GameplayCode.GDHouse_955Objects3.length = 0;
gdjs.GameplayCode.GDHouse_955Objects4.length = 0;
gdjs.GameplayCode.GDHouse_955Objects5.length = 0;
gdjs.GameplayCode.GDHouse_955Objects6.length = 0;
gdjs.GameplayCode.GDHouse_956Objects1.length = 0;
gdjs.GameplayCode.GDHouse_956Objects2.length = 0;
gdjs.GameplayCode.GDHouse_956Objects3.length = 0;
gdjs.GameplayCode.GDHouse_956Objects4.length = 0;
gdjs.GameplayCode.GDHouse_956Objects5.length = 0;
gdjs.GameplayCode.GDHouse_956Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_951Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_952Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_953Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_954Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_955Objects6.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects1.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects2.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects3.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects4.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects5.length = 0;
gdjs.GameplayCode.GDCountdown_95House_956Objects6.length = 0;
gdjs.GameplayCode.GDMoneyObjects1.length = 0;
gdjs.GameplayCode.GDMoneyObjects2.length = 0;
gdjs.GameplayCode.GDMoneyObjects3.length = 0;
gdjs.GameplayCode.GDMoneyObjects4.length = 0;
gdjs.GameplayCode.GDMoneyObjects5.length = 0;
gdjs.GameplayCode.GDMoneyObjects6.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects1.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects2.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects3.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects4.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects5.length = 0;
gdjs.GameplayCode.GDInfo_95MIFObjects6.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects1.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects2.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects3.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects4.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects5.length = 0;
gdjs.GameplayCode.GDLevel_95MIFObjects6.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects1.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects2.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects3.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects4.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects5.length = 0;
gdjs.GameplayCode.GDPrice_95MIFObjects6.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects1.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects2.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects3.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects4.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects5.length = 0;
gdjs.GameplayCode.GDInfo_95DealershipObjects6.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects1.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects2.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects3.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects4.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects5.length = 0;
gdjs.GameplayCode.GDLevel_95DealershipObjects6.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects1.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects2.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects3.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects4.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects5.length = 0;
gdjs.GameplayCode.GDPrice_95DealershipObjects6.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Type_951Objects6.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Type_952Objects6.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects1.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects2.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects3.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects4.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects5.length = 0;
gdjs.GameplayCode.GDCar_95Type_953Objects6.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects1.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects2.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects3.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects4.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects5.length = 0;
gdjs.GameplayCode.GDCar_95Type_95ChooseObjects6.length = 0;
gdjs.GameplayCode.GDRoad_951Objects1.length = 0;
gdjs.GameplayCode.GDRoad_951Objects2.length = 0;
gdjs.GameplayCode.GDRoad_951Objects3.length = 0;
gdjs.GameplayCode.GDRoad_951Objects4.length = 0;
gdjs.GameplayCode.GDRoad_951Objects5.length = 0;
gdjs.GameplayCode.GDRoad_951Objects6.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects1.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects2.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects3.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects4.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects5.length = 0;
gdjs.GameplayCode.GDRoad_9511Objects6.length = 0;
gdjs.GameplayCode.GDRoad_952Objects1.length = 0;
gdjs.GameplayCode.GDRoad_952Objects2.length = 0;
gdjs.GameplayCode.GDRoad_952Objects3.length = 0;
gdjs.GameplayCode.GDRoad_952Objects4.length = 0;
gdjs.GameplayCode.GDRoad_952Objects5.length = 0;
gdjs.GameplayCode.GDRoad_952Objects6.length = 0;
gdjs.GameplayCode.GDRoad_953Objects1.length = 0;
gdjs.GameplayCode.GDRoad_953Objects2.length = 0;
gdjs.GameplayCode.GDRoad_953Objects3.length = 0;
gdjs.GameplayCode.GDRoad_953Objects4.length = 0;
gdjs.GameplayCode.GDRoad_953Objects5.length = 0;
gdjs.GameplayCode.GDRoad_953Objects6.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects1.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects2.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects3.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects4.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects5.length = 0;
gdjs.GameplayCode.GDRoad_9533Objects6.length = 0;
gdjs.GameplayCode.GDRoad_954Objects1.length = 0;
gdjs.GameplayCode.GDRoad_954Objects2.length = 0;
gdjs.GameplayCode.GDRoad_954Objects3.length = 0;
gdjs.GameplayCode.GDRoad_954Objects4.length = 0;
gdjs.GameplayCode.GDRoad_954Objects5.length = 0;
gdjs.GameplayCode.GDRoad_954Objects6.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects1.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects2.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects3.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects4.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects5.length = 0;
gdjs.GameplayCode.GDApartment_95DecoObjects6.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects1.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects2.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects3.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects4.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects5.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_952Objects6.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects1.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects2.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects3.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects4.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects5.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_953Objects6.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects1.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects2.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects3.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects4.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects5.length = 0;
gdjs.GameplayCode.GDApartment_95Deco_954Objects6.length = 0;
gdjs.GameplayCode.GDRiverObjects1.length = 0;
gdjs.GameplayCode.GDRiverObjects2.length = 0;
gdjs.GameplayCode.GDRiverObjects3.length = 0;
gdjs.GameplayCode.GDRiverObjects4.length = 0;
gdjs.GameplayCode.GDRiverObjects5.length = 0;
gdjs.GameplayCode.GDRiverObjects6.length = 0;
gdjs.GameplayCode.GDBGObjects1.length = 0;
gdjs.GameplayCode.GDBGObjects2.length = 0;
gdjs.GameplayCode.GDBGObjects3.length = 0;
gdjs.GameplayCode.GDBGObjects4.length = 0;
gdjs.GameplayCode.GDBGObjects5.length = 0;
gdjs.GameplayCode.GDBGObjects6.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects1.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects2.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects3.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects4.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects5.length = 0;
gdjs.GameplayCode.GDTennis_95CourtObjects6.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects1.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects2.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects3.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects4.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects5.length = 0;
gdjs.GameplayCode.GDUI_95BarObjects6.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects1.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects2.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects3.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects4.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects5.length = 0;
gdjs.GameplayCode.GDBottom_95BarObjects6.length = 0;
gdjs.GameplayCode.GDReady6Objects1.length = 0;
gdjs.GameplayCode.GDReady6Objects2.length = 0;
gdjs.GameplayCode.GDReady6Objects3.length = 0;
gdjs.GameplayCode.GDReady6Objects4.length = 0;
gdjs.GameplayCode.GDReady6Objects5.length = 0;
gdjs.GameplayCode.GDReady6Objects6.length = 0;
gdjs.GameplayCode.GDReady5Objects1.length = 0;
gdjs.GameplayCode.GDReady5Objects2.length = 0;
gdjs.GameplayCode.GDReady5Objects3.length = 0;
gdjs.GameplayCode.GDReady5Objects4.length = 0;
gdjs.GameplayCode.GDReady5Objects5.length = 0;
gdjs.GameplayCode.GDReady5Objects6.length = 0;
gdjs.GameplayCode.GDReady4Objects1.length = 0;
gdjs.GameplayCode.GDReady4Objects2.length = 0;
gdjs.GameplayCode.GDReady4Objects3.length = 0;
gdjs.GameplayCode.GDReady4Objects4.length = 0;
gdjs.GameplayCode.GDReady4Objects5.length = 0;
gdjs.GameplayCode.GDReady4Objects6.length = 0;
gdjs.GameplayCode.GDReady3Objects1.length = 0;
gdjs.GameplayCode.GDReady3Objects2.length = 0;
gdjs.GameplayCode.GDReady3Objects3.length = 0;
gdjs.GameplayCode.GDReady3Objects4.length = 0;
gdjs.GameplayCode.GDReady3Objects5.length = 0;
gdjs.GameplayCode.GDReady3Objects6.length = 0;
gdjs.GameplayCode.GDReady2Objects1.length = 0;
gdjs.GameplayCode.GDReady2Objects2.length = 0;
gdjs.GameplayCode.GDReady2Objects3.length = 0;
gdjs.GameplayCode.GDReady2Objects4.length = 0;
gdjs.GameplayCode.GDReady2Objects5.length = 0;
gdjs.GameplayCode.GDReady2Objects6.length = 0;
gdjs.GameplayCode.GDReady1Objects1.length = 0;
gdjs.GameplayCode.GDReady1Objects2.length = 0;
gdjs.GameplayCode.GDReady1Objects3.length = 0;
gdjs.GameplayCode.GDReady1Objects4.length = 0;
gdjs.GameplayCode.GDReady1Objects5.length = 0;
gdjs.GameplayCode.GDReady1Objects6.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects1.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects2.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects3.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects4.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects5.length = 0;
gdjs.GameplayCode.GDHouseNum_95TopObjects6.length = 0;
gdjs.GameplayCode.GDHouseNumObjects1.length = 0;
gdjs.GameplayCode.GDHouseNumObjects2.length = 0;
gdjs.GameplayCode.GDHouseNumObjects3.length = 0;
gdjs.GameplayCode.GDHouseNumObjects4.length = 0;
gdjs.GameplayCode.GDHouseNumObjects5.length = 0;
gdjs.GameplayCode.GDHouseNumObjects6.length = 0;
gdjs.GameplayCode.GDOneObjects1.length = 0;
gdjs.GameplayCode.GDOneObjects2.length = 0;
gdjs.GameplayCode.GDOneObjects3.length = 0;
gdjs.GameplayCode.GDOneObjects4.length = 0;
gdjs.GameplayCode.GDOneObjects5.length = 0;
gdjs.GameplayCode.GDOneObjects6.length = 0;
gdjs.GameplayCode.GDVolumeObjects1.length = 0;
gdjs.GameplayCode.GDVolumeObjects2.length = 0;
gdjs.GameplayCode.GDVolumeObjects3.length = 0;
gdjs.GameplayCode.GDVolumeObjects4.length = 0;
gdjs.GameplayCode.GDVolumeObjects5.length = 0;
gdjs.GameplayCode.GDVolumeObjects6.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects1.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects2.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects3.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects4.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects5.length = 0;
gdjs.GameplayCode.GDTutorial_95ButtonObjects6.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects1.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects3.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects4.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects5.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects6.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects1.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects2.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects3.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects4.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects5.length = 0;
gdjs.GameplayCode.GDArrow_95RightObjects6.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects1.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects2.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects3.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects4.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects5.length = 0;
gdjs.GameplayCode.GDArrow_95LeftObjects6.length = 0;

gdjs.GameplayCode.eventsList61(runtimeScene);
return;

}

gdjs['GameplayCode'] = gdjs.GameplayCode;
