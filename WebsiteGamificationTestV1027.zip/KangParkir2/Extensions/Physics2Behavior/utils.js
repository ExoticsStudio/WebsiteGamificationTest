var gdjs;(function(o){let t;(function(n){n.computeCurrentContactsFromStartedAndEndedContacts=(a,c,p)=>{c.forEach(e=>{a.push(e)}),p.forEach(e=>{const r=a.indexOf(e);r!==-1&&a.splice(r,1)})}})(t=o.physics2||(o.physics2={}))})(gdjs||(gdjs={}));
//# sourceMappingURL=utils.js.map
