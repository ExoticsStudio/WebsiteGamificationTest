gdjs.GameplayCode = {};
gdjs.GameplayCode.GDBatuObjects2_2final = [];

gdjs.GameplayCode.GDBotolObjects2_2final = [];

gdjs.GameplayCode.GDCollisionObjects2_2final = [];

gdjs.GameplayCode.GDFeeshObjects2_2final = [];

gdjs.GameplayCode.GDHookObjects2_2final = [];

gdjs.GameplayCode.forEachIndex2 = 0;

gdjs.GameplayCode.forEachIndex3 = 0;

gdjs.GameplayCode.forEachObjects2 = [];

gdjs.GameplayCode.forEachObjects3 = [];

gdjs.GameplayCode.forEachTemporary2 = null;

gdjs.GameplayCode.forEachTemporary3 = null;

gdjs.GameplayCode.forEachTotalCount2 = 0;

gdjs.GameplayCode.forEachTotalCount3 = 0;

gdjs.GameplayCode.GDKapalObjects1= [];
gdjs.GameplayCode.GDKapalObjects2= [];
gdjs.GameplayCode.GDKapalObjects3= [];
gdjs.GameplayCode.GDKapalObjects4= [];
gdjs.GameplayCode.GDKapalObjects5= [];
gdjs.GameplayCode.GDKapalObjects6= [];
gdjs.GameplayCode.GDHookObjects1= [];
gdjs.GameplayCode.GDHookObjects2= [];
gdjs.GameplayCode.GDHookObjects3= [];
gdjs.GameplayCode.GDHookObjects4= [];
gdjs.GameplayCode.GDHookObjects5= [];
gdjs.GameplayCode.GDHookObjects6= [];
gdjs.GameplayCode.GDCollisionObjects1= [];
gdjs.GameplayCode.GDCollisionObjects2= [];
gdjs.GameplayCode.GDCollisionObjects3= [];
gdjs.GameplayCode.GDCollisionObjects4= [];
gdjs.GameplayCode.GDCollisionObjects5= [];
gdjs.GameplayCode.GDCollisionObjects6= [];
gdjs.GameplayCode.GDStringObjects1= [];
gdjs.GameplayCode.GDStringObjects2= [];
gdjs.GameplayCode.GDStringObjects3= [];
gdjs.GameplayCode.GDStringObjects4= [];
gdjs.GameplayCode.GDStringObjects5= [];
gdjs.GameplayCode.GDStringObjects6= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects1= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects2= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects3= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects4= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects5= [];
gdjs.GameplayCode.GDHookAngleDetectorObjects6= [];
gdjs.GameplayCode.GDBotolObjects1= [];
gdjs.GameplayCode.GDBotolObjects2= [];
gdjs.GameplayCode.GDBotolObjects3= [];
gdjs.GameplayCode.GDBotolObjects4= [];
gdjs.GameplayCode.GDBotolObjects5= [];
gdjs.GameplayCode.GDBotolObjects6= [];
gdjs.GameplayCode.GDBotol2Objects1= [];
gdjs.GameplayCode.GDBotol2Objects2= [];
gdjs.GameplayCode.GDBotol2Objects3= [];
gdjs.GameplayCode.GDBotol2Objects4= [];
gdjs.GameplayCode.GDBotol2Objects5= [];
gdjs.GameplayCode.GDBotol2Objects6= [];
gdjs.GameplayCode.GDBatuObjects1= [];
gdjs.GameplayCode.GDBatuObjects2= [];
gdjs.GameplayCode.GDBatuObjects3= [];
gdjs.GameplayCode.GDBatuObjects4= [];
gdjs.GameplayCode.GDBatuObjects5= [];
gdjs.GameplayCode.GDBatuObjects6= [];
gdjs.GameplayCode.GDBatu2Objects1= [];
gdjs.GameplayCode.GDBatu2Objects2= [];
gdjs.GameplayCode.GDBatu2Objects3= [];
gdjs.GameplayCode.GDBatu2Objects4= [];
gdjs.GameplayCode.GDBatu2Objects5= [];
gdjs.GameplayCode.GDBatu2Objects6= [];
gdjs.GameplayCode.GDFeeshObjects1= [];
gdjs.GameplayCode.GDFeeshObjects2= [];
gdjs.GameplayCode.GDFeeshObjects3= [];
gdjs.GameplayCode.GDFeeshObjects4= [];
gdjs.GameplayCode.GDFeeshObjects5= [];
gdjs.GameplayCode.GDFeeshObjects6= [];
gdjs.GameplayCode.GDFeesh2Objects1= [];
gdjs.GameplayCode.GDFeesh2Objects2= [];
gdjs.GameplayCode.GDFeesh2Objects3= [];
gdjs.GameplayCode.GDFeesh2Objects4= [];
gdjs.GameplayCode.GDFeesh2Objects5= [];
gdjs.GameplayCode.GDFeesh2Objects6= [];
gdjs.GameplayCode.GDFeesh3Objects1= [];
gdjs.GameplayCode.GDFeesh3Objects2= [];
gdjs.GameplayCode.GDFeesh3Objects3= [];
gdjs.GameplayCode.GDFeesh3Objects4= [];
gdjs.GameplayCode.GDFeesh3Objects5= [];
gdjs.GameplayCode.GDFeesh3Objects6= [];
gdjs.GameplayCode.GDLimitObjects1= [];
gdjs.GameplayCode.GDLimitObjects2= [];
gdjs.GameplayCode.GDLimitObjects3= [];
gdjs.GameplayCode.GDLimitObjects4= [];
gdjs.GameplayCode.GDLimitObjects5= [];
gdjs.GameplayCode.GDLimitObjects6= [];
gdjs.GameplayCode.GDLimitBarObjects1= [];
gdjs.GameplayCode.GDLimitBarObjects2= [];
gdjs.GameplayCode.GDLimitBarObjects3= [];
gdjs.GameplayCode.GDLimitBarObjects4= [];
gdjs.GameplayCode.GDLimitBarObjects5= [];
gdjs.GameplayCode.GDLimitBarObjects6= [];
gdjs.GameplayCode.GDLimitBar2Objects1= [];
gdjs.GameplayCode.GDLimitBar2Objects2= [];
gdjs.GameplayCode.GDLimitBar2Objects3= [];
gdjs.GameplayCode.GDLimitBar2Objects4= [];
gdjs.GameplayCode.GDLimitBar2Objects5= [];
gdjs.GameplayCode.GDLimitBar2Objects6= [];
gdjs.GameplayCode.GDLimitBar3Objects1= [];
gdjs.GameplayCode.GDLimitBar3Objects2= [];
gdjs.GameplayCode.GDLimitBar3Objects3= [];
gdjs.GameplayCode.GDLimitBar3Objects4= [];
gdjs.GameplayCode.GDLimitBar3Objects5= [];
gdjs.GameplayCode.GDLimitBar3Objects6= [];
gdjs.GameplayCode.GDWarningObjects1= [];
gdjs.GameplayCode.GDWarningObjects2= [];
gdjs.GameplayCode.GDWarningObjects3= [];
gdjs.GameplayCode.GDWarningObjects4= [];
gdjs.GameplayCode.GDWarningObjects5= [];
gdjs.GameplayCode.GDWarningObjects6= [];
gdjs.GameplayCode.GDDestroyerObjects1= [];
gdjs.GameplayCode.GDDestroyerObjects2= [];
gdjs.GameplayCode.GDDestroyerObjects3= [];
gdjs.GameplayCode.GDDestroyerObjects4= [];
gdjs.GameplayCode.GDDestroyerObjects5= [];
gdjs.GameplayCode.GDDestroyerObjects6= [];
gdjs.GameplayCode.GDWaveFrontObjects1= [];
gdjs.GameplayCode.GDWaveFrontObjects2= [];
gdjs.GameplayCode.GDWaveFrontObjects3= [];
gdjs.GameplayCode.GDWaveFrontObjects4= [];
gdjs.GameplayCode.GDWaveFrontObjects5= [];
gdjs.GameplayCode.GDWaveFrontObjects6= [];
gdjs.GameplayCode.GDWaveBackObjects1= [];
gdjs.GameplayCode.GDWaveBackObjects2= [];
gdjs.GameplayCode.GDWaveBackObjects3= [];
gdjs.GameplayCode.GDWaveBackObjects4= [];
gdjs.GameplayCode.GDWaveBackObjects5= [];
gdjs.GameplayCode.GDWaveBackObjects6= [];
gdjs.GameplayCode.GDBackgroundObjects1= [];
gdjs.GameplayCode.GDBackgroundObjects2= [];
gdjs.GameplayCode.GDBackgroundObjects3= [];
gdjs.GameplayCode.GDBackgroundObjects4= [];
gdjs.GameplayCode.GDBackgroundObjects5= [];
gdjs.GameplayCode.GDBackgroundObjects6= [];
gdjs.GameplayCode.GDBackgroundAirObjects1= [];
gdjs.GameplayCode.GDBackgroundAirObjects2= [];
gdjs.GameplayCode.GDBackgroundAirObjects3= [];
gdjs.GameplayCode.GDBackgroundAirObjects4= [];
gdjs.GameplayCode.GDBackgroundAirObjects5= [];
gdjs.GameplayCode.GDBackgroundAirObjects6= [];
gdjs.GameplayCode.GDTimerObjects1= [];
gdjs.GameplayCode.GDTimerObjects2= [];
gdjs.GameplayCode.GDTimerObjects3= [];
gdjs.GameplayCode.GDTimerObjects4= [];
gdjs.GameplayCode.GDTimerObjects5= [];
gdjs.GameplayCode.GDTimerObjects6= [];
gdjs.GameplayCode.GDRockObjects1= [];
gdjs.GameplayCode.GDRockObjects2= [];
gdjs.GameplayCode.GDRockObjects3= [];
gdjs.GameplayCode.GDRockObjects4= [];
gdjs.GameplayCode.GDRockObjects5= [];
gdjs.GameplayCode.GDRockObjects6= [];
gdjs.GameplayCode.GDBottleObjects1= [];
gdjs.GameplayCode.GDBottleObjects2= [];
gdjs.GameplayCode.GDBottleObjects3= [];
gdjs.GameplayCode.GDBottleObjects4= [];
gdjs.GameplayCode.GDBottleObjects5= [];
gdjs.GameplayCode.GDBottleObjects6= [];
gdjs.GameplayCode.GDFishObjects1= [];
gdjs.GameplayCode.GDFishObjects2= [];
gdjs.GameplayCode.GDFishObjects3= [];
gdjs.GameplayCode.GDFishObjects4= [];
gdjs.GameplayCode.GDFishObjects5= [];
gdjs.GameplayCode.GDFishObjects6= [];
gdjs.GameplayCode.GDTitleObjects1= [];
gdjs.GameplayCode.GDTitleObjects2= [];
gdjs.GameplayCode.GDTitleObjects3= [];
gdjs.GameplayCode.GDTitleObjects4= [];
gdjs.GameplayCode.GDTitleObjects5= [];
gdjs.GameplayCode.GDTitleObjects6= [];
gdjs.GameplayCode.GDTitleOObjects1= [];
gdjs.GameplayCode.GDTitleOObjects2= [];
gdjs.GameplayCode.GDTitleOObjects3= [];
gdjs.GameplayCode.GDTitleOObjects4= [];
gdjs.GameplayCode.GDTitleOObjects5= [];
gdjs.GameplayCode.GDTitleOObjects6= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects1= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects2= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects3= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects4= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects5= [];
gdjs.GameplayCode.GDPresstoPlayBGObjects6= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects1= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects2= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects3= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects4= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects5= [];
gdjs.GameplayCode.GDPresstoPlaytxtObjects6= [];
gdjs.GameplayCode.GDTutorialButtonObjects1= [];
gdjs.GameplayCode.GDTutorialButtonObjects2= [];
gdjs.GameplayCode.GDTutorialButtonObjects3= [];
gdjs.GameplayCode.GDTutorialButtonObjects4= [];
gdjs.GameplayCode.GDTutorialButtonObjects5= [];
gdjs.GameplayCode.GDTutorialButtonObjects6= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects1= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects2= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects3= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects4= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects5= [];
gdjs.GameplayCode.GDTutorialBackButtonObjects6= [];
gdjs.GameplayCode.GDHowtoPlayObjects1= [];
gdjs.GameplayCode.GDHowtoPlayObjects2= [];
gdjs.GameplayCode.GDHowtoPlayObjects3= [];
gdjs.GameplayCode.GDHowtoPlayObjects4= [];
gdjs.GameplayCode.GDHowtoPlayObjects5= [];
gdjs.GameplayCode.GDHowtoPlayObjects6= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects1= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects2= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects3= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects4= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects5= [];
gdjs.GameplayCode.GDGameStartHitBoxObjects6= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects1= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects2= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects3= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects4= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects5= [];
gdjs.GameplayCode.GDHowtoGetScoreObjects6= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects1= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects2= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects3= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects4= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects5= [];
gdjs.GameplayCode.GDHowtoLoseScoreObjects6= [];
gdjs.GameplayCode.GDHappyPlayingObjects1= [];
gdjs.GameplayCode.GDHappyPlayingObjects2= [];
gdjs.GameplayCode.GDHappyPlayingObjects3= [];
gdjs.GameplayCode.GDHappyPlayingObjects4= [];
gdjs.GameplayCode.GDHappyPlayingObjects5= [];
gdjs.GameplayCode.GDHappyPlayingObjects6= [];
gdjs.GameplayCode.GDTutorialBGObjects1= [];
gdjs.GameplayCode.GDTutorialBGObjects2= [];
gdjs.GameplayCode.GDTutorialBGObjects3= [];
gdjs.GameplayCode.GDTutorialBGObjects4= [];
gdjs.GameplayCode.GDTutorialBGObjects5= [];
gdjs.GameplayCode.GDTutorialBGObjects6= [];

gdjs.GameplayCode.conditionTrue_0 = {val:false};
gdjs.GameplayCode.condition0IsTrue_0 = {val:false};
gdjs.GameplayCode.condition1IsTrue_0 = {val:false};
gdjs.GameplayCode.condition2IsTrue_0 = {val:false};
gdjs.GameplayCode.condition3IsTrue_0 = {val:false};
gdjs.GameplayCode.condition4IsTrue_0 = {val:false};
gdjs.GameplayCode.condition5IsTrue_0 = {val:false};
gdjs.GameplayCode.condition6IsTrue_0 = {val:false};
gdjs.GameplayCode.conditionTrue_1 = {val:false};
gdjs.GameplayCode.condition0IsTrue_1 = {val:false};
gdjs.GameplayCode.condition1IsTrue_1 = {val:false};
gdjs.GameplayCode.condition2IsTrue_1 = {val:false};
gdjs.GameplayCode.condition3IsTrue_1 = {val:false};
gdjs.GameplayCode.condition4IsTrue_1 = {val:false};
gdjs.GameplayCode.condition5IsTrue_1 = {val:false};
gdjs.GameplayCode.condition6IsTrue_1 = {val:false};
gdjs.GameplayCode.conditionTrue_2 = {val:false};
gdjs.GameplayCode.condition0IsTrue_2 = {val:false};
gdjs.GameplayCode.condition1IsTrue_2 = {val:false};
gdjs.GameplayCode.condition2IsTrue_2 = {val:false};
gdjs.GameplayCode.condition3IsTrue_2 = {val:false};
gdjs.GameplayCode.condition4IsTrue_2 = {val:false};
gdjs.GameplayCode.condition5IsTrue_2 = {val:false};
gdjs.GameplayCode.condition6IsTrue_2 = {val:false};


gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameStartHitBoxObjects1Objects = Hashtable.newFrom({"GameStartHitBox": gdjs.GameplayCode.GDGameStartHitBoxObjects1});
gdjs.GameplayCode.asyncCallback10580492 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar3"), gdjs.GameplayCode.GDLimitBar3Objects2);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar3Objects2[i].getBehavior("Tween").addObjectPositionTween("Out", 95, 23, "easeInQuad", 1000, false);
}
}}
gdjs.GameplayCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameplayCode.asyncCallback10580492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects1Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects1});
gdjs.GameplayCode.eventsList1 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Bottle"), gdjs.GameplayCode.GDBottleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fish"), gdjs.GameplayCode.GDFishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.GameplayCode.GDRockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.GameplayCode.GDTimerObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTimerObjects1[i].setString("Timer : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("TimePlayed"))));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDRockObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRockObjects1[i].setString("Rock : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RockCaught"))));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBottleObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBottleObjects1[i].setString("Bottle : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("BottleCaught"))));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFishObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFishObjects1[i].setString("Fish : " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("FishCaught"))));
}
}}

}


};gdjs.GameplayCode.eventsList2 = function(runtimeScene) {

{



}


{



}


};gdjs.GameplayCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Gerak_Kanan"), true);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Able_Move"), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects3[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDKapalObjects3[k] = gdjs.GameplayCode.GDKapalObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects3.length = k;}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects3[i].getBehavior("Turret").SetAimingAngle((gdjs.GameplayCode.GDHookObjects3[i].getAngle()) + 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Gerak_Kiri"), true);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Able_Move"), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects3[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition2IsTrue_0.val = true;
        gdjs.GameplayCode.GDKapalObjects3[k] = gdjs.GameplayCode.GDKapalObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects3.length = k;}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects3[i].getBehavior("Turret").SetAimingAngle((gdjs.GameplayCode.GDHookObjects3[i].getAngle()) - 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHookObjects3[i].getAngle() == 65 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHookObjects3[k] = gdjs.GameplayCode.GDHookObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects3.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Gerak_Kanan"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Gerak_Kiri"), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHookObjects2[i].getAngle() == 305 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHookObjects2[k] = gdjs.GameplayCode.GDHookObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects2.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Gerak_Kanan"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Gerak_Kiri"), false);
}}

}


};gdjs.GameplayCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList2(runtimeScene);
}


{


gdjs.GameplayCode.eventsList3(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStringObjects2Objects = Hashtable.newFrom({"String": gdjs.GameplayCode.GDStringObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollisionObjects3Objects = Hashtable.newFrom({"Collision": gdjs.GameplayCode.GDCollisionObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects3Objects = Hashtable.newFrom({"Batu": gdjs.GameplayCode.GDBatuObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects3Objects = Hashtable.newFrom({"Botol": gdjs.GameplayCode.GDBotolObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects3});
gdjs.GameplayCode.eventsList5 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects1Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects1});
gdjs.GameplayCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Able_Move"), true);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects2[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDKapalObjects2[k] = gdjs.GameplayCode.GDKapalObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects2.length = k;}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);
gdjs.GameplayCode.GDStringObjects2.length = 0;

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Able_Move"), false);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStringObjects2Objects, (( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointX("")), (( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "watersplash2.mp3", false, 100, 1.5);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Able_Move"), false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects2[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDKapalObjects2[k] = gdjs.GameplayCode.GDKapalObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects2.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);
gdjs.copyArray(runtimeScene.getObjects("HookAngleDetector"), gdjs.GameplayCode.GDHookAngleDetectorObjects2);
gdjs.copyArray(runtimeScene.getObjects("String"), gdjs.GameplayCode.GDStringObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].addPolarForce((gdjs.GameplayCode.GDHookObjects2[i].getAngle()) + 90, 1000, 0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStringObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStringObjects2[i].setAngle((( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getAngle()) + 180);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookAngleDetectorObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookAngleDetectorObjects2[i].setAngle((( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStringObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStringObjects2[i].setHeight(gdjs.evtTools.common.distanceBetweenPositions((( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointX("")), (( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointY("")), (gdjs.GameplayCode.GDStringObjects2[i].getPointX("")), (gdjs.GameplayCode.GDStringObjects2[i].getPointY(""))));
}
}}

}


{



}


{



}


{



}


{

gdjs.GameplayCode.GDCollisionObjects2.length = 0;

gdjs.GameplayCode.GDHookObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition0IsTrue_1;
gdjs.GameplayCode.GDCollisionObjects2_2final.length = 0;gdjs.GameplayCode.GDHookObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Collision"), gdjs.GameplayCode.GDCollisionObjects3);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCollisionObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDCollisionObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDCollisionObjects2_2final.indexOf(gdjs.GameplayCode.GDCollisionObjects3[j]) === -1 )
            gdjs.GameplayCode.GDCollisionObjects2_2final.push(gdjs.GameplayCode.GDCollisionObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDHookObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDHookObjects2_2final.indexOf(gdjs.GameplayCode.GDHookObjects3[j]) === -1 )
            gdjs.GameplayCode.GDHookObjects2_2final.push(gdjs.GameplayCode.GDHookObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDCollisionObjects2_2final, gdjs.GameplayCode.GDCollisionObjects2);
gdjs.copyArray(gdjs.GameplayCode.GDHookObjects2_2final, gdjs.GameplayCode.GDHookObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").exists("Revert")) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHookObjects2[k] = gdjs.GameplayCode.GDHookObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10602052);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDHookObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").addObjectPositionTween("Revert", 248, 235, "linear", 500, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.GameplayCode.GDBatuObjects2.length = 0;

gdjs.GameplayCode.GDHookObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition0IsTrue_1;
gdjs.GameplayCode.GDBatuObjects2_2final.length = 0;gdjs.GameplayCode.GDHookObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Batu"), gdjs.GameplayCode.GDBatuObjects3);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDBatuObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDBatuObjects2_2final.indexOf(gdjs.GameplayCode.GDBatuObjects3[j]) === -1 )
            gdjs.GameplayCode.GDBatuObjects2_2final.push(gdjs.GameplayCode.GDBatuObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDHookObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDHookObjects2_2final.indexOf(gdjs.GameplayCode.GDHookObjects3[j]) === -1 )
            gdjs.GameplayCode.GDHookObjects2_2final.push(gdjs.GameplayCode.GDHookObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDBatuObjects2_2final, gdjs.GameplayCode.GDBatuObjects2);
gdjs.copyArray(gdjs.GameplayCode.GDHookObjects2_2final, gdjs.GameplayCode.GDHookObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").exists("Revert")) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHookObjects2[k] = gdjs.GameplayCode.GDHookObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10604692);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDHookObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").addObjectPositionTween("Revert", 248, 235, "linear", 1250, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.GameplayCode.GDBotolObjects2.length = 0;

gdjs.GameplayCode.GDHookObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition0IsTrue_1;
gdjs.GameplayCode.GDBotolObjects2_2final.length = 0;gdjs.GameplayCode.GDHookObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Botol"), gdjs.GameplayCode.GDBotolObjects3);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDBotolObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDBotolObjects2_2final.indexOf(gdjs.GameplayCode.GDBotolObjects3[j]) === -1 )
            gdjs.GameplayCode.GDBotolObjects2_2final.push(gdjs.GameplayCode.GDBotolObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDHookObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDHookObjects2_2final.indexOf(gdjs.GameplayCode.GDHookObjects3[j]) === -1 )
            gdjs.GameplayCode.GDHookObjects2_2final.push(gdjs.GameplayCode.GDHookObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDBotolObjects2_2final, gdjs.GameplayCode.GDBotolObjects2);
gdjs.copyArray(gdjs.GameplayCode.GDHookObjects2_2final, gdjs.GameplayCode.GDHookObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").exists("Revert")) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHookObjects2[k] = gdjs.GameplayCode.GDHookObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10606684);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDHookObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").addObjectPositionTween("Revert", 248, 235, "linear", 1000, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.GameplayCode.GDFeeshObjects2.length = 0;

gdjs.GameplayCode.GDHookObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition0IsTrue_1;
gdjs.GameplayCode.GDFeeshObjects2_2final.length = 0;gdjs.GameplayCode.GDHookObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Feesh"), gdjs.GameplayCode.GDFeeshObjects3);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDFeeshObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDFeeshObjects2_2final.indexOf(gdjs.GameplayCode.GDFeeshObjects3[j]) === -1 )
            gdjs.GameplayCode.GDFeeshObjects2_2final.push(gdjs.GameplayCode.GDFeeshObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDHookObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDHookObjects2_2final.indexOf(gdjs.GameplayCode.GDHookObjects3[j]) === -1 )
            gdjs.GameplayCode.GDHookObjects2_2final.push(gdjs.GameplayCode.GDHookObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDFeeshObjects2_2final, gdjs.GameplayCode.GDFeeshObjects2);
gdjs.copyArray(gdjs.GameplayCode.GDHookObjects2_2final, gdjs.GameplayCode.GDHookObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").exists("Revert")) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDHookObjects2[k] = gdjs.GameplayCode.GDHookObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10606108);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDHookObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].getBehavior("Tween").addObjectPositionTween("Revert", 248, 235, "linear", 1750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);

for(gdjs.GameplayCode.forEachIndex3 = 0;gdjs.GameplayCode.forEachIndex3 < gdjs.GameplayCode.GDHookObjects2.length;++gdjs.GameplayCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Batu"), gdjs.GameplayCode.GDBatuObjects3);
gdjs.copyArray(runtimeScene.getObjects("Botol"), gdjs.GameplayCode.GDBotolObjects3);
gdjs.copyArray(runtimeScene.getObjects("Feesh"), gdjs.GameplayCode.GDFeeshObjects3);
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects3);
gdjs.copyArray(runtimeScene.getObjects("String"), gdjs.GameplayCode.GDStringObjects3);
gdjs.GameplayCode.GDHookObjects3.length = 0;


gdjs.GameplayCode.forEachTemporary3 = gdjs.GameplayCode.GDHookObjects2[gdjs.GameplayCode.forEachIndex3];
gdjs.GameplayCode.GDHookObjects3.push(gdjs.GameplayCode.forEachTemporary3);
gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDHookObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDHookObjects3[i].getBehavior("Tween").hasFinished("Revert") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDHookObjects3[k] = gdjs.GameplayCode.GDHookObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDHookObjects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects3[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDKapalObjects3[k] = gdjs.GameplayCode.GDKapalObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects3.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10610972);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Able_Move"), true);
}{for(var i = 0, len = gdjs.GameplayCode.GDStringObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDStringObjects3[i].setAngle((( gdjs.GameplayCode.GDHookObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStringObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDStringObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Hook_Ada"), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects3[i].setVariableBoolean(gdjs.GameplayCode.GDBatuObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects3[i].setVariableBoolean(gdjs.GameplayCode.GDBotolObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].setVariableBoolean(gdjs.GameplayCode.GDFeeshObjects3[i].getVariables().getFromIndex(0), true);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ResetHit");
}}
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ResetHit") >= 0.1;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Batu"), gdjs.GameplayCode.GDBatuObjects2);
gdjs.copyArray(runtimeScene.getObjects("Botol"), gdjs.GameplayCode.GDBotolObjects2);
gdjs.copyArray(runtimeScene.getObjects("Feesh"), gdjs.GameplayCode.GDFeeshObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDBotolObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDBatuObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDFeeshObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Hook_Ada"), false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects1[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDKapalObjects1[k] = gdjs.GameplayCode.GDKapalObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects1.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition3IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10613708);
}
}}
}
}
if (gdjs.GameplayCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HookAngleDetector"), gdjs.GameplayCode.GDHookAngleDetectorObjects1);
/* Reuse gdjs.GameplayCode.GDKapalObjects1 */
gdjs.GameplayCode.GDHookObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects1Objects, 248, 235, "Net");
}{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects1[i].getBehavior("Turret").SetAimingAngle((( gdjs.GameplayCode.GDHookAngleDetectorObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookAngleDetectorObjects1[0].getAngle()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Hook_Ada"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Hooked"), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects1[i].setAnimation(0);
}
}}

}


};gdjs.GameplayCode.eventsList7 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList4(runtimeScene);
}


{


gdjs.GameplayCode.eventsList6(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects2Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects2Objects = Hashtable.newFrom({"Botol": gdjs.GameplayCode.GDBotolObjects2});
gdjs.GameplayCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDBotolObjects2 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDBotolObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBotolObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDBotolObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDBotolObjects2[k] = gdjs.GameplayCode.GDBotolObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBotolObjects2.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDBotolObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Scoring a Point.mp3", false, 100, 1);
}{runtimeScene.getVariables().get("Limit_Sampah").sub(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().get("BottleCaught").add(1);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects3Objects = Hashtable.newFrom({"Batu": gdjs.GameplayCode.GDBatuObjects3});
gdjs.GameplayCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameplayCode.GDBatuObjects3, gdjs.GameplayCode.GDBatuObjects4);


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDBatuObjects4.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBatuObjects4[i].getVariableBoolean(gdjs.GameplayCode.GDBatuObjects4[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDBatuObjects4[k] = gdjs.GameplayCode.GDBatuObjects4[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBatuObjects4.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDBatuObjects4 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Scoring a Point.mp3", false, 100, 1);
}{runtimeScene.getVariables().get("Limit_Sampah").sub(1);
}{runtimeScene.getGame().getVariables().get("RockCaught").add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects2Objects = Hashtable.newFrom({"Hook": gdjs.GameplayCode.GDHookObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects2Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects2});
gdjs.GameplayCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameplayCode.GDFeeshObjects2, gdjs.GameplayCode.GDFeeshObjects3);


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDFeeshObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDFeeshObjects3[i].getVariableBoolean(gdjs.GameplayCode.GDFeeshObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDFeeshObjects3[k] = gdjs.GameplayCode.GDFeeshObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDFeeshObjects3.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFeeshObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Error.mp3", false, 100, 1);
}{runtimeScene.getGame().getVariables().get("FishCaught").add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameplayCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Botol"), gdjs.GameplayCode.GDBotolObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDBotolObjects2 */
/* Reuse gdjs.GameplayCode.GDHookObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].setPosition((( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointX("ItemPlace")),(( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointY("ItemPlace")));
}
}
{ //Subevents
gdjs.GameplayCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Batu"), gdjs.GameplayCode.GDBatuObjects2);

for(gdjs.GameplayCode.forEachIndex3 = 0;gdjs.GameplayCode.forEachIndex3 < gdjs.GameplayCode.GDBatuObjects2.length;++gdjs.GameplayCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects3);
gdjs.GameplayCode.GDBatuObjects3.length = 0;


gdjs.GameplayCode.forEachTemporary3 = gdjs.GameplayCode.GDBatuObjects2[gdjs.GameplayCode.forEachIndex3];
gdjs.GameplayCode.GDBatuObjects3.push(gdjs.GameplayCode.forEachTemporary3);
gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects3[i].setPosition((( gdjs.GameplayCode.GDHookObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects3[0].getPointX("ItemPlace")),(( gdjs.GameplayCode.GDHookObjects3.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects3[0].getPointY("ItemPlace")));
}
}
{ //Subevents: 
gdjs.GameplayCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Feesh"), gdjs.GameplayCode.GDFeeshObjects1);

for(gdjs.GameplayCode.forEachIndex2 = 0;gdjs.GameplayCode.forEachIndex2 < gdjs.GameplayCode.GDFeeshObjects1.length;++gdjs.GameplayCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects2);
gdjs.GameplayCode.GDFeeshObjects2.length = 0;


gdjs.GameplayCode.forEachTemporary2 = gdjs.GameplayCode.GDFeeshObjects1[gdjs.GameplayCode.forEachIndex2];
gdjs.GameplayCode.GDFeeshObjects2.push(gdjs.GameplayCode.forEachTemporary2);
gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects2[i].setPosition((( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointX("ItemPlace")),(( gdjs.GameplayCode.GDHookObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDHookObjects2[0].getPointY("ItemPlace")));
}
}
{ //Subevents: 
gdjs.GameplayCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects2Objects = Hashtable.newFrom({"Botol": gdjs.GameplayCode.GDBotolObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects = Hashtable.newFrom({"Batu": gdjs.GameplayCode.GDBatuObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects = Hashtable.newFrom({"Batu": gdjs.GameplayCode.GDBatuObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects4});
gdjs.GameplayCode.eventsList12 = function(runtimeScene) {

{


{
gdjs.GameplayCode.GDFeeshObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects, 550, gdjs.randomFloatInRange(410, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].addForce(-(gdjs.randomInRange(75, 150)), 0, 1);
}
}}

}


{


{
gdjs.GameplayCode.GDFeeshObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects, -(50), gdjs.randomFloatInRange(425, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].flipX(true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].addForce(gdjs.randomInRange(75, 150), 0, 1);
}
}}

}


{


{
gdjs.GameplayCode.GDFeeshObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects, 550, gdjs.randomFloatInRange(410, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].addForce(-(gdjs.randomInRange(75, 150)), 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects4});
gdjs.GameplayCode.eventsList13 = function(runtimeScene) {

{


{
gdjs.GameplayCode.GDFeeshObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects, 550, gdjs.randomFloatInRange(410, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].addForce(-(gdjs.randomInRange(75, 150)), 0, 1);
}
}}

}


{


{
gdjs.GameplayCode.GDFeeshObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects, -(50), gdjs.randomFloatInRange(425, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].flipX(true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].addForce(gdjs.randomInRange(75, 150), 0, 1);
}
}}

}


{


{
gdjs.GameplayCode.GDFeeshObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects, -(50), gdjs.randomFloatInRange(425, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].flipX(true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].addForce(gdjs.randomInRange(75, 150), 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects5});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects4});
gdjs.GameplayCode.eventsList14 = function(runtimeScene) {

{


{
gdjs.GameplayCode.GDFeeshObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects5Objects, 550, gdjs.randomFloatInRange(410, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects5.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects5[i].addForce(-(gdjs.randomInRange(75, 150)), 0, 1);
}
}}

}


{


{
gdjs.GameplayCode.GDFeeshObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects, -(50), gdjs.randomFloatInRange(425, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].flipX(true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].addForce(gdjs.randomInRange(75, 150), 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects4});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects3});
gdjs.GameplayCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishType")) == 5;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10762764);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishType")) == 4;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10769204);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishType")) == 3;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10775772);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishType")) == 2;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10780364);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDFeeshObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects4Objects, 550, gdjs.randomFloatInRange(410, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects4.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects4[i].addForce(-(gdjs.randomInRange(75, 150)), 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishType")) == 1;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10782164);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDFeeshObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects, -(50), gdjs.randomFloatInRange(425, 880), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].setAnimation(gdjs.randomInRange(0, 1));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].addForce(gdjs.randomInRange(75, 150), 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects = Hashtable.newFrom({"Feesh": gdjs.GameplayCode.GDFeeshObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDestroyerObjects3Objects = Hashtable.newFrom({"Destroyer": gdjs.GameplayCode.GDDestroyerObjects3});
gdjs.GameplayCode.eventsList16 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList17 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "FishTimer") >= gdjs.randomInRange(4, 4);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("FishType").setNumber(gdjs.randomInRange(1, 5));
}
{ //Subevents
gdjs.GameplayCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Feesh"), gdjs.GameplayCode.GDFeeshObjects2);

for(gdjs.GameplayCode.forEachIndex3 = 0;gdjs.GameplayCode.forEachIndex3 < gdjs.GameplayCode.GDFeeshObjects2.length;++gdjs.GameplayCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Destroyer"), gdjs.GameplayCode.GDDestroyerObjects3);
gdjs.GameplayCode.GDFeeshObjects3.length = 0;


gdjs.GameplayCode.forEachTemporary3 = gdjs.GameplayCode.GDFeeshObjects2[gdjs.GameplayCode.forEachIndex3];
gdjs.GameplayCode.GDFeeshObjects3.push(gdjs.GameplayCode.forEachTemporary3);
gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFeeshObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDestroyerObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameplayCode.GDFeeshObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeeshObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects = Hashtable.newFrom({"Batu": gdjs.GameplayCode.GDBatuObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects1Objects = Hashtable.newFrom({"Botol": gdjs.GameplayCode.GDBotolObjects1});
gdjs.GameplayCode.eventsList18 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("ItemType")) == 2;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10786836);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDBatuObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects, gdjs.randomFloatInRange(75, 425), gdjs.randomFloatInRange(425, 850), "");
}{runtimeScene.getVariables().get("Limit_Sampah").add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].setSize(1, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].getBehavior("Tween").addObjectWidthTween("FadeInBatuX", 50, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].getBehavior("Tween").addObjectHeightTween("FadeInBatuY", 50, "linear", 750, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("ItemType")) == 1;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10789316);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDBotolObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects1Objects, gdjs.randomFloatInRange(75, 425), gdjs.randomFloatInRange(425, 850), "");
}{runtimeScene.getVariables().get("Limit_Sampah").add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects1[i].setSize(1, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects1[i].getBehavior("Tween").addObjectWidthTween("FadeInBotolX", 30, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects1[i].getBehavior("Tween").addObjectHeightTween("FadeInBotolY", 90, "linear", 750, false);
}
}}

}


};gdjs.GameplayCode.eventsList19 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ItemTimer") >= gdjs.randomInRange(2, 4);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("ItemType").setNumber(gdjs.randomInRange(1, 2));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ItemTimer");
}
{ //Subevents
gdjs.GameplayCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList20 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10754612);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDBatuObjects2.length = 0;

gdjs.GameplayCode.GDBotolObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBotolObjects2Objects, gdjs.randomFloatInRange(75, 425), gdjs.randomFloatInRange(425, 850), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects, gdjs.randomFloatInRange(75, 425), gdjs.randomFloatInRange(425, 850), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDBatuObjects2Objects, gdjs.randomFloatInRange(75, 425), gdjs.randomFloatInRange(425, 850), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ItemTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FishTimer");
}{runtimeScene.getVariables().get("ItemType").setNumber(0);
}{runtimeScene.getVariables().get("FishType").setNumber(0);
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].setSize(1, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].setSize(1, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].getBehavior("Tween").addObjectHeightTween("FadeInBatuY", 50, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatuObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatuObjects2[i].getBehavior("Tween").addObjectWidthTween("FadeInBatuX", 50, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].getBehavior("Tween").addObjectHeightTween("FadeInBotolY", 90, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotolObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotolObjects2[i].getBehavior("Tween").addObjectWidthTween("FadeInBotolX", 30, "linear", 750, false);
}
}}

}


{


gdjs.GameplayCode.eventsList17(runtimeScene);
}


{


gdjs.GameplayCode.eventsList19(runtimeScene);
}


};gdjs.GameplayCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 1;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "65;255;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 2;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "85;255;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 3;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "105;235;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 4;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "125;205;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 5;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "145;175;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 6;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "165;145;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 7;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "185;115;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 8;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "205;85;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 9;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects3);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects3[i].getBehavior("Tween").addObjectColorTween("BarColor", "225;55;0", "linear", 350, false, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 10;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects2[i].getBehavior("Tween").addObjectColorTween("BarColor", "245;25;0", "linear", 350, false, false);
}
}}

}


};gdjs.GameplayCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Warning"), true);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10633644);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDWarningObjects1, gdjs.GameplayCode.GDWarningObjects2);

{for(var i = 0, len = gdjs.GameplayCode.GDWarningObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDWarningObjects2[i].getBehavior("Tween").addObjectOpacityTween("WarningOpacity0", 0, "linear", 250, false);
}
}}

}


{

gdjs.copyArray(gdjs.GameplayCode.GDWarningObjects1, gdjs.GameplayCode.GDWarningObjects2);


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDWarningObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDWarningObjects2[i].getBehavior("Tween").hasFinished("WarningOpacity0") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDWarningObjects2[k] = gdjs.GameplayCode.GDWarningObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDWarningObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10634708);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Warning"), false);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Warning"), false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10635388);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDWarningObjects1, gdjs.GameplayCode.GDWarningObjects2);

{for(var i = 0, len = gdjs.GameplayCode.GDWarningObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDWarningObjects2[i].getBehavior("Tween").addObjectOpacityTween("WarningOpacity255", 255, "linear", 250, false);
}
}}

}


{

/* Reuse gdjs.GameplayCode.GDWarningObjects1 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDWarningObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDWarningObjects1[i].getBehavior("Tween").hasFinished("WarningOpacity255") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDWarningObjects1[k] = gdjs.GameplayCode.GDWarningObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDWarningObjects1.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10636508);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Warning"), true);
}}

}


};gdjs.GameplayCode.eventsList23 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Limit"), gdjs.GameplayCode.GDLimitObjects2);
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDLimitObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitObjects2[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah"))));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitObjects2[i].setAlignment("center");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects2[i].getBehavior("Tween").addObjectHeightTween("LimitBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) * 30, "linear", 350, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) == 11;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gameover", false);
}}

}


{


gdjs.GameplayCode.eventsList21(runtimeScene);
}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Warning"), true);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Limit_Sampah")) > 7;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Warning"), gdjs.GameplayCode.GDWarningObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDWarningObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDWarningObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList24 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("CurrentURL").setString(gdjs.evtsExt__URLTools__CurrentURL.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().get("Param_ContractID").setString(gdjs.evtsExt__URLTools__URLQueryStringParameter.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("CurrentURL")), "ContractID", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().get("Username").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Param_ContractID")));
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects3Objects = Hashtable.newFrom({"TutorialButton": gdjs.GameplayCode.GDTutorialButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects3Objects = Hashtable.newFrom({"TutorialButton": gdjs.GameplayCode.GDTutorialButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects2Objects = Hashtable.newFrom({"TutorialButton": gdjs.GameplayCode.GDTutorialButtonObjects2});
gdjs.GameplayCode.asyncCallback10642372 = function (runtimeScene, asyncObjectsList) {
}
gdjs.GameplayCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.GameplayCode.asyncCallback10642372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Batu2"), gdjs.GameplayCode.GDBatu2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Botol2"), gdjs.GameplayCode.GDBotol2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Feesh2"), gdjs.GameplayCode.GDFeesh2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Feesh3"), gdjs.GameplayCode.GDFeesh3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HappyPlaying"), gdjs.GameplayCode.GDHappyPlayingObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoGetScore"), gdjs.GameplayCode.GDHowtoGetScoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoLoseScore"), gdjs.GameplayCode.GDHowtoLoseScoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoPlay"), gdjs.GameplayCode.GDHowtoPlayObjects3);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlayBG"), gdjs.GameplayCode.GDPresstoPlayBGObjects3);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlaytxt"), gdjs.GameplayCode.GDPresstoPlaytxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects3);
gdjs.copyArray(runtimeScene.getObjects("TitleO"), gdjs.GameplayCode.GDTitleOObjects3);
gdjs.copyArray(runtimeScene.getObjects("TutorialBG"), gdjs.GameplayCode.GDTutorialBGObjects3);
gdjs.copyArray(runtimeScene.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects3);

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Tutorial"), true);
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDTitleOObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleOObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlayBGObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlayBGObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlaytxtObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlaytxtObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHowtoPlayObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoPlayObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoGetScoreObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoGetScoreObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoLoseScoreObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoLoseScoreObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDBotol2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotol2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDBatu2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatu2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh2Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh3Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh3Objects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDHappyPlayingObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHappyPlayingObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBGObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBGObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameplayCode.asyncCallback10640948 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameplayCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameplayCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDTutorialButtonObjects2) asyncObjectsList.addObject("TutorialButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.GameplayCode.asyncCallback10640948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.063, 0.063, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects3Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.07, 0.07, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Tutorial"), false);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialButtonObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bubble Pop SFX.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.063, 0.063, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.07, 0.07, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects3Objects = Hashtable.newFrom({"TutorialBackButton": gdjs.GameplayCode.GDTutorialBackButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects3Objects = Hashtable.newFrom({"TutorialBackButton": gdjs.GameplayCode.GDTutorialBackButtonObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects2Objects = Hashtable.newFrom({"TutorialBackButton": gdjs.GameplayCode.GDTutorialBackButtonObjects2});
gdjs.GameplayCode.asyncCallback10647492 = function (runtimeScene, asyncObjectsList) {
}
gdjs.GameplayCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.GameplayCode.asyncCallback10647492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Batu2"), gdjs.GameplayCode.GDBatu2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Botol2"), gdjs.GameplayCode.GDBotol2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Feesh2"), gdjs.GameplayCode.GDFeesh2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Feesh3"), gdjs.GameplayCode.GDFeesh3Objects3);
gdjs.copyArray(runtimeScene.getObjects("HappyPlaying"), gdjs.GameplayCode.GDHappyPlayingObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoGetScore"), gdjs.GameplayCode.GDHowtoGetScoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoLoseScore"), gdjs.GameplayCode.GDHowtoLoseScoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("HowtoPlay"), gdjs.GameplayCode.GDHowtoPlayObjects3);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlayBG"), gdjs.GameplayCode.GDPresstoPlayBGObjects3);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlaytxt"), gdjs.GameplayCode.GDPresstoPlaytxtObjects3);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects3);
gdjs.copyArray(runtimeScene.getObjects("TitleO"), gdjs.GameplayCode.GDTitleOObjects3);
gdjs.copyArray(runtimeScene.getObjects("TutorialBG"), gdjs.GameplayCode.GDTutorialBGObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects3);

gdjs.copyArray(runtimeScene.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects3);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Tutorial"), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDHowtoPlayObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoPlayObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoGetScoreObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoGetScoreObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoLoseScoreObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoLoseScoreObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDBotol2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotol2Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDBatu2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatu2Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh2Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh2Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh3Objects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh3Objects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHappyPlayingObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDHappyPlayingObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBGObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBGObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDTitleOObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleOObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlayBGObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlayBGObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlaytxtObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlaytxtObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameplayCode.asyncCallback10644732 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameplayCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameplayCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameplayCode.GDTutorialBackButtonObjects2) asyncObjectsList.addObject("TutorialBackButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.GameplayCode.asyncCallback10644732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameplayCode.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialBackButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.063, 0.063, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects3Objects, runtimeScene, true, true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialBackButtonObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.07, 0.07, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDTutorialBackButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Tutorial"), true);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTutorialBackButtonObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bubble Pop SFX.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.063, 0.063, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.07, 0.07, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList33 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList28(runtimeScene);
}


{


gdjs.GameplayCode.eventsList32(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackgroundAir"), gdjs.GameplayCode.GDBackgroundAirObjects1);
gdjs.copyArray(runtimeScene.getObjects("Batu2"), gdjs.GameplayCode.GDBatu2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Botol2"), gdjs.GameplayCode.GDBotol2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Feesh2"), gdjs.GameplayCode.GDFeesh2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Feesh3"), gdjs.GameplayCode.GDFeesh3Objects1);
gdjs.copyArray(runtimeScene.getObjects("HappyPlaying"), gdjs.GameplayCode.GDHappyPlayingObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoGetScore"), gdjs.GameplayCode.GDHowtoGetScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoLoseScore"), gdjs.GameplayCode.GDHowtoLoseScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoPlay"), gdjs.GameplayCode.GDHowtoPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("TutorialBG"), gdjs.GameplayCode.GDTutorialBGObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDHowtoPlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoPlayObjects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - (gdjs.GameplayCode.GDHowtoPlayObjects1[i].getWidth()) / 2,140);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHowtoGetScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoGetScoreObjects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - (gdjs.GameplayCode.GDHowtoGetScoreObjects1[i].getWidth()) / 2,(( gdjs.GameplayCode.GDHowtoPlayObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDHowtoPlayObjects1[0].getY()) + 100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBotol2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotol2Objects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - 50,(( gdjs.GameplayCode.GDHowtoGetScoreObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDHowtoGetScoreObjects1[0].getY()) + 140);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDBatu2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatu2Objects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 + 50,(( gdjs.GameplayCode.GDBotol2Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBotol2Objects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHowtoLoseScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoLoseScoreObjects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - (gdjs.GameplayCode.GDHowtoLoseScoreObjects1[i].getWidth()) / 2,(( gdjs.GameplayCode.GDBotol2Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBotol2Objects1[0].getPointY("")) + 85);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeesh2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh2Objects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - 50,(( gdjs.GameplayCode.GDHowtoLoseScoreObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDHowtoLoseScoreObjects1[0].getY()) + 120);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFeesh3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh3Objects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 + 50,(( gdjs.GameplayCode.GDFeesh2Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFeesh2Objects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHappyPlayingObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHappyPlayingObjects1[i].setPosition((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - (gdjs.GameplayCode.GDHappyPlayingObjects1[i].getWidth()) / 2,(( gdjs.GameplayCode.GDFeesh2Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFeesh2Objects1[0].getPointY("")) + 100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBGObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBGObjects1[i].setPosition(0,0);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialBGObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBGObjects1[i].setOpacity(150);
}
}}

}


};gdjs.GameplayCode.eventsList34 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BackgroundAir"), gdjs.GameplayCode.GDBackgroundAirObjects1);
gdjs.copyArray(runtimeScene.getObjects("Batu2"), gdjs.GameplayCode.GDBatu2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Botol2"), gdjs.GameplayCode.GDBotol2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Feesh2"), gdjs.GameplayCode.GDFeesh2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Feesh3"), gdjs.GameplayCode.GDFeesh3Objects1);
gdjs.copyArray(runtimeScene.getObjects("GameStartHitBox"), gdjs.GameplayCode.GDGameStartHitBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("HappyPlaying"), gdjs.GameplayCode.GDHappyPlayingObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hook"), gdjs.GameplayCode.GDHookObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoGetScore"), gdjs.GameplayCode.GDHowtoGetScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoLoseScore"), gdjs.GameplayCode.GDHowtoLoseScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowtoPlay"), gdjs.GameplayCode.GDHowtoPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("LimitBar2"), gdjs.GameplayCode.GDLimitBar2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlayBG"), gdjs.GameplayCode.GDPresstoPlayBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlaytxt"), gdjs.GameplayCode.GDPresstoPlaytxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("TutorialBG"), gdjs.GameplayCode.GDTutorialBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("TutorialBackButton"), gdjs.GameplayCode.GDTutorialBackButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Warning"), gdjs.GameplayCode.GDWarningObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDHookObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHookObjects1[i].getBehavior("Turret").SetAimingAngle(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDGameStartHitBoxObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGameStartHitBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDHowtoPlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoPlayObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoGetScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoGetScoreObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHowtoLoseScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHowtoLoseScoreObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDBotol2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBotol2Objects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDBatu2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBatu2Objects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh2Objects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDFeesh3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFeesh3Objects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDHappyPlayingObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDHappyPlayingObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBGObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBGObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameplayCode.GDTutorialBackButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialBackButtonObjects1[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Able_Move"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Hook_Ada"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Gerak_Kanan"), true);
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects1[i].setSize(40, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].setSize(1, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDWarningObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDWarningObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Tutorial"), false);
}{runtimeScene.getGame().getVariables().get("TimePlayed").setNumber(0);
}{runtimeScene.getGame().getVariables().get("FishCaught").setNumber(0);
}{runtimeScene.getGame().getVariables().get("RockCaught").setNumber(0);
}{runtimeScene.getGame().getVariables().get("BottleCaught").setNumber(0);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("TweenDone"), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlayBGObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlayBGObjects1[i].setOpacity(150);
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "A-Sea-of-Stars.mp3", 1, false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlaytxtObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlaytxtObjects1[i].setX((( gdjs.GameplayCode.GDBackgroundAirObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBackgroundAirObjects1[0].getWidth()) / 2 - (gdjs.GameplayCode.GDPresstoPlaytxtObjects1[i].getWidth()) / 2);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameplayCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("TitleO"), gdjs.GameplayCode.GDTitleOObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBackgroundObjects1[i].setXOffset(gdjs.GameplayCode.GDBackgroundObjects1[i].getXOffset() + (0.5));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleOObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleOObjects1[i].rotate(25, runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleOObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleOObjects1[i].setPosition((( gdjs.GameplayCode.GDTitleObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDTitleObjects1[0].getPointX("Center")),(( gdjs.GameplayCode.GDTitleObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDTitleObjects1[0].getPointY("Center")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameStartHitBox"), gdjs.GameplayCode.GDGameStartHitBoxObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
gdjs.GameplayCode.condition3IsTrue_0.val = false;
gdjs.GameplayCode.condition4IsTrue_0.val = false;
gdjs.GameplayCode.condition5IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), false);
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("TweenDone"), false);
}if ( gdjs.GameplayCode.condition2IsTrue_0.val ) {
{
gdjs.GameplayCode.condition3IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameStartHitBoxObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameplayCode.condition3IsTrue_0.val ) {
{
gdjs.GameplayCode.condition4IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Tutorial"), false);
}if ( gdjs.GameplayCode.condition4IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition5IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10579268);
}
}}
}
}
}
}
if (gdjs.GameplayCode.condition5IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects1);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlayBG"), gdjs.GameplayCode.GDPresstoPlayBGObjects1);
gdjs.copyArray(runtimeScene.getObjects("PresstoPlaytxt"), gdjs.GameplayCode.GDPresstoPlaytxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("TutorialButton"), gdjs.GameplayCode.GDTutorialButtonObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlaytxtObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlaytxtObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPresstoPlayBGObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPresstoPlayBGObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorialButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorialButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "TitleSwoopMovementSFX.mp3", false, 100, 1);
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Picnic-By-the-River.mp3", 2, false, 100, 1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("TweenDone"), true);
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects1[i].getBehavior("Tween").addObjectPositionTween("TitleOut", 0, -(550), "easeInQuad", 1000, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDKapalObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDKapalObjects1[i].getBehavior("Tween").addObjectPositionTween("KapalMasuk", 30, 73, "easeOutSine", 3000, false);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Kapal"), gdjs.GameplayCode.GDKapalObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDKapalObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDKapalObjects1[i].getBehavior("Tween").hasFinished("KapalMasuk") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDKapalObjects1[k] = gdjs.GameplayCode.GDKapalObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDKapalObjects1.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10581196);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LimitBar"), gdjs.GameplayCode.GDLimitBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("LimitBar2"), gdjs.GameplayCode.GDLimitBar2Objects1);
gdjs.GameplayCode.GDHookObjects1.length = 0;

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDHookObjects1Objects, 248, 235, "Net");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimePlayedCounter");
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBarObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBarObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].hide(false);
}
}{runtimeScene.getVariables().get("Limit_Sampah").setNumber(3);
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].getBehavior("Tween").addObjectWidthTween("WidthLimit2", 40, "linear", 500, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDLimitBar2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLimitBar2Objects1[i].getBehavior("Tween").addObjectHeightTween("HeightLimit2", 300, "linear", 1000, false);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimePlayedCounter") >= 1;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("GameStarted"), true);
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("TimePlayed").add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimePlayedCounter");
}}

}


{


gdjs.GameplayCode.eventsList1(runtimeScene);
}


{


gdjs.GameplayCode.eventsList7(runtimeScene);
}


{


gdjs.GameplayCode.eventsList11(runtimeScene);
}


{


gdjs.GameplayCode.eventsList20(runtimeScene);
}


{


gdjs.GameplayCode.eventsList23(runtimeScene);
}


{


gdjs.GameplayCode.eventsList24(runtimeScene);
}


{


gdjs.GameplayCode.eventsList33(runtimeScene);
}


{


{
}

}


};

gdjs.GameplayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameplayCode.GDKapalObjects1.length = 0;
gdjs.GameplayCode.GDKapalObjects2.length = 0;
gdjs.GameplayCode.GDKapalObjects3.length = 0;
gdjs.GameplayCode.GDKapalObjects4.length = 0;
gdjs.GameplayCode.GDKapalObjects5.length = 0;
gdjs.GameplayCode.GDKapalObjects6.length = 0;
gdjs.GameplayCode.GDHookObjects1.length = 0;
gdjs.GameplayCode.GDHookObjects2.length = 0;
gdjs.GameplayCode.GDHookObjects3.length = 0;
gdjs.GameplayCode.GDHookObjects4.length = 0;
gdjs.GameplayCode.GDHookObjects5.length = 0;
gdjs.GameplayCode.GDHookObjects6.length = 0;
gdjs.GameplayCode.GDCollisionObjects1.length = 0;
gdjs.GameplayCode.GDCollisionObjects2.length = 0;
gdjs.GameplayCode.GDCollisionObjects3.length = 0;
gdjs.GameplayCode.GDCollisionObjects4.length = 0;
gdjs.GameplayCode.GDCollisionObjects5.length = 0;
gdjs.GameplayCode.GDCollisionObjects6.length = 0;
gdjs.GameplayCode.GDStringObjects1.length = 0;
gdjs.GameplayCode.GDStringObjects2.length = 0;
gdjs.GameplayCode.GDStringObjects3.length = 0;
gdjs.GameplayCode.GDStringObjects4.length = 0;
gdjs.GameplayCode.GDStringObjects5.length = 0;
gdjs.GameplayCode.GDStringObjects6.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects1.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects2.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects3.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects4.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects5.length = 0;
gdjs.GameplayCode.GDHookAngleDetectorObjects6.length = 0;
gdjs.GameplayCode.GDBotolObjects1.length = 0;
gdjs.GameplayCode.GDBotolObjects2.length = 0;
gdjs.GameplayCode.GDBotolObjects3.length = 0;
gdjs.GameplayCode.GDBotolObjects4.length = 0;
gdjs.GameplayCode.GDBotolObjects5.length = 0;
gdjs.GameplayCode.GDBotolObjects6.length = 0;
gdjs.GameplayCode.GDBotol2Objects1.length = 0;
gdjs.GameplayCode.GDBotol2Objects2.length = 0;
gdjs.GameplayCode.GDBotol2Objects3.length = 0;
gdjs.GameplayCode.GDBotol2Objects4.length = 0;
gdjs.GameplayCode.GDBotol2Objects5.length = 0;
gdjs.GameplayCode.GDBotol2Objects6.length = 0;
gdjs.GameplayCode.GDBatuObjects1.length = 0;
gdjs.GameplayCode.GDBatuObjects2.length = 0;
gdjs.GameplayCode.GDBatuObjects3.length = 0;
gdjs.GameplayCode.GDBatuObjects4.length = 0;
gdjs.GameplayCode.GDBatuObjects5.length = 0;
gdjs.GameplayCode.GDBatuObjects6.length = 0;
gdjs.GameplayCode.GDBatu2Objects1.length = 0;
gdjs.GameplayCode.GDBatu2Objects2.length = 0;
gdjs.GameplayCode.GDBatu2Objects3.length = 0;
gdjs.GameplayCode.GDBatu2Objects4.length = 0;
gdjs.GameplayCode.GDBatu2Objects5.length = 0;
gdjs.GameplayCode.GDBatu2Objects6.length = 0;
gdjs.GameplayCode.GDFeeshObjects1.length = 0;
gdjs.GameplayCode.GDFeeshObjects2.length = 0;
gdjs.GameplayCode.GDFeeshObjects3.length = 0;
gdjs.GameplayCode.GDFeeshObjects4.length = 0;
gdjs.GameplayCode.GDFeeshObjects5.length = 0;
gdjs.GameplayCode.GDFeeshObjects6.length = 0;
gdjs.GameplayCode.GDFeesh2Objects1.length = 0;
gdjs.GameplayCode.GDFeesh2Objects2.length = 0;
gdjs.GameplayCode.GDFeesh2Objects3.length = 0;
gdjs.GameplayCode.GDFeesh2Objects4.length = 0;
gdjs.GameplayCode.GDFeesh2Objects5.length = 0;
gdjs.GameplayCode.GDFeesh2Objects6.length = 0;
gdjs.GameplayCode.GDFeesh3Objects1.length = 0;
gdjs.GameplayCode.GDFeesh3Objects2.length = 0;
gdjs.GameplayCode.GDFeesh3Objects3.length = 0;
gdjs.GameplayCode.GDFeesh3Objects4.length = 0;
gdjs.GameplayCode.GDFeesh3Objects5.length = 0;
gdjs.GameplayCode.GDFeesh3Objects6.length = 0;
gdjs.GameplayCode.GDLimitObjects1.length = 0;
gdjs.GameplayCode.GDLimitObjects2.length = 0;
gdjs.GameplayCode.GDLimitObjects3.length = 0;
gdjs.GameplayCode.GDLimitObjects4.length = 0;
gdjs.GameplayCode.GDLimitObjects5.length = 0;
gdjs.GameplayCode.GDLimitObjects6.length = 0;
gdjs.GameplayCode.GDLimitBarObjects1.length = 0;
gdjs.GameplayCode.GDLimitBarObjects2.length = 0;
gdjs.GameplayCode.GDLimitBarObjects3.length = 0;
gdjs.GameplayCode.GDLimitBarObjects4.length = 0;
gdjs.GameplayCode.GDLimitBarObjects5.length = 0;
gdjs.GameplayCode.GDLimitBarObjects6.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects1.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects2.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects3.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects4.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects5.length = 0;
gdjs.GameplayCode.GDLimitBar2Objects6.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects1.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects2.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects3.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects4.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects5.length = 0;
gdjs.GameplayCode.GDLimitBar3Objects6.length = 0;
gdjs.GameplayCode.GDWarningObjects1.length = 0;
gdjs.GameplayCode.GDWarningObjects2.length = 0;
gdjs.GameplayCode.GDWarningObjects3.length = 0;
gdjs.GameplayCode.GDWarningObjects4.length = 0;
gdjs.GameplayCode.GDWarningObjects5.length = 0;
gdjs.GameplayCode.GDWarningObjects6.length = 0;
gdjs.GameplayCode.GDDestroyerObjects1.length = 0;
gdjs.GameplayCode.GDDestroyerObjects2.length = 0;
gdjs.GameplayCode.GDDestroyerObjects3.length = 0;
gdjs.GameplayCode.GDDestroyerObjects4.length = 0;
gdjs.GameplayCode.GDDestroyerObjects5.length = 0;
gdjs.GameplayCode.GDDestroyerObjects6.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects1.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects2.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects3.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects4.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects5.length = 0;
gdjs.GameplayCode.GDWaveFrontObjects6.length = 0;
gdjs.GameplayCode.GDWaveBackObjects1.length = 0;
gdjs.GameplayCode.GDWaveBackObjects2.length = 0;
gdjs.GameplayCode.GDWaveBackObjects3.length = 0;
gdjs.GameplayCode.GDWaveBackObjects4.length = 0;
gdjs.GameplayCode.GDWaveBackObjects5.length = 0;
gdjs.GameplayCode.GDWaveBackObjects6.length = 0;
gdjs.GameplayCode.GDBackgroundObjects1.length = 0;
gdjs.GameplayCode.GDBackgroundObjects2.length = 0;
gdjs.GameplayCode.GDBackgroundObjects3.length = 0;
gdjs.GameplayCode.GDBackgroundObjects4.length = 0;
gdjs.GameplayCode.GDBackgroundObjects5.length = 0;
gdjs.GameplayCode.GDBackgroundObjects6.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects1.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects2.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects3.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects4.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects5.length = 0;
gdjs.GameplayCode.GDBackgroundAirObjects6.length = 0;
gdjs.GameplayCode.GDTimerObjects1.length = 0;
gdjs.GameplayCode.GDTimerObjects2.length = 0;
gdjs.GameplayCode.GDTimerObjects3.length = 0;
gdjs.GameplayCode.GDTimerObjects4.length = 0;
gdjs.GameplayCode.GDTimerObjects5.length = 0;
gdjs.GameplayCode.GDTimerObjects6.length = 0;
gdjs.GameplayCode.GDRockObjects1.length = 0;
gdjs.GameplayCode.GDRockObjects2.length = 0;
gdjs.GameplayCode.GDRockObjects3.length = 0;
gdjs.GameplayCode.GDRockObjects4.length = 0;
gdjs.GameplayCode.GDRockObjects5.length = 0;
gdjs.GameplayCode.GDRockObjects6.length = 0;
gdjs.GameplayCode.GDBottleObjects1.length = 0;
gdjs.GameplayCode.GDBottleObjects2.length = 0;
gdjs.GameplayCode.GDBottleObjects3.length = 0;
gdjs.GameplayCode.GDBottleObjects4.length = 0;
gdjs.GameplayCode.GDBottleObjects5.length = 0;
gdjs.GameplayCode.GDBottleObjects6.length = 0;
gdjs.GameplayCode.GDFishObjects1.length = 0;
gdjs.GameplayCode.GDFishObjects2.length = 0;
gdjs.GameplayCode.GDFishObjects3.length = 0;
gdjs.GameplayCode.GDFishObjects4.length = 0;
gdjs.GameplayCode.GDFishObjects5.length = 0;
gdjs.GameplayCode.GDFishObjects6.length = 0;
gdjs.GameplayCode.GDTitleObjects1.length = 0;
gdjs.GameplayCode.GDTitleObjects2.length = 0;
gdjs.GameplayCode.GDTitleObjects3.length = 0;
gdjs.GameplayCode.GDTitleObjects4.length = 0;
gdjs.GameplayCode.GDTitleObjects5.length = 0;
gdjs.GameplayCode.GDTitleObjects6.length = 0;
gdjs.GameplayCode.GDTitleOObjects1.length = 0;
gdjs.GameplayCode.GDTitleOObjects2.length = 0;
gdjs.GameplayCode.GDTitleOObjects3.length = 0;
gdjs.GameplayCode.GDTitleOObjects4.length = 0;
gdjs.GameplayCode.GDTitleOObjects5.length = 0;
gdjs.GameplayCode.GDTitleOObjects6.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects1.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects2.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects3.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects4.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects5.length = 0;
gdjs.GameplayCode.GDPresstoPlayBGObjects6.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects1.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects2.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects3.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects4.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects5.length = 0;
gdjs.GameplayCode.GDPresstoPlaytxtObjects6.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects1.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects2.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects3.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects4.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects5.length = 0;
gdjs.GameplayCode.GDTutorialButtonObjects6.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects1.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects2.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects3.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects4.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects5.length = 0;
gdjs.GameplayCode.GDTutorialBackButtonObjects6.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects1.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects2.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects3.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects4.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects5.length = 0;
gdjs.GameplayCode.GDHowtoPlayObjects6.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects1.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects2.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects3.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects4.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects5.length = 0;
gdjs.GameplayCode.GDGameStartHitBoxObjects6.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects1.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects2.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects3.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects4.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects5.length = 0;
gdjs.GameplayCode.GDHowtoGetScoreObjects6.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects1.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects2.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects3.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects4.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects5.length = 0;
gdjs.GameplayCode.GDHowtoLoseScoreObjects6.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects1.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects2.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects3.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects4.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects5.length = 0;
gdjs.GameplayCode.GDHappyPlayingObjects6.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects1.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects2.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects3.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects4.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects5.length = 0;
gdjs.GameplayCode.GDTutorialBGObjects6.length = 0;

gdjs.GameplayCode.eventsList34(runtimeScene);
return;

}

gdjs['GameplayCode'] = gdjs.GameplayCode;
