gdjs.GameoverCode = {};
gdjs.GameoverCode.GDRestartObjects1= [];
gdjs.GameoverCode.GDRestartObjects2= [];
gdjs.GameoverCode.GDRestartObjects3= [];
gdjs.GameoverCode.GDRestartObjects4= [];
gdjs.GameoverCode.GDBackgroundObjects1= [];
gdjs.GameoverCode.GDBackgroundObjects2= [];
gdjs.GameoverCode.GDBackgroundObjects3= [];
gdjs.GameoverCode.GDBackgroundObjects4= [];
gdjs.GameoverCode.GDTimerLogoObjects1= [];
gdjs.GameoverCode.GDTimerLogoObjects2= [];
gdjs.GameoverCode.GDTimerLogoObjects3= [];
gdjs.GameoverCode.GDTimerLogoObjects4= [];
gdjs.GameoverCode.GDTimerTextObjects1= [];
gdjs.GameoverCode.GDTimerTextObjects2= [];
gdjs.GameoverCode.GDTimerTextObjects3= [];
gdjs.GameoverCode.GDTimerTextObjects4= [];
gdjs.GameoverCode.GDTimerScoreObjects1= [];
gdjs.GameoverCode.GDTimerScoreObjects2= [];
gdjs.GameoverCode.GDTimerScoreObjects3= [];
gdjs.GameoverCode.GDTimerScoreObjects4= [];
gdjs.GameoverCode.GDRockLogoObjects1= [];
gdjs.GameoverCode.GDRockLogoObjects2= [];
gdjs.GameoverCode.GDRockLogoObjects3= [];
gdjs.GameoverCode.GDRockLogoObjects4= [];
gdjs.GameoverCode.GDRockTextObjects1= [];
gdjs.GameoverCode.GDRockTextObjects2= [];
gdjs.GameoverCode.GDRockTextObjects3= [];
gdjs.GameoverCode.GDRockTextObjects4= [];
gdjs.GameoverCode.GDRockScoreObjects1= [];
gdjs.GameoverCode.GDRockScoreObjects2= [];
gdjs.GameoverCode.GDRockScoreObjects3= [];
gdjs.GameoverCode.GDRockScoreObjects4= [];
gdjs.GameoverCode.GDBottleLogoObjects1= [];
gdjs.GameoverCode.GDBottleLogoObjects2= [];
gdjs.GameoverCode.GDBottleLogoObjects3= [];
gdjs.GameoverCode.GDBottleLogoObjects4= [];
gdjs.GameoverCode.GDBottleTextObjects1= [];
gdjs.GameoverCode.GDBottleTextObjects2= [];
gdjs.GameoverCode.GDBottleTextObjects3= [];
gdjs.GameoverCode.GDBottleTextObjects4= [];
gdjs.GameoverCode.GDBottleScoreObjects1= [];
gdjs.GameoverCode.GDBottleScoreObjects2= [];
gdjs.GameoverCode.GDBottleScoreObjects3= [];
gdjs.GameoverCode.GDBottleScoreObjects4= [];
gdjs.GameoverCode.GDFishLogoObjects1= [];
gdjs.GameoverCode.GDFishLogoObjects2= [];
gdjs.GameoverCode.GDFishLogoObjects3= [];
gdjs.GameoverCode.GDFishLogoObjects4= [];
gdjs.GameoverCode.GDFishTextObjects1= [];
gdjs.GameoverCode.GDFishTextObjects2= [];
gdjs.GameoverCode.GDFishTextObjects3= [];
gdjs.GameoverCode.GDFishTextObjects4= [];
gdjs.GameoverCode.GDFishScoreObjects1= [];
gdjs.GameoverCode.GDFishScoreObjects2= [];
gdjs.GameoverCode.GDFishScoreObjects3= [];
gdjs.GameoverCode.GDFishScoreObjects4= [];
gdjs.GameoverCode.GDTotalScoreObjects1= [];
gdjs.GameoverCode.GDTotalScoreObjects2= [];
gdjs.GameoverCode.GDTotalScoreObjects3= [];
gdjs.GameoverCode.GDTotalScoreObjects4= [];
gdjs.GameoverCode.GDTandaXObjects1= [];
gdjs.GameoverCode.GDTandaXObjects2= [];
gdjs.GameoverCode.GDTandaXObjects3= [];
gdjs.GameoverCode.GDTandaXObjects4= [];
gdjs.GameoverCode.GDAngka1Objects1= [];
gdjs.GameoverCode.GDAngka1Objects2= [];
gdjs.GameoverCode.GDAngka1Objects3= [];
gdjs.GameoverCode.GDAngka1Objects4= [];
gdjs.GameoverCode.GDAngka3Objects1= [];
gdjs.GameoverCode.GDAngka3Objects2= [];
gdjs.GameoverCode.GDAngka3Objects3= [];
gdjs.GameoverCode.GDAngka3Objects4= [];
gdjs.GameoverCode.GDAngka5Objects1= [];
gdjs.GameoverCode.GDAngka5Objects2= [];
gdjs.GameoverCode.GDAngka5Objects3= [];
gdjs.GameoverCode.GDAngka5Objects4= [];
gdjs.GameoverCode.GDAngka5NegatifObjects1= [];
gdjs.GameoverCode.GDAngka5NegatifObjects2= [];
gdjs.GameoverCode.GDAngka5NegatifObjects3= [];
gdjs.GameoverCode.GDAngka5NegatifObjects4= [];
gdjs.GameoverCode.GDYourScoreObjects1= [];
gdjs.GameoverCode.GDYourScoreObjects2= [];
gdjs.GameoverCode.GDYourScoreObjects3= [];
gdjs.GameoverCode.GDYourScoreObjects4= [];
gdjs.GameoverCode.GDYourBestObjects1= [];
gdjs.GameoverCode.GDYourBestObjects2= [];
gdjs.GameoverCode.GDYourBestObjects3= [];
gdjs.GameoverCode.GDYourBestObjects4= [];
gdjs.GameoverCode.GDBestScoreObjects1= [];
gdjs.GameoverCode.GDBestScoreObjects2= [];
gdjs.GameoverCode.GDBestScoreObjects3= [];
gdjs.GameoverCode.GDBestScoreObjects4= [];
gdjs.GameoverCode.GDNewBestScoreObjects1= [];
gdjs.GameoverCode.GDNewBestScoreObjects2= [];
gdjs.GameoverCode.GDNewBestScoreObjects3= [];
gdjs.GameoverCode.GDNewBestScoreObjects4= [];
gdjs.GameoverCode.GDBestScore2Objects1= [];
gdjs.GameoverCode.GDBestScore2Objects2= [];
gdjs.GameoverCode.GDBestScore2Objects3= [];
gdjs.GameoverCode.GDBestScore2Objects4= [];

gdjs.GameoverCode.conditionTrue_0 = {val:false};
gdjs.GameoverCode.condition0IsTrue_0 = {val:false};
gdjs.GameoverCode.condition1IsTrue_0 = {val:false};
gdjs.GameoverCode.condition2IsTrue_0 = {val:false};
gdjs.GameoverCode.condition3IsTrue_0 = {val:false};
gdjs.GameoverCode.conditionTrue_1 = {val:false};
gdjs.GameoverCode.condition0IsTrue_1 = {val:false};
gdjs.GameoverCode.condition1IsTrue_1 = {val:false};
gdjs.GameoverCode.condition2IsTrue_1 = {val:false};
gdjs.GameoverCode.condition3IsTrue_1 = {val:false};


gdjs.GameoverCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BottleScore"), gdjs.GameoverCode.GDBottleScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("BottleText"), gdjs.GameoverCode.GDBottleTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("FishScore"), gdjs.GameoverCode.GDFishScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("FishText"), gdjs.GameoverCode.GDFishTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RockScore"), gdjs.GameoverCode.GDRockScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("RockText"), gdjs.GameoverCode.GDRockTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("TimerScore"), gdjs.GameoverCode.GDTimerScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("TimerText"), gdjs.GameoverCode.GDTimerTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("TotalScore"), gdjs.GameoverCode.GDTotalScoreObjects1);
{runtimeScene.getVariables().get("TimeScore").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameoverCode.GDTimerTextObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameoverCode.GDTimerTextObjects1[0].getVariables()).getFromIndex(0))) * 1);
}{runtimeScene.getVariables().get("TimeHighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("TimePlayed")) * 1);
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerTextObjects1[i].setBBText(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(gdjs.GameoverCode.GDTimerTextObjects1[i].getVariables().getFromIndex(0))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TimeScore")))));
}
}{runtimeScene.getVariables().get("RockScore").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameoverCode.GDRockTextObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameoverCode.GDRockTextObjects1[0].getVariables()).getFromIndex(0))) * 3);
}{runtimeScene.getVariables().get("RockHighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RockCaught")) * 3);
}{for(var i = 0, len = gdjs.GameoverCode.GDRockTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockTextObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor((gdjs.RuntimeObject.getVariableNumber(gdjs.GameoverCode.GDRockTextObjects1[i].getVariables().getFromIndex(0))))));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRockScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RockScore")))));
}
}{runtimeScene.getVariables().get("BottleScore").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameoverCode.GDBottleTextObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameoverCode.GDBottleTextObjects1[0].getVariables()).getFromIndex(0))) * 5);
}{runtimeScene.getVariables().get("BottleHighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("BottleCaught")) * 5);
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleTextObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor((gdjs.RuntimeObject.getVariableNumber(gdjs.GameoverCode.GDBottleTextObjects1[i].getVariables().getFromIndex(0))))));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BottleScore")))));
}
}{runtimeScene.getVariables().get("FishScore").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameoverCode.GDFishTextObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameoverCode.GDFishTextObjects1[0].getVariables()).getFromIndex(0))) * -(5));
}{runtimeScene.getVariables().get("FishHighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("FishCaught")) * -(5));
}{for(var i = 0, len = gdjs.GameoverCode.GDFishTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishTextObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor((gdjs.RuntimeObject.getVariableNumber(gdjs.GameoverCode.GDFishTextObjects1[i].getVariables().getFromIndex(0))))));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDFishScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishScore")))));
}
}{runtimeScene.getVariables().get("TotalScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TimeScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RockScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BottleScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishScore")));
}{runtimeScene.getVariables().get("TotalHighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TimeHighScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RockHighScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BottleHighScore")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("FishHighScore")));
}{for(var i = 0, len = gdjs.GameoverCode.GDTotalScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTotalScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalScore")))));
}
}}

}


};gdjs.GameoverCode.eventsList1 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Angka1"), gdjs.GameoverCode.GDAngka1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Angka3"), gdjs.GameoverCode.GDAngka3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Angka5"), gdjs.GameoverCode.GDAngka5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Angka5Negatif"), gdjs.GameoverCode.GDAngka5NegatifObjects2);
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameoverCode.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BottleLogo"), gdjs.GameoverCode.GDBottleLogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottleScore"), gdjs.GameoverCode.GDBottleScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottleText"), gdjs.GameoverCode.GDBottleTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("FishLogo"), gdjs.GameoverCode.GDFishLogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("FishScore"), gdjs.GameoverCode.GDFishScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("FishText"), gdjs.GameoverCode.GDFishTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("RockLogo"), gdjs.GameoverCode.GDRockLogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("RockScore"), gdjs.GameoverCode.GDRockScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("RockText"), gdjs.GameoverCode.GDRockTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimerLogo"), gdjs.GameoverCode.GDTimerLogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimerScore"), gdjs.GameoverCode.GDTimerScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimerText"), gdjs.GameoverCode.GDTimerTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("YourBest"), gdjs.GameoverCode.GDYourBestObjects2);
{for(var i = 0, len = gdjs.GameoverCode.GDAngka1Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDAngka1Objects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) / 2 - (gdjs.GameoverCode.GDAngka1Objects2[i].getWidth()) / 2,(( gdjs.GameoverCode.GDTimerLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDTimerLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDAngka1Objects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerTextObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerTextObjects2[i].setPosition((( gdjs.GameoverCode.GDTimerLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDTimerLogoObjects2[0].getPointX("")) + 30,(( gdjs.GameoverCode.GDTimerLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDTimerLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDTimerTextObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerScoreObjects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) - 100 - (gdjs.GameoverCode.GDTimerScoreObjects2[i].getWidth()),(( gdjs.GameoverCode.GDTimerLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDTimerLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDTimerScoreObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDAngka3Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDAngka3Objects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) / 2 - (gdjs.GameoverCode.GDAngka3Objects2[i].getWidth()) / 2,(( gdjs.GameoverCode.GDRockLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDRockLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDAngka3Objects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRockTextObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockTextObjects2[i].setPosition((( gdjs.GameoverCode.GDRockLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDRockLogoObjects2[0].getPointX("")) + 30,(( gdjs.GameoverCode.GDRockLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDRockLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDRockTextObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRockScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockScoreObjects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) - 100 - (gdjs.GameoverCode.GDRockScoreObjects2[i].getWidth()),(( gdjs.GameoverCode.GDRockLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDRockLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDRockScoreObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDAngka5Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDAngka5Objects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) / 2 - (gdjs.GameoverCode.GDAngka5Objects2[i].getWidth()) / 2,(( gdjs.GameoverCode.GDBottleLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBottleLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDAngka5Objects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleTextObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleTextObjects2[i].setPosition((( gdjs.GameoverCode.GDBottleLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBottleLogoObjects2[0].getPointX("")) + 30,(( gdjs.GameoverCode.GDBottleLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBottleLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDBottleTextObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleScoreObjects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) - 100 - (gdjs.GameoverCode.GDBottleScoreObjects2[i].getWidth()),(( gdjs.GameoverCode.GDBottleLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBottleLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDBottleScoreObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDAngka5NegatifObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDAngka5NegatifObjects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) / 2 - (gdjs.GameoverCode.GDAngka5NegatifObjects2[i].getWidth()) / 2,(( gdjs.GameoverCode.GDFishLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDFishLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDAngka5NegatifObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDFishTextObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishTextObjects2[i].setPosition((( gdjs.GameoverCode.GDFishLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDFishLogoObjects2[0].getPointX("")) + 30,(( gdjs.GameoverCode.GDFishLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDFishLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDFishTextObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDFishScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishScoreObjects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) - 100 - (gdjs.GameoverCode.GDFishScoreObjects2[i].getWidth()),(( gdjs.GameoverCode.GDFishLogoObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDFishLogoObjects2[0].getPointY("")) - (gdjs.GameoverCode.GDFishScoreObjects2[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects2[i].setPosition((( gdjs.GameoverCode.GDBackgroundObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects2[0].getWidth()) / 2,(( gdjs.GameoverCode.GDYourBestObjects2.length === 0 ) ? 0 :gdjs.GameoverCode.GDYourBestObjects2[0].getY()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameoverCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("BottleScore"), gdjs.GameoverCode.GDBottleScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("FishScore"), gdjs.GameoverCode.GDFishScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("RockScore"), gdjs.GameoverCode.GDRockScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("TimerScore"), gdjs.GameoverCode.GDTimerScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("TotalScore"), gdjs.GameoverCode.GDTotalScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("YourBest"), gdjs.GameoverCode.GDYourBestObjects1);
gdjs.copyArray(runtimeScene.getObjects("YourScore"), gdjs.GameoverCode.GDYourScoreObjects1);
{for(var i = 0, len = gdjs.GameoverCode.GDYourScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDYourScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) / 2 - (gdjs.GameoverCode.GDYourScoreObjects1[i].getWidth()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDYourBestObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDYourBestObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) / 2 - (gdjs.GameoverCode.GDYourBestObjects1[i].getWidth()) * 1.5);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTotalScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTotalScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) / 2 - (gdjs.GameoverCode.GDTotalScoreObjects1[i].getWidth()) / 2);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) - 100 - (gdjs.GameoverCode.GDTimerScoreObjects1[i].getWidth()));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRockScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) - 100 - (gdjs.GameoverCode.GDRockScoreObjects1[i].getWidth()));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDFishScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) - 100 - (gdjs.GameoverCode.GDFishScoreObjects1[i].getWidth()));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleScoreObjects1[i].setX((( gdjs.GameoverCode.GDBackgroundObjects1.length === 0 ) ? 0 :gdjs.GameoverCode.GDBackgroundObjects1[0].getWidth()) - 100 - (gdjs.GameoverCode.GDBottleScoreObjects1[i].getWidth()));
}
}}

}


};gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects3Objects = Hashtable.newFrom({"Restart": gdjs.GameoverCode.GDRestartObjects3});
gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects3Objects = Hashtable.newFrom({"Restart": gdjs.GameoverCode.GDRestartObjects3});
gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects2Objects = Hashtable.newFrom({"Restart": gdjs.GameoverCode.GDRestartObjects2});
gdjs.GameoverCode.asyncCallback10733700 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gameplay", false);
}}
gdjs.GameoverCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.GameoverCode.asyncCallback10733700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameoverCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.GameoverCode.GDRestartObjects3);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
gdjs.GameoverCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDRestartObjects3 */
{for(var i = 0, len = gdjs.GameoverCode.GDRestartObjects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDRestartObjects3[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.GameoverCode.GDRestartObjects3);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects3Objects, runtimeScene, true, true);
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDRestartObjects3 */
{for(var i = 0, len = gdjs.GameoverCode.GDRestartObjects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDRestartObjects3[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.GameoverCode.GDRestartObjects2);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
gdjs.GameoverCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDRestartObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bubble Pop SFX.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameoverCode.GDRestartObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDRestartObjects2[i].getBehavior("Tween").addObjectScaleTween("Down", 0.09, 0.09, "linear", 100, false, true);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRestartObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDRestartObjects2[i].getBehavior("Tween").addObjectScaleTween("Up", 0.1, 0.1, "linear", 100, false, true);
}
}
{ //Subevents
gdjs.GameoverCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.GameoverCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects3);
{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects3[i].getBehavior("Tween").addObjectOpacityTween("Fadeout", 0, "linear", 1000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects3);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameoverCode.GDNewBestScoreObjects3.length;i<l;++i) {
    if ( gdjs.GameoverCode.GDNewBestScoreObjects3[i].getBehavior("Tween").hasFinished("Fadeout") ) {
        gdjs.GameoverCode.condition0IsTrue_0.val = true;
        gdjs.GameoverCode.GDNewBestScoreObjects3[k] = gdjs.GameoverCode.GDNewBestScoreObjects3[i];
        ++k;
    }
}
gdjs.GameoverCode.GDNewBestScoreObjects3.length = k;}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition1IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10715428);
}
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDNewBestScoreObjects3 */
{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects3[i].getBehavior("Tween").addObjectOpacityTween("Fadein", 255, "linear", 1000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects2);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameoverCode.GDNewBestScoreObjects2.length;i<l;++i) {
    if ( gdjs.GameoverCode.GDNewBestScoreObjects2[i].getBehavior("Tween").hasFinished("Fadein") ) {
        gdjs.GameoverCode.condition0IsTrue_0.val = true;
        gdjs.GameoverCode.GDNewBestScoreObjects2[k] = gdjs.GameoverCode.GDNewBestScoreObjects2[i];
        ++k;
    }
}
gdjs.GameoverCode.GDNewBestScoreObjects2.length = k;}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition1IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10729820);
}
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDNewBestScoreObjects2 */
{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects2[i].getBehavior("Tween").addObjectOpacityTween("Fadeout", 0, "linear", 1000, false);
}
}}

}


};gdjs.GameoverCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FishText"), gdjs.GameoverCode.GDFishTextObjects2);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameoverCode.GDFishTextObjects2.length;i<l;++i) {
    if ( gdjs.GameoverCode.GDFishTextObjects2[i].getBehavior("Tween").hasFinished("FishNumber") ) {
        gdjs.GameoverCode.condition0IsTrue_0.val = true;
        gdjs.GameoverCode.GDFishTextObjects2[k] = gdjs.GameoverCode.GDFishTextObjects2[i];
        ++k;
    }
}
gdjs.GameoverCode.GDFishTextObjects2.length = k;}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition1IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10704788);
}
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects2);
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects2[i].getBehavior("Tween").addObjectScaleTween("FadeIn2", 1.2, 1.2, "easeInQuad", 1200, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects1);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameoverCode.GDBestScore2Objects1.length;i<l;++i) {
    if ( gdjs.GameoverCode.GDBestScore2Objects1[i].getBehavior("Tween").hasFinished("FadeIn2") ) {
        gdjs.GameoverCode.condition0IsTrue_0.val = true;
        gdjs.GameoverCode.GDBestScore2Objects1[k] = gdjs.GameoverCode.GDBestScore2Objects1[i];
        ++k;
    }
}
gdjs.GameoverCode.GDBestScore2Objects1.length = k;}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameoverCode.GDBestScore2Objects1 */
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects1[i].getBehavior("Tween").addObjectScaleTween("FadeOut2", 1, 1, "easeOutQuad", 300, false, false);
}
}}

}


};gdjs.GameoverCode.eventsList6 = function(runtimeScene) {

{


gdjs.GameoverCode.eventsList3(runtimeScene);
}


{


gdjs.GameoverCode.eventsList4(runtimeScene);
}


{


gdjs.GameoverCode.eventsList5(runtimeScene);
}


};gdjs.GameoverCode.eventsList7 = function(runtimeScene) {

{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition0IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("LoadedScore")) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")));
}
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects3);
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("LoadedScore"))));
}
}}

}


{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition0IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("LoadedScore")) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")));
}
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects2);
gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects2);
{gdjs.evtTools.storage.writeNumberInJSONFile("ScoreDB", "HighScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")));
}{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "HighscoreSFX.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects2[i].hide(false);
}
}}

}


};gdjs.GameoverCode.eventsList8 = function(runtimeScene) {

{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("ScoreDB", "HighScore"));
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("ScoreDB", "HighScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")));
}{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects3[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TotalHighScore")))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "HighscoreSFX.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects3.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects3[i].hide(false);
}
}}

}


{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("ScoreDB", "HighScore");
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("ScoreDB", "HighScore", runtimeScene, runtimeScene.getVariables().get("LoadedScore"));
}
{ //Subevents
gdjs.GameoverCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameoverCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FishText"), gdjs.GameoverCode.GDFishTextObjects2);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameoverCode.GDFishTextObjects2.length;i<l;++i) {
    if ( gdjs.GameoverCode.GDFishTextObjects2[i].getBehavior("Tween").hasFinished("FishNumber") ) {
        gdjs.GameoverCode.condition0IsTrue_0.val = true;
        gdjs.GameoverCode.GDFishTextObjects2[k] = gdjs.GameoverCode.GDFishTextObjects2[i];
        ++k;
    }
}
gdjs.GameoverCode.GDFishTextObjects2.length = k;}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition1IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10712596);
}
}}
if (gdjs.GameoverCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameoverCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects2Objects = Hashtable.newFrom({"Restart": gdjs.GameoverCode.GDRestartObjects2});
gdjs.GameoverCode.eventsList10 = function(runtimeScene) {

{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition0IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10675484);
}
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.network.sendAsyncRequest("https://localhost:44312/api/Gamification2022/Gamification/UpdateFishing", "{ \"username\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("Username")) + ",\n   \"score\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("TotalHighScore")) + ",\n   \"Highscore\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getVariables().get("LoadedScore")) + " \n }", "POST", "application/json", runtimeScene.getVariables().get("Return_Temp"), gdjs.VariablesContainer.badVariable);
}}

}


};gdjs.GameoverCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.GameoverCode.GDRestartObjects2);

gdjs.GameoverCode.condition0IsTrue_0.val = false;
gdjs.GameoverCode.condition1IsTrue_0.val = false;
gdjs.GameoverCode.condition2IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameoverCode.mapOfGDgdjs_46GameoverCode_46GDRestartObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameoverCode.condition0IsTrue_0.val ) {
{
gdjs.GameoverCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameoverCode.condition1IsTrue_0.val ) {
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition2IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10721252);
}
}}
}
if (gdjs.GameoverCode.condition2IsTrue_0.val) {
{gdjs.evtTools.network.sendAsyncRequest("https://localhost:44312/api/Gamification2022/Gamification/UpdateFishing", "{ \"username\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("Username")) + ",\n   \"score\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("TotalHighScore")) + ",\n   \"Highscore\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getVariables().get("LoadedScore")) + " \n }", "POST", "application/json", runtimeScene.getVariables().get("Return_Temp"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.network.sendAsyncRequest("https://localhost:44312/api/Gamification2022/Gamification/GetFishing", "{ \n\"username\": " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("Username")) + "\n  \n }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get"), gdjs.VariablesContainer.badVariable);
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get")), runtimeScene.getGame().getVariables().get("DataConvertedtoGlobal"));
}{runtimeScene.getGame().getVariables().get("ScoreLoadedfromDatabaseSQL").setNumber(gdjs.evtTools.common.toNumber(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("DataConvertedtoGlobal").getChild("data").getChild("highscore")))));
}}

}


{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition0IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("ScoreLoadedfromDatabaseSQL")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Score")));
}
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TotalScore"), gdjs.GameoverCode.GDTotalScoreObjects2);
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("ScoreLoadedfromDatabaseSQL"))));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTotalScoreObjects2.length ;i < len;++i) {
    gdjs.GameoverCode.GDTotalScoreObjects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Score")));
}
}}

}


{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
{gdjs.GameoverCode.conditionTrue_1 = gdjs.GameoverCode.condition0IsTrue_0;
gdjs.GameoverCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("ScoreLoadedfromDatabaseSQL")) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Score")));
}
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects1);
gdjs.copyArray(runtimeScene.getObjects("TotalScore"), gdjs.GameoverCode.GDTotalScoreObjects1);
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Score")));
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTotalScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTotalScoreObjects1[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Score")));
}
}
{ //Subevents
gdjs.GameoverCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.GameoverCode.eventsList12 = function(runtimeScene) {

{


gdjs.GameoverCode.eventsList9(runtimeScene);
}


{


gdjs.GameoverCode.eventsList11(runtimeScene);
}


};gdjs.GameoverCode.eventsList13 = function(runtimeScene) {

};gdjs.GameoverCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameoverCode.condition0IsTrue_0.val = false;
{
gdjs.GameoverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameoverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BestScore2"), gdjs.GameoverCode.GDBestScore2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BottleText"), gdjs.GameoverCode.GDBottleTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("FishText"), gdjs.GameoverCode.GDFishTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewBestScore"), gdjs.GameoverCode.GDNewBestScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("RockText"), gdjs.GameoverCode.GDRockTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("TimerText"), gdjs.GameoverCode.GDTimerTextObjects1);
{for(var i = 0, len = gdjs.GameoverCode.GDBestScore2Objects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBestScore2Objects1[i].setScale(0);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDTimerTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDTimerTextObjects1[i].getBehavior("Tween").addVariableTween("TimerNumber", gdjs.GameoverCode.GDTimerTextObjects1[i].getVariables().getFromIndex(0), 0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("TimePlayed")), "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDRockTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDRockTextObjects1[i].getBehavior("Tween").addVariableTween("RockNumber", gdjs.GameoverCode.GDRockTextObjects1[i].getVariables().getFromIndex(0), 0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RockCaught")), "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDBottleTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDBottleTextObjects1[i].getBehavior("Tween").addVariableTween("BottleNumber", gdjs.GameoverCode.GDBottleTextObjects1[i].getVariables().getFromIndex(0), 0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("BottleCaught")), "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDFishTextObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDFishTextObjects1[i].getBehavior("Tween").addVariableTween("FishNumber", gdjs.GameoverCode.GDFishTextObjects1[i].getVariables().getFromIndex(0), 0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("FishCaught")), "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.GameoverCode.GDNewBestScoreObjects1.length ;i < len;++i) {
    gdjs.GameoverCode.GDNewBestScoreObjects1[i].hide();
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "A-Sea-of-Stars.mp3", 1, false, 100, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "ScoreSFX.mp3", false, 150, 1);
}}

}


{


gdjs.GameoverCode.eventsList0(runtimeScene);
}


{


gdjs.GameoverCode.eventsList1(runtimeScene);
}


{


gdjs.GameoverCode.eventsList6(runtimeScene);
}


{


gdjs.GameoverCode.eventsList12(runtimeScene);
}


{


gdjs.GameoverCode.eventsList13(runtimeScene);
}


};

gdjs.GameoverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameoverCode.GDRestartObjects1.length = 0;
gdjs.GameoverCode.GDRestartObjects2.length = 0;
gdjs.GameoverCode.GDRestartObjects3.length = 0;
gdjs.GameoverCode.GDRestartObjects4.length = 0;
gdjs.GameoverCode.GDBackgroundObjects1.length = 0;
gdjs.GameoverCode.GDBackgroundObjects2.length = 0;
gdjs.GameoverCode.GDBackgroundObjects3.length = 0;
gdjs.GameoverCode.GDBackgroundObjects4.length = 0;
gdjs.GameoverCode.GDTimerLogoObjects1.length = 0;
gdjs.GameoverCode.GDTimerLogoObjects2.length = 0;
gdjs.GameoverCode.GDTimerLogoObjects3.length = 0;
gdjs.GameoverCode.GDTimerLogoObjects4.length = 0;
gdjs.GameoverCode.GDTimerTextObjects1.length = 0;
gdjs.GameoverCode.GDTimerTextObjects2.length = 0;
gdjs.GameoverCode.GDTimerTextObjects3.length = 0;
gdjs.GameoverCode.GDTimerTextObjects4.length = 0;
gdjs.GameoverCode.GDTimerScoreObjects1.length = 0;
gdjs.GameoverCode.GDTimerScoreObjects2.length = 0;
gdjs.GameoverCode.GDTimerScoreObjects3.length = 0;
gdjs.GameoverCode.GDTimerScoreObjects4.length = 0;
gdjs.GameoverCode.GDRockLogoObjects1.length = 0;
gdjs.GameoverCode.GDRockLogoObjects2.length = 0;
gdjs.GameoverCode.GDRockLogoObjects3.length = 0;
gdjs.GameoverCode.GDRockLogoObjects4.length = 0;
gdjs.GameoverCode.GDRockTextObjects1.length = 0;
gdjs.GameoverCode.GDRockTextObjects2.length = 0;
gdjs.GameoverCode.GDRockTextObjects3.length = 0;
gdjs.GameoverCode.GDRockTextObjects4.length = 0;
gdjs.GameoverCode.GDRockScoreObjects1.length = 0;
gdjs.GameoverCode.GDRockScoreObjects2.length = 0;
gdjs.GameoverCode.GDRockScoreObjects3.length = 0;
gdjs.GameoverCode.GDRockScoreObjects4.length = 0;
gdjs.GameoverCode.GDBottleLogoObjects1.length = 0;
gdjs.GameoverCode.GDBottleLogoObjects2.length = 0;
gdjs.GameoverCode.GDBottleLogoObjects3.length = 0;
gdjs.GameoverCode.GDBottleLogoObjects4.length = 0;
gdjs.GameoverCode.GDBottleTextObjects1.length = 0;
gdjs.GameoverCode.GDBottleTextObjects2.length = 0;
gdjs.GameoverCode.GDBottleTextObjects3.length = 0;
gdjs.GameoverCode.GDBottleTextObjects4.length = 0;
gdjs.GameoverCode.GDBottleScoreObjects1.length = 0;
gdjs.GameoverCode.GDBottleScoreObjects2.length = 0;
gdjs.GameoverCode.GDBottleScoreObjects3.length = 0;
gdjs.GameoverCode.GDBottleScoreObjects4.length = 0;
gdjs.GameoverCode.GDFishLogoObjects1.length = 0;
gdjs.GameoverCode.GDFishLogoObjects2.length = 0;
gdjs.GameoverCode.GDFishLogoObjects3.length = 0;
gdjs.GameoverCode.GDFishLogoObjects4.length = 0;
gdjs.GameoverCode.GDFishTextObjects1.length = 0;
gdjs.GameoverCode.GDFishTextObjects2.length = 0;
gdjs.GameoverCode.GDFishTextObjects3.length = 0;
gdjs.GameoverCode.GDFishTextObjects4.length = 0;
gdjs.GameoverCode.GDFishScoreObjects1.length = 0;
gdjs.GameoverCode.GDFishScoreObjects2.length = 0;
gdjs.GameoverCode.GDFishScoreObjects3.length = 0;
gdjs.GameoverCode.GDFishScoreObjects4.length = 0;
gdjs.GameoverCode.GDTotalScoreObjects1.length = 0;
gdjs.GameoverCode.GDTotalScoreObjects2.length = 0;
gdjs.GameoverCode.GDTotalScoreObjects3.length = 0;
gdjs.GameoverCode.GDTotalScoreObjects4.length = 0;
gdjs.GameoverCode.GDTandaXObjects1.length = 0;
gdjs.GameoverCode.GDTandaXObjects2.length = 0;
gdjs.GameoverCode.GDTandaXObjects3.length = 0;
gdjs.GameoverCode.GDTandaXObjects4.length = 0;
gdjs.GameoverCode.GDAngka1Objects1.length = 0;
gdjs.GameoverCode.GDAngka1Objects2.length = 0;
gdjs.GameoverCode.GDAngka1Objects3.length = 0;
gdjs.GameoverCode.GDAngka1Objects4.length = 0;
gdjs.GameoverCode.GDAngka3Objects1.length = 0;
gdjs.GameoverCode.GDAngka3Objects2.length = 0;
gdjs.GameoverCode.GDAngka3Objects3.length = 0;
gdjs.GameoverCode.GDAngka3Objects4.length = 0;
gdjs.GameoverCode.GDAngka5Objects1.length = 0;
gdjs.GameoverCode.GDAngka5Objects2.length = 0;
gdjs.GameoverCode.GDAngka5Objects3.length = 0;
gdjs.GameoverCode.GDAngka5Objects4.length = 0;
gdjs.GameoverCode.GDAngka5NegatifObjects1.length = 0;
gdjs.GameoverCode.GDAngka5NegatifObjects2.length = 0;
gdjs.GameoverCode.GDAngka5NegatifObjects3.length = 0;
gdjs.GameoverCode.GDAngka5NegatifObjects4.length = 0;
gdjs.GameoverCode.GDYourScoreObjects1.length = 0;
gdjs.GameoverCode.GDYourScoreObjects2.length = 0;
gdjs.GameoverCode.GDYourScoreObjects3.length = 0;
gdjs.GameoverCode.GDYourScoreObjects4.length = 0;
gdjs.GameoverCode.GDYourBestObjects1.length = 0;
gdjs.GameoverCode.GDYourBestObjects2.length = 0;
gdjs.GameoverCode.GDYourBestObjects3.length = 0;
gdjs.GameoverCode.GDYourBestObjects4.length = 0;
gdjs.GameoverCode.GDBestScoreObjects1.length = 0;
gdjs.GameoverCode.GDBestScoreObjects2.length = 0;
gdjs.GameoverCode.GDBestScoreObjects3.length = 0;
gdjs.GameoverCode.GDBestScoreObjects4.length = 0;
gdjs.GameoverCode.GDNewBestScoreObjects1.length = 0;
gdjs.GameoverCode.GDNewBestScoreObjects2.length = 0;
gdjs.GameoverCode.GDNewBestScoreObjects3.length = 0;
gdjs.GameoverCode.GDNewBestScoreObjects4.length = 0;
gdjs.GameoverCode.GDBestScore2Objects1.length = 0;
gdjs.GameoverCode.GDBestScore2Objects2.length = 0;
gdjs.GameoverCode.GDBestScore2Objects3.length = 0;
gdjs.GameoverCode.GDBestScore2Objects4.length = 0;

gdjs.GameoverCode.eventsList14(runtimeScene);
return;

}

gdjs['GameoverCode'] = gdjs.GameoverCode;
