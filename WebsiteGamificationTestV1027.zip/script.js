/*const myURL = new URL("http://127.0.0.1:5500/index.html");
            myURL.searchParams.append('x',42);
            console.log(myURL.search);*/

          
          
          
          /*  const data = { username: 'example' };

            fetch('https://wsdl.maybankfinance.co.id:8282/api/BackToWork_Main/BackToWork/GetTop_10_Highscore', 
                    {
                        method: 'POST', 
                        headers: {
                                    'Content-Type': 'application/json',
                                    'X-Auth-Token':'6GfwBwJcYNtfldKkjScCy2GQJuL6ZAnjFC8KIKa0',
                                 },
                        body: JSON.stringify(data),
                        mode:"cors",
                        cache:"default",
                    }
                )

                .then(response => response.json())
                .then(data => {console.log('Success:', data);})
                .catch((error) => {console.error('Error:', error);});


*/

            