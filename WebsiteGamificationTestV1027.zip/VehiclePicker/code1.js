gdjs.Level1_95ConstructCode = {};
gdjs.Level1_95ConstructCode.GDCustomer2Objects3_1final = [];

gdjs.Level1_95ConstructCode.GDCustomerObjects3_1final = [];

gdjs.Level1_95ConstructCode.GDPoint1Objects3_1final = [];

gdjs.Level1_95ConstructCode.GDPointAObjects3_1final = [];

gdjs.Level1_95ConstructCode.repeatCount3 = 0;

gdjs.Level1_95ConstructCode.repeatCount4 = 0;

gdjs.Level1_95ConstructCode.repeatIndex3 = 0;

gdjs.Level1_95ConstructCode.repeatIndex4 = 0;

gdjs.Level1_95ConstructCode.GDPoint1Objects1= [];
gdjs.Level1_95ConstructCode.GDPoint1Objects2= [];
gdjs.Level1_95ConstructCode.GDPoint1Objects3= [];
gdjs.Level1_95ConstructCode.GDPoint1Objects4= [];
gdjs.Level1_95ConstructCode.GDPoint1Objects5= [];
gdjs.Level1_95ConstructCode.GDTapObjects1= [];
gdjs.Level1_95ConstructCode.GDTapObjects2= [];
gdjs.Level1_95ConstructCode.GDTapObjects3= [];
gdjs.Level1_95ConstructCode.GDTapObjects4= [];
gdjs.Level1_95ConstructCode.GDTapObjects5= [];
gdjs.Level1_95ConstructCode.GDPoint2Objects1= [];
gdjs.Level1_95ConstructCode.GDPoint2Objects2= [];
gdjs.Level1_95ConstructCode.GDPoint2Objects3= [];
gdjs.Level1_95ConstructCode.GDPoint2Objects4= [];
gdjs.Level1_95ConstructCode.GDPoint2Objects5= [];
gdjs.Level1_95ConstructCode.GDPoint3Objects1= [];
gdjs.Level1_95ConstructCode.GDPoint3Objects2= [];
gdjs.Level1_95ConstructCode.GDPoint3Objects3= [];
gdjs.Level1_95ConstructCode.GDPoint3Objects4= [];
gdjs.Level1_95ConstructCode.GDPoint3Objects5= [];
gdjs.Level1_95ConstructCode.GDPoint4Objects1= [];
gdjs.Level1_95ConstructCode.GDPoint4Objects2= [];
gdjs.Level1_95ConstructCode.GDPoint4Objects3= [];
gdjs.Level1_95ConstructCode.GDPoint4Objects4= [];
gdjs.Level1_95ConstructCode.GDPoint4Objects5= [];
gdjs.Level1_95ConstructCode.GDPointAObjects1= [];
gdjs.Level1_95ConstructCode.GDPointAObjects2= [];
gdjs.Level1_95ConstructCode.GDPointAObjects3= [];
gdjs.Level1_95ConstructCode.GDPointAObjects4= [];
gdjs.Level1_95ConstructCode.GDPointAObjects5= [];
gdjs.Level1_95ConstructCode.GDPointBObjects1= [];
gdjs.Level1_95ConstructCode.GDPointBObjects2= [];
gdjs.Level1_95ConstructCode.GDPointBObjects3= [];
gdjs.Level1_95ConstructCode.GDPointBObjects4= [];
gdjs.Level1_95ConstructCode.GDPointBObjects5= [];
gdjs.Level1_95ConstructCode.GDPointCObjects1= [];
gdjs.Level1_95ConstructCode.GDPointCObjects2= [];
gdjs.Level1_95ConstructCode.GDPointCObjects3= [];
gdjs.Level1_95ConstructCode.GDPointCObjects4= [];
gdjs.Level1_95ConstructCode.GDPointCObjects5= [];
gdjs.Level1_95ConstructCode.GDPointDObjects1= [];
gdjs.Level1_95ConstructCode.GDPointDObjects2= [];
gdjs.Level1_95ConstructCode.GDPointDObjects3= [];
gdjs.Level1_95ConstructCode.GDPointDObjects4= [];
gdjs.Level1_95ConstructCode.GDPointDObjects5= [];
gdjs.Level1_95ConstructCode.GDCustomerObjects1= [];
gdjs.Level1_95ConstructCode.GDCustomerObjects2= [];
gdjs.Level1_95ConstructCode.GDCustomerObjects3= [];
gdjs.Level1_95ConstructCode.GDCustomerObjects4= [];
gdjs.Level1_95ConstructCode.GDCustomerObjects5= [];
gdjs.Level1_95ConstructCode.GDCustomer2Objects1= [];
gdjs.Level1_95ConstructCode.GDCustomer2Objects2= [];
gdjs.Level1_95ConstructCode.GDCustomer2Objects3= [];
gdjs.Level1_95ConstructCode.GDCustomer2Objects4= [];
gdjs.Level1_95ConstructCode.GDCustomer2Objects5= [];
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects1= [];
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects2= [];
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects3= [];
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects4= [];
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects5= [];
gdjs.Level1_95ConstructCode.GDMasterObjects1= [];
gdjs.Level1_95ConstructCode.GDMasterObjects2= [];
gdjs.Level1_95ConstructCode.GDMasterObjects3= [];
gdjs.Level1_95ConstructCode.GDMasterObjects4= [];
gdjs.Level1_95ConstructCode.GDMasterObjects5= [];
gdjs.Level1_95ConstructCode.GDOptionBObjects1= [];
gdjs.Level1_95ConstructCode.GDOptionBObjects2= [];
gdjs.Level1_95ConstructCode.GDOptionBObjects3= [];
gdjs.Level1_95ConstructCode.GDOptionBObjects4= [];
gdjs.Level1_95ConstructCode.GDOptionBObjects5= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects1= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects2= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects3= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects4= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects5= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects1= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects2= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects3= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects4= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects5= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects1= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects2= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects3= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects4= [];
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects5= [];
gdjs.Level1_95ConstructCode.GDOptionAObjects1= [];
gdjs.Level1_95ConstructCode.GDOptionAObjects2= [];
gdjs.Level1_95ConstructCode.GDOptionAObjects3= [];
gdjs.Level1_95ConstructCode.GDOptionAObjects4= [];
gdjs.Level1_95ConstructCode.GDOptionAObjects5= [];
gdjs.Level1_95ConstructCode.GDTestTimerObjects1= [];
gdjs.Level1_95ConstructCode.GDTestTimerObjects2= [];
gdjs.Level1_95ConstructCode.GDTestTimerObjects3= [];
gdjs.Level1_95ConstructCode.GDTestTimerObjects4= [];
gdjs.Level1_95ConstructCode.GDTestTimerObjects5= [];
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects1= [];
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2= [];
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3= [];
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4= [];
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects5= [];
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects1= [];
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2= [];
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3= [];
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4= [];
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects5= [];
gdjs.Level1_95ConstructCode.GDPoinObjects1= [];
gdjs.Level1_95ConstructCode.GDPoinObjects2= [];
gdjs.Level1_95ConstructCode.GDPoinObjects3= [];
gdjs.Level1_95ConstructCode.GDPoinObjects4= [];
gdjs.Level1_95ConstructCode.GDPoinObjects5= [];
gdjs.Level1_95ConstructCode.GDSpawnerObjects1= [];
gdjs.Level1_95ConstructCode.GDSpawnerObjects2= [];
gdjs.Level1_95ConstructCode.GDSpawnerObjects3= [];
gdjs.Level1_95ConstructCode.GDSpawnerObjects4= [];
gdjs.Level1_95ConstructCode.GDSpawnerObjects5= [];
gdjs.Level1_95ConstructCode.GDSpawner2Objects1= [];
gdjs.Level1_95ConstructCode.GDSpawner2Objects2= [];
gdjs.Level1_95ConstructCode.GDSpawner2Objects3= [];
gdjs.Level1_95ConstructCode.GDSpawner2Objects4= [];
gdjs.Level1_95ConstructCode.GDSpawner2Objects5= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects1= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects2= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects3= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects4= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects5= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects1= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects2= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects3= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects4= [];
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects5= [];
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects1= [];
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects2= [];
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects3= [];
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects4= [];
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects5= [];
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects1= [];
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects2= [];
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects3= [];
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects4= [];
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects5= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects1= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects2= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects3= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects4= [];
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects5= [];
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects1= [];
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects2= [];
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects3= [];
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects4= [];
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects5= [];
gdjs.Level1_95ConstructCode.GDBackgroundObjects1= [];
gdjs.Level1_95ConstructCode.GDBackgroundObjects2= [];
gdjs.Level1_95ConstructCode.GDBackgroundObjects3= [];
gdjs.Level1_95ConstructCode.GDBackgroundObjects4= [];
gdjs.Level1_95ConstructCode.GDBackgroundObjects5= [];
gdjs.Level1_95ConstructCode.GDBUBBLEObjects1= [];
gdjs.Level1_95ConstructCode.GDBUBBLEObjects2= [];
gdjs.Level1_95ConstructCode.GDBUBBLEObjects3= [];
gdjs.Level1_95ConstructCode.GDBUBBLEObjects4= [];
gdjs.Level1_95ConstructCode.GDBUBBLEObjects5= [];
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1= [];
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects2= [];
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects3= [];
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects4= [];
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects5= [];
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects1= [];
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects2= [];
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects3= [];
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects4= [];
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects5= [];
gdjs.Level1_95ConstructCode.GDTigerObjects1= [];
gdjs.Level1_95ConstructCode.GDTigerObjects2= [];
gdjs.Level1_95ConstructCode.GDTigerObjects3= [];
gdjs.Level1_95ConstructCode.GDTigerObjects4= [];
gdjs.Level1_95ConstructCode.GDTigerObjects5= [];
gdjs.Level1_95ConstructCode.GDTimerObjects1= [];
gdjs.Level1_95ConstructCode.GDTimerObjects2= [];
gdjs.Level1_95ConstructCode.GDTimerObjects3= [];
gdjs.Level1_95ConstructCode.GDTimerObjects4= [];
gdjs.Level1_95ConstructCode.GDTimerObjects5= [];
gdjs.Level1_95ConstructCode.GDTimerTweenObjects1= [];
gdjs.Level1_95ConstructCode.GDTimerTweenObjects2= [];
gdjs.Level1_95ConstructCode.GDTimerTweenObjects3= [];
gdjs.Level1_95ConstructCode.GDTimerTweenObjects4= [];
gdjs.Level1_95ConstructCode.GDTimerTweenObjects5= [];
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects1= [];
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects2= [];
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects3= [];
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects4= [];
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects5= [];
gdjs.Level1_95ConstructCode.GDDarahObjects1= [];
gdjs.Level1_95ConstructCode.GDDarahObjects2= [];
gdjs.Level1_95ConstructCode.GDDarahObjects3= [];
gdjs.Level1_95ConstructCode.GDDarahObjects4= [];
gdjs.Level1_95ConstructCode.GDDarahObjects5= [];
gdjs.Level1_95ConstructCode.GDNyawaObjects1= [];
gdjs.Level1_95ConstructCode.GDNyawaObjects2= [];
gdjs.Level1_95ConstructCode.GDNyawaObjects3= [];
gdjs.Level1_95ConstructCode.GDNyawaObjects4= [];
gdjs.Level1_95ConstructCode.GDNyawaObjects5= [];

gdjs.Level1_95ConstructCode.conditionTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition0IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition1IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition2IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition3IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition4IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition5IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition6IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition7IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.condition8IsTrue_0 = {val:false};
gdjs.Level1_95ConstructCode.conditionTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition0IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition1IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition2IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition3IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition4IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition5IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition6IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition7IsTrue_1 = {val:false};
gdjs.Level1_95ConstructCode.condition8IsTrue_1 = {val:false};


gdjs.Level1_95ConstructCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Point4"), gdjs.Level1_95ConstructCode.GDPoint4Objects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint4Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint3Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint1Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint1Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint2Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint2Objects2[i].hide();
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects1);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects1);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects1);
gdjs.copyArray(runtimeScene.getObjects("PointD"), gdjs.Level1_95ConstructCode.GDPointDObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointAObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointBObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointBObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointCObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointCObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointDObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointDObjects1[i].hide();
}
}}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDTapObjects2Objects = Hashtable.newFrom({"Tap": gdjs.Level1_95ConstructCode.GDTapObjects2});
gdjs.Level1_95ConstructCode.eventsList1 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tap"), gdjs.Level1_95ConstructCode.GDTapObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTapObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTapObjects2[i].getBehavior("Tween").addObjectPositionYTween("TapTweeN", 64, "easeInQuad", 300, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tap"), gdjs.Level1_95ConstructCode.GDTapObjects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDTapObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10538692);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("TweenTap").setNumber(1);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenTap")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tap"), gdjs.Level1_95ConstructCode.GDTapObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTapObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTapObjects1[i].getBehavior("Tween").addObjectPositionYTween("TapTweeN", -(942), "easeInQuad", 200, false);
}
}}

}


};gdjs.Level1_95ConstructCode.eventsList2 = function(runtimeScene) {

};gdjs.Level1_95ConstructCode.eventsList3 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn_Customer_Left");
}{runtimeScene.getVariables().get("Timer_Customer_Left").setNumber(1);
}}

}


{


gdjs.Level1_95ConstructCode.repeatCount4 = 1;
for(gdjs.Level1_95ConstructCode.repeatIndex4 = 0;gdjs.Level1_95ConstructCode.repeatIndex4 < gdjs.Level1_95ConstructCode.repeatCount4;++gdjs.Level1_95ConstructCode.repeatIndex4) {

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Spawn_Customer_Left") > 1;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stop_Timer")) == 0;
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val)
{
{runtimeScene.getVariables().get("Timer_Customer_Left").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn_Customer_Left");
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_1.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects3[k] = gdjs.Level1_95ConstructCode.GDPointAObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects3[k] = gdjs.Level1_95ConstructCode.GDPointBObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointCObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPointCObjects3[k] = gdjs.Level1_95ConstructCode.GDPointCObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointCObjects3.length = k;}}
}
gdjs.Level1_95ConstructCode.conditionTrue_1.val = true && gdjs.Level1_95ConstructCode.condition0IsTrue_1.val && gdjs.Level1_95ConstructCode.condition1IsTrue_1.val && gdjs.Level1_95ConstructCode.condition2IsTrue_1.val;
}
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("Stop_Timer").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects2);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects2);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects2[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects2[k] = gdjs.Level1_95ConstructCode.GDPointAObjects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects2.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects2[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects2[k] = gdjs.Level1_95ConstructCode.GDPointBObjects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects2.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointCObjects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointCObjects2[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointCObjects2[k] = gdjs.Level1_95ConstructCode.GDPointCObjects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointCObjects2.length = k;}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("Stop_Timer").setNumber(0);
}}

}


};gdjs.Level1_95ConstructCode.eventsList4 = function(runtimeScene) {

};gdjs.Level1_95ConstructCode.eventsList5 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn_Customer_Left_2");
}{runtimeScene.getVariables().get("Timer_Customer_Right").setNumber(1);
}}

}


{


gdjs.Level1_95ConstructCode.repeatCount4 = 1;
for(gdjs.Level1_95ConstructCode.repeatIndex4 = 0;gdjs.Level1_95ConstructCode.repeatIndex4 < gdjs.Level1_95ConstructCode.repeatCount4;++gdjs.Level1_95ConstructCode.repeatIndex4) {

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Spawn_Customer_Left_2") > 1;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Stop_Timer_2")) == 0;
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val)
{
{runtimeScene.getVariables().get("Timer_Customer_Right").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn_Customer_Left_2");
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_1.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_1.val = true;
        gdjs.Level1_95ConstructCode.GDPoint3Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint3Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint3Objects3.length = k;}}
}
gdjs.Level1_95ConstructCode.conditionTrue_1.val = true && gdjs.Level1_95ConstructCode.condition0IsTrue_1.val && gdjs.Level1_95ConstructCode.condition1IsTrue_1.val && gdjs.Level1_95ConstructCode.condition2IsTrue_1.val;
}
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("Stop_Timer_2").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint3Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint3Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint3Objects3.length = k;}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("Stop_Timer_2").setNumber(0);
}}

}


{


{
}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects4[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects4[k] = gdjs.Level1_95ConstructCode.GDPointAObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10552860);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomerObjects3, gdjs.Level1_95ConstructCode.GDCustomerObjects4);

/* Reuse gdjs.Level1_95ConstructCode.GDPointAObjects4 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects4.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects4[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointAObjects4.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointAObjects4[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects4);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects4[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects4[k] = gdjs.Level1_95ConstructCode.GDPointAObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects4[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects4[k] = gdjs.Level1_95ConstructCode.GDPointBObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10554116);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomerObjects3, gdjs.Level1_95ConstructCode.GDCustomerObjects4);

/* Reuse gdjs.Level1_95ConstructCode.GDPointBObjects4 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects4.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects4[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointBObjects4.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointBObjects4[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects3[k] = gdjs.Level1_95ConstructCode.GDPointBObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointCObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointCObjects3[k] = gdjs.Level1_95ConstructCode.GDPointCObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointCObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10555164);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointCObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointCObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointCObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects = Hashtable.newFrom({"PointA": gdjs.Level1_95ConstructCode.GDPointAObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects4Objects = Hashtable.newFrom({"PointA": gdjs.Level1_95ConstructCode.GDPointAObjects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects4Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects = Hashtable.newFrom({"PointB": gdjs.Level1_95ConstructCode.GDPointBObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects = Hashtable.newFrom({"PointB": gdjs.Level1_95ConstructCode.GDPointBObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects = Hashtable.newFrom({"PointC": gdjs.Level1_95ConstructCode.GDPointCObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects = Hashtable.newFrom({"PointC": gdjs.Level1_95ConstructCode.GDPointCObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects3Objects = Hashtable.newFrom({"OptionA": gdjs.Level1_95ConstructCode.GDOptionAObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects = Hashtable.newFrom({"PointA": gdjs.Level1_95ConstructCode.GDPointAObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects = Hashtable.newFrom({"Point1": gdjs.Level1_95ConstructCode.GDPoint1Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects = Hashtable.newFrom({"PointB": gdjs.Level1_95ConstructCode.GDPointBObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects = Hashtable.newFrom({"PointC": gdjs.Level1_95ConstructCode.GDPointCObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDSpawnerObjects3Objects = Hashtable.newFrom({"Spawner": gdjs.Level1_95ConstructCode.GDSpawnerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointDObjects2Objects = Hashtable.newFrom({"PointD": gdjs.Level1_95ConstructCode.GDPointDObjects2});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects2Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects2});
gdjs.Level1_95ConstructCode.eventsList7 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Timer_Customer_Left")) == 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.Level1_95ConstructCode.GDSpawnerObjects3);
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, (( gdjs.Level1_95ConstructCode.GDSpawnerObjects3.length === 0 ) ? 0 :gdjs.Level1_95ConstructCode.GDSpawnerObjects3[0].getPointX("")), (( gdjs.Level1_95ConstructCode.GDSpawnerObjects3.length === 0 ) ? 0 :gdjs.Level1_95ConstructCode.GDSpawnerObjects3[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Timer_Customer_Left").setNumber(1);
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setSize(98, 161);
}
}
{ //Subevents
gdjs.Level1_95ConstructCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10555764);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointAObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointAObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointAObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(0);
}
}}

}


{

gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = 0;

gdjs.Level1_95ConstructCode.GDPointAObjects3.length = 0;


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.GDCustomerObjects3_1final.length = 0;gdjs.Level1_95ConstructCode.GDPointAObjects3_1final.length = 0;gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects4);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects4);
gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects4Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects4Objects, true, runtimeScene, false);
if( gdjs.Level1_95ConstructCode.condition0IsTrue_1.val ) {
    gdjs.Level1_95ConstructCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1_95ConstructCode.GDCustomerObjects4.length;j<jLen;++j) {
        if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3_1final.indexOf(gdjs.Level1_95ConstructCode.GDCustomerObjects4[j]) === -1 )
            gdjs.Level1_95ConstructCode.GDCustomerObjects3_1final.push(gdjs.Level1_95ConstructCode.GDCustomerObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level1_95ConstructCode.GDPointAObjects4.length;j<jLen;++j) {
        if ( gdjs.Level1_95ConstructCode.GDPointAObjects3_1final.indexOf(gdjs.Level1_95ConstructCode.GDPointAObjects4[j]) === -1 )
            gdjs.Level1_95ConstructCode.GDPointAObjects3_1final.push(gdjs.Level1_95ConstructCode.GDPointAObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomerObjects3_1final, gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDPointAObjects3_1final, gdjs.Level1_95ConstructCode.GDPointAObjects3);
}
}
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10557020);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointAObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointAObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointAObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects3[k] = gdjs.Level1_95ConstructCode.GDPointAObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10558740);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointBObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointBObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointBObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10559428);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointBObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointBObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointBObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects3[k] = gdjs.Level1_95ConstructCode.GDPointBObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10561012);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointCObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointCObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointCObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10561972);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointCObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPointCObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPointCObjects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{



}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_A"), gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3);
gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition5IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition6IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition7IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects3[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition5IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects3[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition5IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition6IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10564812);
}
}if ( gdjs.Level1_95ConstructCode.condition6IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3[i].getString() == "v" ) {
        gdjs.Level1_95ConstructCode.condition7IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3[k] = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3.length = k;}}
}
}
}
}
}
}
if (gdjs.Level1_95ConstructCode.condition7IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Point4"), gdjs.Level1_95ConstructCode.GDPoint4Objects3);
gdjs.copyArray(runtimeScene.getObjects("PointD"), gdjs.Level1_95ConstructCode.GDPointDObjects3);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointDObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointDObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint4Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint4Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Move"), false);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects3[k] = gdjs.Level1_95ConstructCode.GDPointAObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointBObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects3[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition3IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10566828);
}
}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointAObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointAObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointAObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects3[k] = gdjs.Level1_95ConstructCode.GDPointAObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects3[k] = gdjs.Level1_95ConstructCode.GDPointBObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointCObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects3[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition4IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10568612);
}
}}
}
}
}
if (gdjs.Level1_95ConstructCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointBObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointBObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointBObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects3);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.Level1_95ConstructCode.GDSpawnerObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointBObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointBObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointBObjects3[k] = gdjs.Level1_95ConstructCode.GDPointBObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointCObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointCObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointCObjects3[k] = gdjs.Level1_95ConstructCode.GDPointCObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointCObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDSpawnerObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects3[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition4IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10570540);
}
}}
}
}
}
if (gdjs.Level1_95ConstructCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPointCObjects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointCObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointCObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects2);
gdjs.copyArray(runtimeScene.getObjects("PointD"), gdjs.Level1_95ConstructCode.GDPointDObjects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointDObjects2Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10571372);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects2 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects4[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects4[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10574092);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomer2Objects3, gdjs.Level1_95ConstructCode.GDCustomer2Objects4);

/* Reuse gdjs.Level1_95ConstructCode.GDPoint1Objects4 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects4.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects4[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint1Objects4.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint1Objects4[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects4[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects4[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects4[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects4[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects4[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10575348);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomer2Objects3, gdjs.Level1_95ConstructCode.GDCustomer2Objects4);

/* Reuse gdjs.Level1_95ConstructCode.GDPoint2Objects4 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects4.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects4[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint2Objects4.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint2Objects4[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint3Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint3Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint3Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10576396);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint3Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint3Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint3Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects = Hashtable.newFrom({"Point1": gdjs.Level1_95ConstructCode.GDPoint1Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects4Objects = Hashtable.newFrom({"Point1": gdjs.Level1_95ConstructCode.GDPoint1Objects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects4Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects = Hashtable.newFrom({"Point2": gdjs.Level1_95ConstructCode.GDPoint2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects = Hashtable.newFrom({"Point2": gdjs.Level1_95ConstructCode.GDPoint2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects = Hashtable.newFrom({"Point3": gdjs.Level1_95ConstructCode.GDPoint3Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects = Hashtable.newFrom({"Point3": gdjs.Level1_95ConstructCode.GDPoint3Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects3Objects = Hashtable.newFrom({"OptionB": gdjs.Level1_95ConstructCode.GDOptionBObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects = Hashtable.newFrom({"Customer": gdjs.Level1_95ConstructCode.GDCustomerObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects = Hashtable.newFrom({"PointA": gdjs.Level1_95ConstructCode.GDPointAObjects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects = Hashtable.newFrom({"Point1": gdjs.Level1_95ConstructCode.GDPoint1Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects = Hashtable.newFrom({"Point2": gdjs.Level1_95ConstructCode.GDPoint2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects = Hashtable.newFrom({"Point3": gdjs.Level1_95ConstructCode.GDPoint3Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDSpawner2Objects3Objects = Hashtable.newFrom({"Spawner2": gdjs.Level1_95ConstructCode.GDSpawner2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects3});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint4Objects2Objects = Hashtable.newFrom({"Point4": gdjs.Level1_95ConstructCode.GDPoint4Objects2});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects2Objects = Hashtable.newFrom({"Customer2": gdjs.Level1_95ConstructCode.GDCustomer2Objects2});
gdjs.Level1_95ConstructCode.eventsList9 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Timer_Customer_Right")) == 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Spawner2"), gdjs.Level1_95ConstructCode.GDSpawner2Objects3);
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, (( gdjs.Level1_95ConstructCode.GDSpawner2Objects3.length === 0 ) ? 0 :gdjs.Level1_95ConstructCode.GDSpawner2Objects3[0].getPointX("")), (( gdjs.Level1_95ConstructCode.GDSpawner2Objects3.length === 0 ) ? 0 :gdjs.Level1_95ConstructCode.GDSpawner2Objects3[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Timer_Customer_Right").setNumber(1);
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setSize(98, 161);
}
}
{ //Subevents
gdjs.Level1_95ConstructCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10577044);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint1Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(0);
}
}}

}


{

gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = 0;

gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = 0;


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects3_1final.length = 0;gdjs.Level1_95ConstructCode.GDPoint1Objects3_1final.length = 0;gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects4);
gdjs.Level1_95ConstructCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects4Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects4Objects, true, runtimeScene, false);
if( gdjs.Level1_95ConstructCode.condition0IsTrue_1.val ) {
    gdjs.Level1_95ConstructCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1_95ConstructCode.GDCustomer2Objects4.length;j<jLen;++j) {
        if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3_1final.indexOf(gdjs.Level1_95ConstructCode.GDCustomer2Objects4[j]) === -1 )
            gdjs.Level1_95ConstructCode.GDCustomer2Objects3_1final.push(gdjs.Level1_95ConstructCode.GDCustomer2Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level1_95ConstructCode.GDPoint1Objects4.length;j<jLen;++j) {
        if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3_1final.indexOf(gdjs.Level1_95ConstructCode.GDPoint1Objects4[j]) === -1 )
            gdjs.Level1_95ConstructCode.GDPoint1Objects3_1final.push(gdjs.Level1_95ConstructCode.GDPoint1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDCustomer2Objects3_1final, gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(gdjs.Level1_95ConstructCode.GDPoint1Objects3_1final, gdjs.Level1_95ConstructCode.GDPoint1Objects3);
}
}
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10578564);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint1Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10579484);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint2Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, true, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10580724);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint2Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10582100);
}
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint3Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, true, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10583060);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint3Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].setVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_B"), gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3);
gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition5IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition6IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition7IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomerObjects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPointAObjects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint1Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects3[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition5IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects3[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition5IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[i].getString() == "v" ) {
        gdjs.Level1_95ConstructCode.condition6IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[k] = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition6IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition7IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10585332);
}
}}
}
}
}
}
}
}
if (gdjs.Level1_95ConstructCode.condition7IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Point4"), gdjs.Level1_95ConstructCode.GDPoint4Objects3);
gdjs.copyArray(runtimeScene.getObjects("PointD"), gdjs.Level1_95ConstructCode.GDPointDObjects3);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPointDObjects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPointDObjects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint4Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint4Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Move"), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects3[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition3IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10586652);
}
}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint1Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint1Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint1Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint3Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects3[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition4IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10588756);
}
}}
}
}
}
if (gdjs.Level1_95ConstructCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint2Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint2Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint2Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spawner2"), gdjs.Level1_95ConstructCode.GDSpawner2Objects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition4IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint2Objects3[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint2Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint3Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint3Objects3[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint3Objects3[k] = gdjs.Level1_95ConstructCode.GDPoint3Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint3Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDSpawner2Objects3Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects3Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects3[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = k;}if ( gdjs.Level1_95ConstructCode.condition3IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition4IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10590156);
}
}}
}
}
}
if (gdjs.Level1_95ConstructCode.condition4IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects3 */
/* Reuse gdjs.Level1_95ConstructCode.GDPoint3Objects3 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].addForceTowardObject((gdjs.Level1_95ConstructCode.GDPoint3Objects3.length !== 0 ? gdjs.Level1_95ConstructCode.GDPoint3Objects3[0] : null), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Speed")), 1);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Point4"), gdjs.Level1_95ConstructCode.GDPoint4Objects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDPoint4Objects2Objects, gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDCustomer2Objects2Objects, false, runtimeScene, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10591188);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects2 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level1_95ConstructCode.eventsList10 = function(runtimeScene) {

{


{
}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("Speed").setNumber(500);
}}

}


{


gdjs.Level1_95ConstructCode.eventsList3(runtimeScene);
}


{


gdjs.Level1_95ConstructCode.eventsList5(runtimeScene);
}


{


gdjs.Level1_95ConstructCode.eventsList7(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Customer"), gdjs.Level1_95ConstructCode.GDCustomerObjects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomerObjects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomerObjects2[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomerObjects2[k] = gdjs.Level1_95ConstructCode.GDCustomerObjects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomerObjects2.length = k;}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomerObjects2 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomerObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomerObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.Level1_95ConstructCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Customer2"), gdjs.Level1_95ConstructCode.GDCustomer2Objects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCustomer2Objects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCustomer2Objects2[i].hasNoForces() ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCustomer2Objects2[k] = gdjs.Level1_95ConstructCode.GDCustomer2Objects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCustomer2Objects2.length = k;}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1_95ConstructCode.GDCustomer2Objects2 */
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCustomer2Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCustomer2Objects2[i].setAnimation(0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Point2"), gdjs.Level1_95ConstructCode.GDPoint2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Point3"), gdjs.Level1_95ConstructCode.GDPoint3Objects1);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects1);
gdjs.copyArray(runtimeScene.getObjects("PointB"), gdjs.Level1_95ConstructCode.GDPointBObjects1);
gdjs.copyArray(runtimeScene.getObjects("PointC"), gdjs.Level1_95ConstructCode.GDPointCObjects1);
gdjs.copyArray(runtimeScene.getObjects("Qty_Customer"), gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Qty_Customer2"), gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Test_Timer_Customer"), gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Test_Timer_Customer2"), gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_1"), gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_2"), gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_3"), gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_A"), gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_B"), gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects1);
gdjs.copyArray(runtimeScene.getObjects("test_fill_C"), gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Timer_Customer_Left")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Timer_Customer_Right")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Qty_Customer")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Qty_Customer_2")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPointAObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPointAObjects1[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPointBObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPointBObjects1[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPointCObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPointCObjects1[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPoint1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPoint1Objects1[0].getVariables()).get("Fill"))));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPoint2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPoint2Objects1[0].getVariables()).get("Fill"))));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1_95ConstructCode.GDPoint3Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1_95ConstructCode.GDPoint3Objects1[0].getVariables()).get("Fill"))));
}
}}

}


};gdjs.Level1_95ConstructCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects2);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects2);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects2[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects2[k] = gdjs.Level1_95ConstructCode.GDPointAObjects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects2.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects2.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects2[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects2[i].getVariables().get("Fill"), true) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects2[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects2[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects2.length = k;}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BUBBLE"), gdjs.Level1_95ConstructCode.GDBUBBLEObjects2);
gdjs.copyArray(runtimeScene.getObjects("BUBBLE2"), gdjs.Level1_95ConstructCode.GDBUBBLE2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Master"), gdjs.Level1_95ConstructCode.GDMasterObjects2);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects2);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects2);
{runtimeScene.getVariables().get("Start_Timer").setNumber(1);
}{runtimeScene.getVariables().get("Start_Timer_RandomSoal").setNumber(1);
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLEObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLE2Objects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLE2Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionAObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionAObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionBObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionBObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDMasterObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDMasterObjects2[i].hide(false);
}
}{runtimeScene.getVariables().get("Start_Game").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Point1"), gdjs.Level1_95ConstructCode.GDPoint1Objects1);
gdjs.copyArray(runtimeScene.getObjects("PointA"), gdjs.Level1_95ConstructCode.GDPointAObjects1);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPointAObjects1.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPointAObjects1[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPointAObjects1[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPointAObjects1[k] = gdjs.Level1_95ConstructCode.GDPointAObjects1[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPointAObjects1.length = k;}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDPoint1Objects1.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDPoint1Objects1[i].getVariableBoolean(gdjs.Level1_95ConstructCode.GDPoint1Objects1[i].getVariables().get("Fill"), false) ) {
        gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDPoint1Objects1[k] = gdjs.Level1_95ConstructCode.GDPoint1Objects1[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDPoint1Objects1.length = k;}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BUBBLE"), gdjs.Level1_95ConstructCode.GDBUBBLEObjects1);
gdjs.copyArray(runtimeScene.getObjects("BUBBLE2"), gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Master"), gdjs.Level1_95ConstructCode.GDMasterObjects1);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects1);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects1);
{runtimeScene.getVariables().get("Start_Timer").setNumber(0);
}{runtimeScene.getVariables().get("Start_Timer_RandomSoal").setNumber(0);
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionBObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionBObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionAObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLEObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLEObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDMasterObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDMasterObjects1[i].hide();
}
}{runtimeScene.getVariables().get("Start_Game").setNumber(0);
}}

}


};gdjs.Level1_95ConstructCode.eventsList12 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Start_Game")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_Master"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionA"), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionB"), true);
}{runtimeScene.getVariables().get("Start_Select").setNumber(1);
}}

}


{



}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Start_Random_Master"), true);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10604444);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("Master").setNumber(gdjs.randomInRange(0, 1));
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Master")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Master"), gdjs.Level1_95ConstructCode.GDMasterObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDMasterObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDMasterObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_Master"), false);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Master")) == 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Master"), gdjs.Level1_95ConstructCode.GDMasterObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDMasterObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDMasterObjects2[i].setAnimation(1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_Master"), false);
}}

}


{



}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionA"), true);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10607524);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("OptionA").setNumber(gdjs.randomInRange(0, 1));
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionA")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionAObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionAObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionA"), false);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionA")) == 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionAObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionAObjects2[i].setAnimation(1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionA"), false);
}}

}


{



}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionB"), true);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition1IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10610124);
}
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("OptionB").setNumber(gdjs.randomInRange(0, 1));
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionB")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionBObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionBObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionB"), false);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionB")) == 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionBObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionBObjects2[i].setAnimation(1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Start_Random_OptionB"), false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Test_Random_Master"), gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_Random_OptionA"), gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_Random_OptionB"), gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Master")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("OptionA")));
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("OptionB")));
}
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionA")) == 1;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionB")) == 1;
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("OptionA").setNumber(1);
}{runtimeScene.getVariables().get("OptionB").setNumber(0);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionA")) == 0;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionB")) == 0;
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("OptionA").setNumber(0);
}{runtimeScene.getVariables().get("OptionB").setNumber(1);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionA")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Master")));
}
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Correct_A"), gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2);
gdjs.copyArray(runtimeScene.getObjects("Correct_B"), gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2[i].setString("v");
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2[i].setString("0");
}
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition0IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("OptionB")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Master")));
}
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Correct_A"), gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2);
gdjs.copyArray(runtimeScene.getObjects("Correct_B"), gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2[i].setString("0");
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2[i].setString("v");
}
}}

}


{


{
}

}


};gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects4Objects = Hashtable.newFrom({"OptionA": gdjs.Level1_95ConstructCode.GDOptionAObjects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects4Objects = Hashtable.newFrom({"OptionA": gdjs.Level1_95ConstructCode.GDOptionAObjects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects4Objects = Hashtable.newFrom({"OptionB": gdjs.Level1_95ConstructCode.GDOptionBObjects4});
gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects3Objects = Hashtable.newFrom({"OptionB": gdjs.Level1_95ConstructCode.GDOptionBObjects3});
gdjs.Level1_95ConstructCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Correct_A"), gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[i].getString() == "v" ) {
        gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[k] = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4.length = k;}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition3IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10619116);
}
}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("Poin").add(1);
}{runtimeScene.getVariables().get("Timer_Game_Utama").add(1);
}{runtimeScene.getVariables().get("TweenValue").add(8.3);
}{runtimeScene.getVariables().get("Start_Select").setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "415762__thebuilder15__notification-correct.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_A"), gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionAObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10621108);
}
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[i].getString() == "0" ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[k] = gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4.length = k;}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
{runtimeScene.getVariables().get("Timer_Game_Utama").sub(5);
}{runtimeScene.getVariables().get("TweenValue").sub(41.5);
}{runtimeScene.getVariables().get("Start_Select").setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "131657__bertrof__game-sound-wrong.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_B"), gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects4);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10622948);
}
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4[i].getString() == "v" ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4[k] = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4.length = k;}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("Poin").add(1);
}{runtimeScene.getVariables().get("Timer_Game_Utama").add(1);
}{runtimeScene.getVariables().get("TweenValue").add(8.3);
}{runtimeScene.getVariables().get("Start_Select").setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "415762__thebuilder15__notification-correct.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_B"), gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects3);

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1_95ConstructCode.mapOfGDgdjs_46Level1_9595ConstructCode_46GDOptionBObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
{gdjs.Level1_95ConstructCode.conditionTrue_1 = gdjs.Level1_95ConstructCode.condition2IsTrue_0;
gdjs.Level1_95ConstructCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10624956);
}
}if ( gdjs.Level1_95ConstructCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3.length;i<l;++i) {
    if ( gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[i].getString() == "0" ) {
        gdjs.Level1_95ConstructCode.condition3IsTrue_0.val = true;
        gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[k] = gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3[i];
        ++k;
    }
}
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3.length = k;}}
}
}
if (gdjs.Level1_95ConstructCode.condition3IsTrue_0.val) {
{runtimeScene.getVariables().get("Timer_Game_Utama").sub(5);
}{runtimeScene.getVariables().get("TweenValue").sub(41.5);
}{runtimeScene.getVariables().get("Start_Select").setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "131657__bertrof__game-sound-wrong.wav", false, 100, 1);
}}

}


};gdjs.Level1_95ConstructCode.eventsList14 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level1_95ConstructCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


{
}

}


};gdjs.Level1_95ConstructCode.eventsList15 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Start_Select")) == 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level1_95ConstructCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Poin"), gdjs.Level1_95ConstructCode.GDPoinObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDPoinObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDPoinObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Poin")));
}
}}

}


};gdjs.Level1_95ConstructCode.eventsList16 = function(runtimeScene) {

};gdjs.Level1_95ConstructCode.eventsList17 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.repeatCount3 = 1;
for(gdjs.Level1_95ConstructCode.repeatIndex3 = 0;gdjs.Level1_95ConstructCode.repeatIndex3 < gdjs.Level1_95ConstructCode.repeatCount3;++gdjs.Level1_95ConstructCode.repeatIndex3) {

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimerGame") > 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("Timer_Game_Utama").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerGame");
}{runtimeScene.getVariables().get("TweenValue").sub(8.3);
}}
}

}


};gdjs.Level1_95ConstructCode.eventsList18 = function(runtimeScene) {

};gdjs.Level1_95ConstructCode.eventsList19 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.repeatCount3 = 1;
for(gdjs.Level1_95ConstructCode.repeatIndex3 = 0;gdjs.Level1_95ConstructCode.repeatIndex3 < gdjs.Level1_95ConstructCode.repeatCount3;++gdjs.Level1_95ConstructCode.repeatIndex3) {

gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimerGame") > 1;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("Timer_Game_Utama").sub(2);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerGame");
}{runtimeScene.getVariables().get("TweenValue").sub(16.6);
}}
}

}


};gdjs.Level1_95ConstructCode.eventsList20 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerGame");
}{runtimeScene.getVariables().get("Timer_Game_Utama").setNumber(60);
}{runtimeScene.getVariables().get("TweenValue").setNumber(500);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Poin")) < 10;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Start_Game")) == 1;
}}
if (gdjs.Level1_95ConstructCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level1_95ConstructCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = false;
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Poin")) >= 10;
}if ( gdjs.Level1_95ConstructCode.condition0IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Poin")) < 50;
}if ( gdjs.Level1_95ConstructCode.condition1IsTrue_0.val ) {
{
gdjs.Level1_95ConstructCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Start_Game")) == 1;
}}
}
if (gdjs.Level1_95ConstructCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level1_95ConstructCode.eventsList19(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level1_95ConstructCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTimerObjects2[i].getBehavior("Tween").addObjectWidthTween("TweenTimer", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenValue")), "easeInQuad", 50, false);
}
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Timer_Game_Utama")) <= 0;
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerGame");
}{runtimeScene.getVariables().get("Start_Game").setNumber(0);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "EndGame", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("TimerTween"), gdjs.Level1_95ConstructCode.GDTimerTweenObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTimerTweenObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTimerTweenObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Timer_Game_Utama"))));
}
}}

}


};gdjs.Level1_95ConstructCode.eventsList21 = function(runtimeScene) {

{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "118750__novasoundtechnology__east-coast-drum-loop-tempo-90-nova-sound.mp3", true, 80, 1);
}}

}


{


gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = false;
{
gdjs.Level1_95ConstructCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1_95ConstructCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BUBBLE"), gdjs.Level1_95ConstructCode.GDBUBBLEObjects1);
gdjs.copyArray(runtimeScene.getObjects("BUBBLE2"), gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Master"), gdjs.Level1_95ConstructCode.GDMasterObjects1);
gdjs.copyArray(runtimeScene.getObjects("OptionA"), gdjs.Level1_95ConstructCode.GDOptionAObjects1);
gdjs.copyArray(runtimeScene.getObjects("OptionB"), gdjs.Level1_95ConstructCode.GDOptionBObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLEObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLEObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLEObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLEObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionAObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDOptionBObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDOptionBObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDMasterObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDMasterObjects1[i].hide();
}
}
{ //Subevents
gdjs.Level1_95ConstructCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Level1_95ConstructCode.eventsList1(runtimeScene);
}


{


{
}

}


{


gdjs.Level1_95ConstructCode.eventsList10(runtimeScene);
}


{


gdjs.Level1_95ConstructCode.eventsList11(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("TestStartTimer"), gdjs.Level1_95ConstructCode.GDTestStartTimerObjects1);
{for(var i = 0, len = gdjs.Level1_95ConstructCode.GDTestStartTimerObjects1.length ;i < len;++i) {
    gdjs.Level1_95ConstructCode.GDTestStartTimerObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Start_Timer")));
}
}}

}


{


gdjs.Level1_95ConstructCode.eventsList12(runtimeScene);
}


{


gdjs.Level1_95ConstructCode.eventsList15(runtimeScene);
}


{


gdjs.Level1_95ConstructCode.eventsList20(runtimeScene);
}


{


{
}

}


};

gdjs.Level1_95ConstructCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1_95ConstructCode.GDPoint1Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDPoint1Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDPoint1Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDPoint1Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDPoint1Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDTapObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTapObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTapObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTapObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTapObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDPoint2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDPoint2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDPoint2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDPoint2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDPoint2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDPoint3Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDPoint3Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDPoint3Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDPoint3Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDPoint3Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDPoint4Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDPoint4Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDPoint4Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDPoint4Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDPoint4Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDPointAObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDPointAObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDPointAObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDPointAObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDPointAObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDPointBObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDPointBObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDPointBObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDPointBObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDPointBObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDPointCObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDPointCObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDPointCObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDPointCObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDPointCObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDPointDObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDPointDObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDPointDObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDPointDObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDPointDObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDCustomerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDCustomerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDCustomerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDCustomerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDCustomerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTestStartTimerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDMasterObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDMasterObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDMasterObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDMasterObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDMasterObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDOptionBObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDOptionBObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDOptionBObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDOptionBObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDOptionBObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95MasterObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionAObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Random_95OptionBObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDOptionAObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDOptionAObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDOptionAObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDOptionAObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDOptionAObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTestTimerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTestTimerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTestTimerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTestTimerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTestTimerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95AObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDCorrect_95BObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDPoinObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDPoinObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDPoinObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDPoinObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDPoinObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDSpawnerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDSpawnerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDSpawnerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDSpawnerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDSpawnerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDSpawner2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDSpawner2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDSpawner2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDSpawner2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDSpawner2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95CustomerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDTest_95Timer_95Customer2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95CustomerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDQty_95Customer2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95AObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95BObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_95CObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_951Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_952Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDtest_95fill_953Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDCustomer_95StatusObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDBackgroundObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDBackgroundObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDBackgroundObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDBackgroundObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDBackgroundObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLEObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLEObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLEObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLEObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLEObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects1.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects2.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects3.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects4.length = 0;
gdjs.Level1_95ConstructCode.GDBUBBLE2Objects5.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95FrontOfficeDeskObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTigerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTigerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTigerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTigerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTigerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTimerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTimerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTimerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTimerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTimerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDTimerTweenObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDTimerTweenObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDTimerTweenObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDTimerTweenObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDTimerTweenObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDDecor_95TimerObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDDarahObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDDarahObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDDarahObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDDarahObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDDarahObjects5.length = 0;
gdjs.Level1_95ConstructCode.GDNyawaObjects1.length = 0;
gdjs.Level1_95ConstructCode.GDNyawaObjects2.length = 0;
gdjs.Level1_95ConstructCode.GDNyawaObjects3.length = 0;
gdjs.Level1_95ConstructCode.GDNyawaObjects4.length = 0;
gdjs.Level1_95ConstructCode.GDNyawaObjects5.length = 0;

gdjs.Level1_95ConstructCode.eventsList21(runtimeScene);
return;

}

gdjs['Level1_95ConstructCode'] = gdjs.Level1_95ConstructCode;
