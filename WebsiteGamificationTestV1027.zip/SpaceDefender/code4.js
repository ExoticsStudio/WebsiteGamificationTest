gdjs.WarCode = {};
gdjs.WarCode.GDBullet2Objects2_1final = [];

gdjs.WarCode.GDBullet3Objects2_1final = [];

gdjs.WarCode.GDBullet4Objects2_1final = [];

gdjs.WarCode.GDCrosshairObjects2_1final = [];

gdjs.WarCode.GDEnemyMasterObjects2_1final = [];

gdjs.WarCode.GDEnemyObjects2_1final = [];

gdjs.WarCode.GDEnemySmallObjects2_1final = [];

gdjs.WarCode.GDPlaneObjects2_1final = [];

gdjs.WarCode.repeatCount3 = 0;

gdjs.WarCode.repeatCount4 = 0;

gdjs.WarCode.repeatIndex3 = 0;

gdjs.WarCode.repeatIndex4 = 0;

gdjs.WarCode.GDBackgroundObjects1= [];
gdjs.WarCode.GDBackgroundObjects2= [];
gdjs.WarCode.GDBackgroundObjects3= [];
gdjs.WarCode.GDBackgroundObjects4= [];
gdjs.WarCode.GDBackgroundObjects5= [];
gdjs.WarCode.GDCollide_95ExplosionObjects1= [];
gdjs.WarCode.GDCollide_95ExplosionObjects2= [];
gdjs.WarCode.GDCollide_95ExplosionObjects3= [];
gdjs.WarCode.GDCollide_95ExplosionObjects4= [];
gdjs.WarCode.GDCollide_95ExplosionObjects5= [];
gdjs.WarCode.GDEnemyObjects1= [];
gdjs.WarCode.GDEnemyObjects2= [];
gdjs.WarCode.GDEnemyObjects3= [];
gdjs.WarCode.GDEnemyObjects4= [];
gdjs.WarCode.GDEnemyObjects5= [];
gdjs.WarCode.GDEnemyDummyObjects1= [];
gdjs.WarCode.GDEnemyDummyObjects2= [];
gdjs.WarCode.GDEnemyDummyObjects3= [];
gdjs.WarCode.GDEnemyDummyObjects4= [];
gdjs.WarCode.GDEnemyDummyObjects5= [];
gdjs.WarCode.GDEnemyMasterObjects1= [];
gdjs.WarCode.GDEnemyMasterObjects2= [];
gdjs.WarCode.GDEnemyMasterObjects3= [];
gdjs.WarCode.GDEnemyMasterObjects4= [];
gdjs.WarCode.GDEnemyMasterObjects5= [];
gdjs.WarCode.GDEnemySmallObjects1= [];
gdjs.WarCode.GDEnemySmallObjects2= [];
gdjs.WarCode.GDEnemySmallObjects3= [];
gdjs.WarCode.GDEnemySmallObjects4= [];
gdjs.WarCode.GDEnemySmallObjects5= [];
gdjs.WarCode.GDPlaneObjects1= [];
gdjs.WarCode.GDPlaneObjects2= [];
gdjs.WarCode.GDPlaneObjects3= [];
gdjs.WarCode.GDPlaneObjects4= [];
gdjs.WarCode.GDPlaneObjects5= [];
gdjs.WarCode.GDBulletObjects1= [];
gdjs.WarCode.GDBulletObjects2= [];
gdjs.WarCode.GDBulletObjects3= [];
gdjs.WarCode.GDBulletObjects4= [];
gdjs.WarCode.GDBulletObjects5= [];
gdjs.WarCode.GDBullet2Objects1= [];
gdjs.WarCode.GDBullet2Objects2= [];
gdjs.WarCode.GDBullet2Objects3= [];
gdjs.WarCode.GDBullet2Objects4= [];
gdjs.WarCode.GDBullet2Objects5= [];
gdjs.WarCode.GDBullet3Objects1= [];
gdjs.WarCode.GDBullet3Objects2= [];
gdjs.WarCode.GDBullet3Objects3= [];
gdjs.WarCode.GDBullet3Objects4= [];
gdjs.WarCode.GDBullet3Objects5= [];
gdjs.WarCode.GDBullet4Objects1= [];
gdjs.WarCode.GDBullet4Objects2= [];
gdjs.WarCode.GDBullet4Objects3= [];
gdjs.WarCode.GDBullet4Objects4= [];
gdjs.WarCode.GDBullet4Objects5= [];
gdjs.WarCode.GDEnemySpawnLocationObjects1= [];
gdjs.WarCode.GDEnemySpawnLocationObjects2= [];
gdjs.WarCode.GDEnemySpawnLocationObjects3= [];
gdjs.WarCode.GDEnemySpawnLocationObjects4= [];
gdjs.WarCode.GDEnemySpawnLocationObjects5= [];
gdjs.WarCode.GDCrosshairObjects1= [];
gdjs.WarCode.GDCrosshairObjects2= [];
gdjs.WarCode.GDCrosshairObjects3= [];
gdjs.WarCode.GDCrosshairObjects4= [];
gdjs.WarCode.GDCrosshairObjects5= [];
gdjs.WarCode.GDCrosshair_95CloneObjects1= [];
gdjs.WarCode.GDCrosshair_95CloneObjects2= [];
gdjs.WarCode.GDCrosshair_95CloneObjects3= [];
gdjs.WarCode.GDCrosshair_95CloneObjects4= [];
gdjs.WarCode.GDCrosshair_95CloneObjects5= [];
gdjs.WarCode.GDCrosshair_95TutorialObjects1= [];
gdjs.WarCode.GDCrosshair_95TutorialObjects2= [];
gdjs.WarCode.GDCrosshair_95TutorialObjects3= [];
gdjs.WarCode.GDCrosshair_95TutorialObjects4= [];
gdjs.WarCode.GDCrosshair_95TutorialObjects5= [];
gdjs.WarCode.GDPOINObjects1= [];
gdjs.WarCode.GDPOINObjects2= [];
gdjs.WarCode.GDPOINObjects3= [];
gdjs.WarCode.GDPOINObjects4= [];
gdjs.WarCode.GDPOINObjects5= [];
gdjs.WarCode.GDCannon_95RefillAnimObjects1= [];
gdjs.WarCode.GDCannon_95RefillAnimObjects2= [];
gdjs.WarCode.GDCannon_95RefillAnimObjects3= [];
gdjs.WarCode.GDCannon_95RefillAnimObjects4= [];
gdjs.WarCode.GDCannon_95RefillAnimObjects5= [];
gdjs.WarCode.GDStarsObjects1= [];
gdjs.WarCode.GDStarsObjects2= [];
gdjs.WarCode.GDStarsObjects3= [];
gdjs.WarCode.GDStarsObjects4= [];
gdjs.WarCode.GDStarsObjects5= [];
gdjs.WarCode.GDAddScoreObjects1= [];
gdjs.WarCode.GDAddScoreObjects2= [];
gdjs.WarCode.GDAddScoreObjects3= [];
gdjs.WarCode.GDAddScoreObjects4= [];
gdjs.WarCode.GDAddScoreObjects5= [];
gdjs.WarCode.GDAddScore2Objects1= [];
gdjs.WarCode.GDAddScore2Objects2= [];
gdjs.WarCode.GDAddScore2Objects3= [];
gdjs.WarCode.GDAddScore2Objects4= [];
gdjs.WarCode.GDAddScore2Objects5= [];
gdjs.WarCode.GDBtn_95backObjects1= [];
gdjs.WarCode.GDBtn_95backObjects2= [];
gdjs.WarCode.GDBtn_95backObjects3= [];
gdjs.WarCode.GDBtn_95backObjects4= [];
gdjs.WarCode.GDBtn_95backObjects5= [];
gdjs.WarCode.GDTripleShotObjects1= [];
gdjs.WarCode.GDTripleShotObjects2= [];
gdjs.WarCode.GDTripleShotObjects3= [];
gdjs.WarCode.GDTripleShotObjects4= [];
gdjs.WarCode.GDTripleShotObjects5= [];
gdjs.WarCode.GDTest_95SpawnDoubleObjects1= [];
gdjs.WarCode.GDTest_95SpawnDoubleObjects2= [];
gdjs.WarCode.GDTest_95SpawnDoubleObjects3= [];
gdjs.WarCode.GDTest_95SpawnDoubleObjects4= [];
gdjs.WarCode.GDTest_95SpawnDoubleObjects5= [];
gdjs.WarCode.GDTest_95SpawnTripleObjects1= [];
gdjs.WarCode.GDTest_95SpawnTripleObjects2= [];
gdjs.WarCode.GDTest_95SpawnTripleObjects3= [];
gdjs.WarCode.GDTest_95SpawnTripleObjects4= [];
gdjs.WarCode.GDTest_95SpawnTripleObjects5= [];
gdjs.WarCode.GDDragObjectBorderObjects1= [];
gdjs.WarCode.GDDragObjectBorderObjects2= [];
gdjs.WarCode.GDDragObjectBorderObjects3= [];
gdjs.WarCode.GDDragObjectBorderObjects4= [];
gdjs.WarCode.GDDragObjectBorderObjects5= [];
gdjs.WarCode.GDCannon1Objects1= [];
gdjs.WarCode.GDCannon1Objects2= [];
gdjs.WarCode.GDCannon1Objects3= [];
gdjs.WarCode.GDCannon1Objects4= [];
gdjs.WarCode.GDCannon1Objects5= [];
gdjs.WarCode.GDCannon3Objects1= [];
gdjs.WarCode.GDCannon3Objects2= [];
gdjs.WarCode.GDCannon3Objects3= [];
gdjs.WarCode.GDCannon3Objects4= [];
gdjs.WarCode.GDCannon3Objects5= [];
gdjs.WarCode.GDCannon2Objects1= [];
gdjs.WarCode.GDCannon2Objects2= [];
gdjs.WarCode.GDCannon2Objects3= [];
gdjs.WarCode.GDCannon2Objects4= [];
gdjs.WarCode.GDCannon2Objects5= [];
gdjs.WarCode.GDTapScreenObjects1= [];
gdjs.WarCode.GDTapScreenObjects2= [];
gdjs.WarCode.GDTapScreenObjects3= [];
gdjs.WarCode.GDTapScreenObjects4= [];
gdjs.WarCode.GDTapScreenObjects5= [];
gdjs.WarCode.GDGameStatusObjects1= [];
gdjs.WarCode.GDGameStatusObjects2= [];
gdjs.WarCode.GDGameStatusObjects3= [];
gdjs.WarCode.GDGameStatusObjects4= [];
gdjs.WarCode.GDGameStatusObjects5= [];
gdjs.WarCode.GDTimerEnemyObjects1= [];
gdjs.WarCode.GDTimerEnemyObjects2= [];
gdjs.WarCode.GDTimerEnemyObjects3= [];
gdjs.WarCode.GDTimerEnemyObjects4= [];
gdjs.WarCode.GDTimerEnemyObjects5= [];
gdjs.WarCode.GDTimerEnemy2Objects1= [];
gdjs.WarCode.GDTimerEnemy2Objects2= [];
gdjs.WarCode.GDTimerEnemy2Objects3= [];
gdjs.WarCode.GDTimerEnemy2Objects4= [];
gdjs.WarCode.GDTimerEnemy2Objects5= [];
gdjs.WarCode.GDTimerEnemy3Objects1= [];
gdjs.WarCode.GDTimerEnemy3Objects2= [];
gdjs.WarCode.GDTimerEnemy3Objects3= [];
gdjs.WarCode.GDTimerEnemy3Objects4= [];
gdjs.WarCode.GDTimerEnemy3Objects5= [];
gdjs.WarCode.GDProgressBarObjects1= [];
gdjs.WarCode.GDProgressBarObjects2= [];
gdjs.WarCode.GDProgressBarObjects3= [];
gdjs.WarCode.GDProgressBarObjects4= [];
gdjs.WarCode.GDProgressBarObjects5= [];
gdjs.WarCode.GDStartTextObjects1= [];
gdjs.WarCode.GDStartTextObjects2= [];
gdjs.WarCode.GDStartTextObjects3= [];
gdjs.WarCode.GDStartTextObjects4= [];
gdjs.WarCode.GDStartTextObjects5= [];
gdjs.WarCode.GDEndTextObjects1= [];
gdjs.WarCode.GDEndTextObjects2= [];
gdjs.WarCode.GDEndTextObjects3= [];
gdjs.WarCode.GDEndTextObjects4= [];
gdjs.WarCode.GDEndTextObjects5= [];
gdjs.WarCode.GDBarObjects1= [];
gdjs.WarCode.GDBarObjects2= [];
gdjs.WarCode.GDBarObjects3= [];
gdjs.WarCode.GDBarObjects4= [];
gdjs.WarCode.GDBarObjects5= [];
gdjs.WarCode.GDTutorialObjects1= [];
gdjs.WarCode.GDTutorialObjects2= [];
gdjs.WarCode.GDTutorialObjects3= [];
gdjs.WarCode.GDTutorialObjects4= [];
gdjs.WarCode.GDTutorialObjects5= [];
gdjs.WarCode.GDUnlockObjects1= [];
gdjs.WarCode.GDUnlockObjects2= [];
gdjs.WarCode.GDUnlockObjects3= [];
gdjs.WarCode.GDUnlockObjects4= [];
gdjs.WarCode.GDUnlockObjects5= [];
gdjs.WarCode.GDDoubleShotAutoObjects1= [];
gdjs.WarCode.GDDoubleShotAutoObjects2= [];
gdjs.WarCode.GDDoubleShotAutoObjects3= [];
gdjs.WarCode.GDDoubleShotAutoObjects4= [];
gdjs.WarCode.GDDoubleShotAutoObjects5= [];
gdjs.WarCode.GDTripleShotAutoObjects1= [];
gdjs.WarCode.GDTripleShotAutoObjects2= [];
gdjs.WarCode.GDTripleShotAutoObjects3= [];
gdjs.WarCode.GDTripleShotAutoObjects4= [];
gdjs.WarCode.GDTripleShotAutoObjects5= [];
gdjs.WarCode.GDUnlock_95Ui100Objects1= [];
gdjs.WarCode.GDUnlock_95Ui100Objects2= [];
gdjs.WarCode.GDUnlock_95Ui100Objects3= [];
gdjs.WarCode.GDUnlock_95Ui100Objects4= [];
gdjs.WarCode.GDUnlock_95Ui100Objects5= [];
gdjs.WarCode.GDUnlock_95Ui500Objects1= [];
gdjs.WarCode.GDUnlock_95Ui500Objects2= [];
gdjs.WarCode.GDUnlock_95Ui500Objects3= [];
gdjs.WarCode.GDUnlock_95Ui500Objects4= [];
gdjs.WarCode.GDUnlock_95Ui500Objects5= [];
gdjs.WarCode.GDUnlock_95Ui1000Objects1= [];
gdjs.WarCode.GDUnlock_95Ui1000Objects2= [];
gdjs.WarCode.GDUnlock_95Ui1000Objects3= [];
gdjs.WarCode.GDUnlock_95Ui1000Objects4= [];
gdjs.WarCode.GDUnlock_95Ui1000Objects5= [];
gdjs.WarCode.GDUnlock_95Ui5000Objects1= [];
gdjs.WarCode.GDUnlock_95Ui5000Objects2= [];
gdjs.WarCode.GDUnlock_95Ui5000Objects3= [];
gdjs.WarCode.GDUnlock_95Ui5000Objects4= [];
gdjs.WarCode.GDUnlock_95Ui5000Objects5= [];

gdjs.WarCode.conditionTrue_0 = {val:false};
gdjs.WarCode.condition0IsTrue_0 = {val:false};
gdjs.WarCode.condition1IsTrue_0 = {val:false};
gdjs.WarCode.condition2IsTrue_0 = {val:false};
gdjs.WarCode.condition3IsTrue_0 = {val:false};
gdjs.WarCode.condition4IsTrue_0 = {val:false};
gdjs.WarCode.condition5IsTrue_0 = {val:false};
gdjs.WarCode.condition6IsTrue_0 = {val:false};
gdjs.WarCode.condition7IsTrue_0 = {val:false};
gdjs.WarCode.conditionTrue_1 = {val:false};
gdjs.WarCode.condition0IsTrue_1 = {val:false};
gdjs.WarCode.condition1IsTrue_1 = {val:false};
gdjs.WarCode.condition2IsTrue_1 = {val:false};
gdjs.WarCode.condition3IsTrue_1 = {val:false};
gdjs.WarCode.condition4IsTrue_1 = {val:false};
gdjs.WarCode.condition5IsTrue_1 = {val:false};
gdjs.WarCode.condition6IsTrue_1 = {val:false};
gdjs.WarCode.condition7IsTrue_1 = {val:false};


gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBackgroundObjects1Objects = Hashtable.newFrom({"Background": gdjs.WarCode.GDBackgroundObjects1});
gdjs.WarCode.asyncCallback10966108 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Game_Start"), true);
}}
gdjs.WarCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.WarCode.asyncCallback10966108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.WarCode.eventsList1 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenTutorial_active")) == 2;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition1IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10963972);
}
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Game_Start"), false);
}{for(var i = 0, len = gdjs.WarCode.GDPlaneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDPlaneObjects2[i].getBehavior("Tween").addObjectPositionYTween("Plane_GoesUP", 849, "easeInQuad", 500, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Game_Start"), false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.WarCode.GDPlaneObjects2.length;i<l;++i) {
    if ( gdjs.WarCode.GDPlaneObjects2[i].getBehavior("Tween").hasFinished("Plane_GoesUP") ) {
        gdjs.WarCode.condition1IsTrue_0.val = true;
        gdjs.WarCode.GDPlaneObjects2[k] = gdjs.WarCode.GDPlaneObjects2[i];
        ++k;
    }
}
gdjs.WarCode.GDPlaneObjects2.length = k;}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon1"), gdjs.WarCode.GDCannon1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects2);
{for(var i = 0, len = gdjs.WarCode.GDCannon1Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDCannon1Objects2[i].getBehavior("Tween").addObjectPositionYTween("Cannon1Ready", 740, "easeInQuad", 100, false);
}
}{for(var i = 0, len = gdjs.WarCode.GDCannon2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDCannon2Objects2[i].getBehavior("Tween").addObjectPositionYTween("Cannon2Ready", 794, "easeInQuad", 100, false);
}
}{for(var i = 0, len = gdjs.WarCode.GDCannon3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDCannon3Objects2[i].getBehavior("Tween").addObjectPositionYTween("Cannon3Ready", 794, "easeInQuad", 100, false);
}
}
{ //Subevents
gdjs.WarCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("GameStatus"), gdjs.WarCode.GDGameStatusObjects1);
{for(var i = 0, len = gdjs.WarCode.GDGameStatusObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDGameStatusObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Game_Start")));
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects2Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.WarCode.GDBulletObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects = Hashtable.newFrom({"Crosshair_Clone": gdjs.WarCode.GDCrosshair_95CloneObjects2});
gdjs.WarCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
gdjs.WarCode.condition3IsTrue_0.val = false;
gdjs.WarCode.condition4IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects2Objects, runtimeScene, true, true);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Bullet_Exists")) == 0;
}if ( gdjs.WarCode.condition2IsTrue_0.val ) {
{
gdjs.WarCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Cannon_Active")) == 0;
}if ( gdjs.WarCode.condition3IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition4IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10971476);
}
}}
}
}
}
if (gdjs.WarCode.condition4IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon1"), gdjs.WarCode.GDCannon1Objects2);
gdjs.WarCode.GDBulletObjects2.length = 0;

gdjs.WarCode.GDCrosshair_95CloneObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects, (( gdjs.WarCode.GDCannon1Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects2[0].getPointX("BulletPoint")), (( gdjs.WarCode.GDCannon1Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects2[0].getPointY("BulletPoint")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "155790__deleted-user-1941307__shipboard-railgun.mp3", false, 100, 1);
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(1);
}{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].returnVariable(gdjs.WarCode.GDBulletObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.WarCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshair_95CloneObjects2.length !== 0 ? gdjs.WarCode.GDCrosshair_95CloneObjects2[0] : null), 1000, 0);
}
}}

}


{


{
}

}


};gdjs.WarCode.eventsList3 = function(runtimeScene) {

{


gdjs.WarCode.eventsList2(runtimeScene);
}


};gdjs.WarCode.eventsList4 = function(runtimeScene) {

};gdjs.WarCode.eventsList5 = function(runtimeScene) {

};gdjs.WarCode.eventsList6 = function(runtimeScene) {

{


gdjs.WarCode.repeatCount3 = 1;
for(gdjs.WarCode.repeatIndex3 = 0;gdjs.WarCode.repeatIndex3 < gdjs.WarCode.repeatCount3;++gdjs.WarCode.repeatIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WarCode.GDPlaneObjects3.length;i<l;++i) {
    if ( gdjs.WarCode.GDPlaneObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Timer_Enemy_Spawn") > 1 ) {
        gdjs.WarCode.condition0IsTrue_0.val = true;
        gdjs.WarCode.GDPlaneObjects3[k] = gdjs.WarCode.GDPlaneObjects3[i];
        ++k;
    }
}
gdjs.WarCode.GDPlaneObjects3.length = k;}if (gdjs.WarCode.condition0IsTrue_0.val)
{
{for(var i = 0, len = gdjs.WarCode.GDPlaneObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDPlaneObjects3[i].resetTimer("Timer_Enemy_Spawn");
}
}{runtimeScene.getVariables().get("Enemy_Spawn_Time").sub(1);
}}
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects2});
gdjs.WarCode.eventsList7 = function(runtimeScene) {

{


gdjs.WarCode.eventsList4(runtimeScene);
}


{


{
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDPlaneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDPlaneObjects2[i].resetTimer("Timer_Enemy_Spawn");
}
}{runtimeScene.getVariables().get("Enemy_Spawn_Time").setNumber(2);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Game_Start"), true);
}if (gdjs.WarCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Enemy_Spawn_Time")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
gdjs.WarCode.GDEnemyObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDPlaneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDPlaneObjects2[i].resetTimer("Timer_Enemy_Spawn");
}
}{runtimeScene.getVariables().get("Enemy_Spawn_Time").setNumber(2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "454595__breviceps__cartoon-flying-ufo.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects, gdjs.randomInRange(-(141), 562), gdjs.randomInRange(-(254), 120), "");
}{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].setSize(112, 57);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 20;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), 50, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 20;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 100;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), 250, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 500;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), 300, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 1000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), 400, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), 500, 0);
}
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("TimerEnemy"), gdjs.WarCode.GDTimerEnemyObjects1);
{for(var i = 0, len = gdjs.WarCode.GDTimerEnemyObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDTimerEnemyObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Enemy_Spawn_Time")));
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.WarCode.GDBulletObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects = Hashtable.newFrom({"AddScore": gdjs.WarCode.GDAddScoreObjects2});
gdjs.WarCode.eventsList8 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10985428);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getVariables().get("tween_bar").add(4.04);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 10, 10, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(140);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects = Hashtable.newFrom({"AddScore": gdjs.WarCode.GDAddScoreObjects2});
gdjs.WarCode.eventsList9 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10990164);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getVariables().get("tween_bar").add(4.04);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 10, 10, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(140);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects = Hashtable.newFrom({"AddScore": gdjs.WarCode.GDAddScoreObjects2});
gdjs.WarCode.eventsList10 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10994276);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getVariables().get("tween_bar").add(4.04);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 10, 10, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(140);
}}

}


{


{
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects1Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects1});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects1});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects1Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects1});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects1Objects = Hashtable.newFrom({"AddScore": gdjs.WarCode.GDAddScoreObjects1});
gdjs.WarCode.eventsList11 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10998724);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getVariables().get("tween_bar").add(4.04);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 10, 10, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(140);
}}

}


};gdjs.WarCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.WarCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects, false, runtimeScene, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.WarCode.GDBulletObjects2.length;i<l;++i) {
    if ( gdjs.WarCode.GDBulletObjects2[i].getVariableNumber(gdjs.WarCode.GDBulletObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.WarCode.condition1IsTrue_0.val = true;
        gdjs.WarCode.GDBulletObjects2[k] = gdjs.WarCode.GDBulletObjects2[i];
        ++k;
    }
}
gdjs.WarCode.GDBulletObjects2.length = k;}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
/* Reuse gdjs.WarCode.GDEnemyObjects2 */
gdjs.WarCode.GDAddScoreObjects2.length = 0;

gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{runtimeScene.getVariables().get("Reffil_Anim_exist").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDAddScoreObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScoreObjects2[i].getBehavior("Tween").addObjectPositionYTween("AddScore_Move_up", (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("Score")), "easeInQuad", 1000, true);
}
}
{ //Subevents
gdjs.WarCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet2Objects2 */
/* Reuse gdjs.WarCode.GDEnemyObjects2 */
gdjs.WarCode.GDAddScoreObjects2.length = 0;

gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDAddScoreObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScoreObjects2[i].getBehavior("Tween").addObjectPositionYTween("AddScore_Move_up", (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("Score")), "easeInQuad", 1000, true);
}
}
{ //Subevents
gdjs.WarCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet3Objects2 */
/* Reuse gdjs.WarCode.GDEnemyObjects2 */
gdjs.WarCode.GDAddScoreObjects2.length = 0;

gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{gdjs.deviceVibration.startVibration(140);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects2Objects, (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDAddScoreObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScoreObjects2[i].getBehavior("Tween").addObjectPositionYTween("AddScore_Move_up", (( gdjs.WarCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects2[0].getPointY("Score")), "easeInQuad", 1000, true);
}
}{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 10, 10, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.WarCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects1);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects1Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet4Objects1 */
/* Reuse gdjs.WarCode.GDEnemyObjects1 */
gdjs.WarCode.GDAddScoreObjects1.length = 0;

gdjs.WarCode.GDCollide_95ExplosionObjects1.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet4Objects1.length ;i < len;++i) {
    gdjs.WarCode.GDBullet4Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects1Objects, (( gdjs.WarCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects1[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScoreObjects1Objects, (( gdjs.WarCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.WarCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDAddScoreObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDAddScoreObjects1[i].getBehavior("Tween").addObjectPositionYTween("AddScore_Move_up", (( gdjs.WarCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyObjects1[0].getPointY("Score")), "easeInQuad", 1000, true);
}
}
{ //Subevents
gdjs.WarCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.WarCode.GDBulletObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList13 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11003692);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList14 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11008140);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList15 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11012676);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList16 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11017036);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.WarCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects, false, runtimeScene, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.WarCode.GDBulletObjects2.length;i<l;++i) {
    if ( gdjs.WarCode.GDBulletObjects2[i].getVariableNumber(gdjs.WarCode.GDBulletObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.WarCode.condition1IsTrue_0.val = true;
        gdjs.WarCode.GDBulletObjects2[k] = gdjs.WarCode.GDBulletObjects2[i];
        ++k;
    }
}
gdjs.WarCode.GDBulletObjects2.length = k;}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
/* Reuse gdjs.WarCode.GDEnemyMasterObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet2Objects2 */
/* Reuse gdjs.WarCode.GDEnemyMasterObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet3Objects2 */
/* Reuse gdjs.WarCode.GDEnemyMasterObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet4Objects2 */
/* Reuse gdjs.WarCode.GDEnemyMasterObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemyMasterObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemyMasterObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet4Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet4Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{


{
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.WarCode.GDBulletObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList18 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11022876);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(2);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList19 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11027964);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(2);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList20 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11032500);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(2);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects = Hashtable.newFrom({"AddScore2": gdjs.WarCode.GDAddScore2Objects2});
gdjs.WarCode.eventsList21 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11036924);
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).add(2);
}{runtimeScene.getVariables().get("tween_bar").add(20.2);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects3[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("tween_bar")), "easeInQuad", 400, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Vibrate")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.5, 0, 0, 0.07, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.deviceVibration.startVibration(200);
}}

}


};gdjs.WarCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.WarCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects, false, runtimeScene, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.WarCode.GDBulletObjects2.length;i<l;++i) {
    if ( gdjs.WarCode.GDBulletObjects2[i].getVariableNumber(gdjs.WarCode.GDBulletObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.WarCode.condition1IsTrue_0.val = true;
        gdjs.WarCode.GDBulletObjects2[k] = gdjs.WarCode.GDBulletObjects2[i];
        ++k;
    }
}
gdjs.WarCode.GDBulletObjects2.length = k;}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
/* Reuse gdjs.WarCode.GDEnemySmallObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointX("")), (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet2Objects2 */
/* Reuse gdjs.WarCode.GDEnemySmallObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet3Objects2 */
/* Reuse gdjs.WarCode.GDEnemySmallObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AddScore2"), gdjs.WarCode.GDAddScore2Objects2);
/* Reuse gdjs.WarCode.GDBullet4Objects2 */
/* Reuse gdjs.WarCode.GDEnemySmallObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDAddScore2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDAddScore2Objects2[i].getBehavior("Tween").addObjectPositionYTween("AddMasterScore_Move_up", (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("Score")), "easeInQuad", 200, true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDAddScore2Objects2Objects, 0, (( gdjs.WarCode.GDEnemySmallObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDEnemySmallObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{for(var i = 0, len = gdjs.WarCode.GDBullet4Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet4Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WarCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{


{
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBtn_9595backObjects1Objects = Hashtable.newFrom({"Btn_back": gdjs.WarCode.GDBtn_95backObjects1});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.WarCode.GDBulletObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects = Hashtable.newFrom({"Crosshair_Clone": gdjs.WarCode.GDCrosshair_95CloneObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects3Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects = Hashtable.newFrom({"Crosshair": gdjs.WarCode.GDCrosshairObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.eventsList23 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.WarCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBulletObjects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBulletObjects2 */
/* Reuse gdjs.WarCode.GDCrosshair_95CloneObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{runtimeScene.getVariables().get("Reffil_Anim_exist").setNumber(0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDCrosshair_95CloneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshair_95CloneObjects2[0].getPointX("")), (( gdjs.WarCode.GDCrosshair_95CloneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshair_95CloneObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}}

}


{

gdjs.WarCode.GDBullet2Objects2.length = 0;

gdjs.WarCode.GDBullet3Objects2.length = 0;

gdjs.WarCode.GDBullet4Objects2.length = 0;

gdjs.WarCode.GDCrosshairObjects2.length = 0;


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.GDBullet2Objects2_1final.length = 0;gdjs.WarCode.GDBullet3Objects2_1final.length = 0;gdjs.WarCode.GDBullet4Objects2_1final.length = 0;gdjs.WarCode.GDCrosshairObjects2_1final.length = 0;gdjs.WarCode.condition0IsTrue_1.val = false;
gdjs.WarCode.condition1IsTrue_1.val = false;
gdjs.WarCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects3);
gdjs.WarCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition0IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDBullet3Objects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDBullet3Objects2_1final.indexOf(gdjs.WarCode.GDBullet3Objects3[j]) === -1 )
            gdjs.WarCode.GDBullet3Objects2_1final.push(gdjs.WarCode.GDBullet3Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDCrosshairObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDCrosshairObjects2_1final.indexOf(gdjs.WarCode.GDCrosshairObjects3[j]) === -1 )
            gdjs.WarCode.GDCrosshairObjects2_1final.push(gdjs.WarCode.GDCrosshairObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects3);
gdjs.WarCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition1IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDBullet2Objects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDBullet2Objects2_1final.indexOf(gdjs.WarCode.GDBullet2Objects3[j]) === -1 )
            gdjs.WarCode.GDBullet2Objects2_1final.push(gdjs.WarCode.GDBullet2Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDCrosshairObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDCrosshairObjects2_1final.indexOf(gdjs.WarCode.GDCrosshairObjects3[j]) === -1 )
            gdjs.WarCode.GDCrosshairObjects2_1final.push(gdjs.WarCode.GDCrosshairObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects3);
gdjs.WarCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition2IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDBullet4Objects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDBullet4Objects2_1final.indexOf(gdjs.WarCode.GDBullet4Objects3[j]) === -1 )
            gdjs.WarCode.GDBullet4Objects2_1final.push(gdjs.WarCode.GDBullet4Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDCrosshairObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDCrosshairObjects2_1final.indexOf(gdjs.WarCode.GDCrosshairObjects3[j]) === -1 )
            gdjs.WarCode.GDCrosshairObjects2_1final.push(gdjs.WarCode.GDCrosshairObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.WarCode.GDBullet2Objects2_1final, gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(gdjs.WarCode.GDBullet3Objects2_1final, gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(gdjs.WarCode.GDBullet4Objects2_1final, gdjs.WarCode.GDBullet4Objects2);
gdjs.copyArray(gdjs.WarCode.GDCrosshairObjects2_1final, gdjs.WarCode.GDCrosshairObjects2);
}
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet2Objects2 */
/* Reuse gdjs.WarCode.GDCrosshairObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointX("")), (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet3Objects2 */
/* Reuse gdjs.WarCode.GDCrosshairObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointX("")), (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshairObjects2Objects, false, runtimeScene, false);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDBullet4Objects2 */
/* Reuse gdjs.WarCode.GDCrosshairObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Crosshair_Clone"), gdjs.WarCode.GDCrosshair_95CloneObjects2);
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.WarCode.GDBullet4Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet4Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "587183__derplayer__explosion-03.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointX("")), (( gdjs.WarCode.GDCrosshairObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDCrosshairObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.WarCode.GDCrosshair_95CloneObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshair_95CloneObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
}

}


};gdjs.WarCode.eventsList24 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 100;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", 404, "easeInQuad", 50, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 100;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition1IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11070028);
}
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("Start_Point").setNumber(0);
}{runtimeScene.getVariables().get("End_Point").setNumber(100);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 100;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 4.04, "easeInQuad", 50, false);
}
}}

}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 100;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 500;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{runtimeScene.getVariables().get("Start_Point").setNumber(100);
}{runtimeScene.getVariables().get("End_Point").setNumber(500);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", 1.01 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) - 100), "easeInQuad", 50, false);
}
}}

}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 1000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{runtimeScene.getVariables().get("Start_Point").setNumber(500);
}{runtimeScene.getVariables().get("End_Point").setNumber(1000);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", 0.808 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) - 500), "easeInQuad", 50, false);
}
}}

}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 5000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{runtimeScene.getVariables().get("Start_Point").setNumber(1000);
}{runtimeScene.getVariables().get("End_Point").setNumber(5000);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", 0.101 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) - 1000), "easeInQuad", 50, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 5000;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 10000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ProgressBar"), gdjs.WarCode.GDProgressBarObjects2);
{runtimeScene.getVariables().get("Start_Point").setNumber(1000);
}{runtimeScene.getVariables().get("End_Point").setNumber(5000);
}{for(var i = 0, len = gdjs.WarCode.GDProgressBarObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDProgressBarObjects2[i].getBehavior("Tween").addObjectWidthTween("ProgressBar", 0.0808 * (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) - 5000), "easeInQuad", 50, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 10000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Congratz", false);
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui100Objects3Objects = Hashtable.newFrom({"Unlock_Ui100": gdjs.WarCode.GDUnlock_95Ui100Objects3});
gdjs.WarCode.eventsList25 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui100"), gdjs.WarCode.GDUnlock_95Ui100Objects3);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui100Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui100Objects3[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi100_Move", 1, "easeInQuad", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui100"), gdjs.WarCode.GDUnlock_95Ui100Objects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui100Objects3Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("TweenUnlock100_Active").setNumber(1);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenUnlock100_Active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui100"), gdjs.WarCode.GDUnlock_95Ui100Objects2);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui100Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui100Objects2[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi100_Move", 909, "easeInQuad", 50, false);
}
}}

}


};gdjs.WarCode.eventsList26 = function(runtimeScene) {

};gdjs.WarCode.eventsList27 = function(runtimeScene) {

{


gdjs.WarCode.repeatCount4 = 1;
for(gdjs.WarCode.repeatIndex4 = 0;gdjs.WarCode.repeatIndex4 < gdjs.WarCode.repeatCount4;++gdjs.WarCode.repeatIndex4) {

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SpawnDouble") > 1;
}if (gdjs.WarCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("SpawnDouble").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnDouble");
}}
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects3});
gdjs.WarCode.eventsList28 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("SpawnDouble").setNumber(5);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnDouble");
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DoubleShotActive_Auto")) == 1;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 100;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList27(runtimeScene);} //End of subevents
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SpawnDouble")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DoubleShotAuto"), gdjs.WarCode.GDDoubleShotAutoObjects3);
{for(var i = 0, len = gdjs.WarCode.GDDoubleShotAutoObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDDoubleShotAutoObjects3[i].setAnimation(1);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SpawnDouble")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects3);
gdjs.copyArray(runtimeScene.getObjects("DoubleShotAuto"), gdjs.WarCode.GDDoubleShotAutoObjects3);
gdjs.WarCode.GDBullet2Objects3.length = 0;

gdjs.WarCode.GDBullet3Objects3.length = 0;

{runtimeScene.getVariables().get("SpawnDouble").setNumber(5);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects, (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects, (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "155790__deleted-user-1941307__shipboard-railgun.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDDoubleShotAutoObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDDoubleShotAutoObjects3[i].setAnimation(0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnDouble"), gdjs.WarCode.GDTest_95SpawnDoubleObjects2);
{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnDoubleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnDoubleObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("SpawnDouble")));
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshairObjects2.length !== 0 ? gdjs.WarCode.GDCrosshairObjects2[0] : null), 600, 0);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshairObjects2.length !== 0 ? gdjs.WarCode.GDCrosshairObjects2[0] : null), 600, 0);
}
}}

}


};gdjs.WarCode.eventsList29 = function(runtimeScene) {

};gdjs.WarCode.eventsList30 = function(runtimeScene) {

{


gdjs.WarCode.repeatCount4 = 1;
for(gdjs.WarCode.repeatIndex4 = 0;gdjs.WarCode.repeatIndex4 < gdjs.WarCode.repeatCount4;++gdjs.WarCode.repeatIndex4) {

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimerMaster_Enemy_Spawn") > 1;
}if (gdjs.WarCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("Enemy_Master_Spawn_Time").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerMaster_Enemy_Spawn");
}}
}

}


};gdjs.WarCode.eventsList31 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerMaster_Enemy_Spawn");
}{runtimeScene.getVariables().get("Enemy_Master_Spawn_Time").setNumber(2);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if (gdjs.WarCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects3Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects3});
gdjs.WarCode.eventsList32 = function(runtimeScene) {

{


gdjs.WarCode.eventsList31(runtimeScene);
}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Enemy_Master_Spawn_Time")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.WarCode.GDEnemyMasterObjects3.length = 0;

{runtimeScene.getVariables().get("Enemy_Master_Spawn_Time").setNumber(2);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer_Enemy_Spawn");
}{gdjs.evtTools.sound.playSound(runtimeScene, "454595__breviceps__cartoon-flying-ufo.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects3Objects, gdjs.randomInRange(-(141), 562), gdjs.randomInRange(-(254), 120), "");
}{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].setSize(265, 134);
}
}}

}


{


{
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 20;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 30, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 20;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 100;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 60, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 500;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 90, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 1000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 120, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemyMasterObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemyMasterObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 150, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("TimerEnemy2"), gdjs.WarCode.GDTimerEnemy2Objects2);
{for(var i = 0, len = gdjs.WarCode.GDTimerEnemy2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDTimerEnemy2Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Enemy_Master_Spawn_Time")));
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui500Objects3Objects = Hashtable.newFrom({"Unlock_Ui500": gdjs.WarCode.GDUnlock_95Ui500Objects3});
gdjs.WarCode.eventsList33 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui500"), gdjs.WarCode.GDUnlock_95Ui500Objects3);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui500Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui500Objects3[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi500_Move", 1, "easeInQuad", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui500"), gdjs.WarCode.GDUnlock_95Ui500Objects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui500Objects3Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("TweenUnlock500_Active").setNumber(1);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenUnlock500_Active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui500"), gdjs.WarCode.GDUnlock_95Ui500Objects2);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui500Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui500Objects2[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi500_Move", 909, "easeInQuad", 50, false);
}
}}

}


};gdjs.WarCode.eventsList34 = function(runtimeScene) {

};gdjs.WarCode.eventsList35 = function(runtimeScene) {

{


gdjs.WarCode.repeatCount4 = 1;
for(gdjs.WarCode.repeatIndex4 = 0;gdjs.WarCode.repeatIndex4 < gdjs.WarCode.repeatCount4;++gdjs.WarCode.repeatIndex4) {

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimerSmall_Enemy_Spawn") > 1;
}if (gdjs.WarCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("Enemy_Small_Spawn_Time").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerSmall_Enemy_Spawn");
}}
}

}


};gdjs.WarCode.eventsList36 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerSmall_Enemy_Spawn");
}{runtimeScene.getVariables().get("Enemy_Small_Spawn_Time").setNumber(2);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if (gdjs.WarCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects3Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects3});
gdjs.WarCode.eventsList37 = function(runtimeScene) {

{


gdjs.WarCode.eventsList36(runtimeScene);
}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Enemy_Small_Spawn_Time")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.WarCode.GDEnemySmallObjects3.length = 0;

{runtimeScene.getVariables().get("Enemy_Small_Spawn_Time").setNumber(2);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerSmall_Enemy_Spawn");
}{gdjs.evtTools.sound.playSound(runtimeScene, "454595__breviceps__cartoon-flying-ufo.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects3Objects, gdjs.randomInRange(-(141), 562), gdjs.randomInRange(-(254), 120), "");
}{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].setSize(51, 26);
}
}}

}


{


{
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 20;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 50, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 20;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 100;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 100, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 500;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 120, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 1000;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 200, 0);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
{for(var i = 0, len = gdjs.WarCode.GDEnemySmallObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDEnemySmallObjects3[i].addForceTowardPosition((( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects3.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects3[0].getPointY("")), 250, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("TimerEnemy3"), gdjs.WarCode.GDTimerEnemy3Objects2);
{for(var i = 0, len = gdjs.WarCode.GDTimerEnemy3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDTimerEnemy3Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Enemy_Small_Spawn_Time")));
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects3Objects = Hashtable.newFrom({"Crosshair_Clone": gdjs.WarCode.GDCrosshair_95CloneObjects3});
gdjs.WarCode.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
gdjs.WarCode.condition3IsTrue_0.val = false;
gdjs.WarCode.condition4IsTrue_0.val = false;
gdjs.WarCode.condition5IsTrue_0.val = false;
gdjs.WarCode.condition6IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects, runtimeScene, true, true);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Bullet_Exists")) == 0;
}if ( gdjs.WarCode.condition2IsTrue_0.val ) {
{
gdjs.WarCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Cannon_Active")) == 0;
}if ( gdjs.WarCode.condition3IsTrue_0.val ) {
{
gdjs.WarCode.condition4IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if ( gdjs.WarCode.condition4IsTrue_0.val ) {
{
gdjs.WarCode.condition5IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DoubleShotActive_Manual")) == 1;
}if ( gdjs.WarCode.condition5IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition6IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11114156);
}
}}
}
}
}
}
}
if (gdjs.WarCode.condition6IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects3);
gdjs.WarCode.GDBullet2Objects3.length = 0;

gdjs.WarCode.GDBullet3Objects3.length = 0;

gdjs.WarCode.GDCrosshair_95CloneObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects, (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects, (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects3Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "155790__deleted-user-1941307__shipboard-railgun.mp3", false, 100, 1);
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(1);
}}

}


{


{
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui1000Objects3Objects = Hashtable.newFrom({"Unlock_Ui1000": gdjs.WarCode.GDUnlock_95Ui1000Objects3});
gdjs.WarCode.eventsList39 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui1000"), gdjs.WarCode.GDUnlock_95Ui1000Objects3);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui1000Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui1000Objects3[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi1000_Move", 1, "easeInQuad", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui1000"), gdjs.WarCode.GDUnlock_95Ui1000Objects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui1000Objects3Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("TweenUnlock1000_Active").setNumber(1);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenUnlock1000_Active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui1000"), gdjs.WarCode.GDUnlock_95Ui1000Objects2);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui1000Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui1000Objects2[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi1000_Move", 909, "easeInQuad", 50, false);
}
}}

}


};gdjs.WarCode.eventsList40 = function(runtimeScene) {

};gdjs.WarCode.eventsList41 = function(runtimeScene) {

{


gdjs.WarCode.repeatCount4 = 1;
for(gdjs.WarCode.repeatIndex4 = 0;gdjs.WarCode.repeatIndex4 < gdjs.WarCode.repeatCount4;++gdjs.WarCode.repeatIndex4) {

gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SpawnTriple") > 1;
}if (gdjs.WarCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("SpawnTriple").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnTriple");
}}
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects3Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects3});
gdjs.WarCode.eventsList42 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("SpawnTriple").setNumber(10);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnTriple");
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TripleShotActive_Auto")) == 1;
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 5;
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList41(runtimeScene);} //End of subevents
}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SpawnTriple")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TripleShotAuto"), gdjs.WarCode.GDTripleShotAutoObjects3);
{for(var i = 0, len = gdjs.WarCode.GDTripleShotAutoObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDTripleShotAutoObjects3[i].setAnimation(1);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SpawnTriple")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon1"), gdjs.WarCode.GDCannon1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects3);
gdjs.copyArray(runtimeScene.getObjects("TripleShotAuto"), gdjs.WarCode.GDTripleShotAutoObjects3);
gdjs.WarCode.GDBullet2Objects3.length = 0;

gdjs.WarCode.GDBullet3Objects3.length = 0;

gdjs.WarCode.GDBullet4Objects3.length = 0;

{runtimeScene.getVariables().get("SpawnTriple").setNumber(10);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects3Objects, (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon2Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects3Objects, (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon3Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects3[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects3Objects, (( gdjs.WarCode.GDCannon1Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects3[0].getPointX("BulletPoint")), (( gdjs.WarCode.GDCannon1Objects3.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects3[0].getPointY("BulletPoint")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "155790__deleted-user-1941307__shipboard-railgun.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.WarCode.GDTripleShotAutoObjects3.length ;i < len;++i) {
    gdjs.WarCode.GDTripleShotAutoObjects3[i].setAnimation(0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.WarCode.GDBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.WarCode.GDBullet3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet4"), gdjs.WarCode.GDBullet4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnTriple"), gdjs.WarCode.GDTest_95SpawnTripleObjects2);
{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnTripleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnTripleObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("SpawnTriple")));
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshairObjects2.length !== 0 ? gdjs.WarCode.GDCrosshairObjects2[0] : null), 800, 0);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshairObjects2.length !== 0 ? gdjs.WarCode.GDCrosshairObjects2[0] : null), 800, 0);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet4Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet4Objects2[i].addForceTowardObject((gdjs.WarCode.GDCrosshairObjects2.length !== 0 ? gdjs.WarCode.GDCrosshairObjects2[0] : null), 800, 0);
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui5000Objects3Objects = Hashtable.newFrom({"Unlock_Ui5000": gdjs.WarCode.GDUnlock_95Ui5000Objects3});
gdjs.WarCode.eventsList43 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 5000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui5000"), gdjs.WarCode.GDUnlock_95Ui5000Objects3);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui5000Objects3.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui5000Objects3[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi5000_Move", 1, "easeInQuad", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui5000"), gdjs.WarCode.GDUnlock_95Ui5000Objects3);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDUnlock_9595Ui5000Objects3Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 5000;
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("TweenUnlock5000_Active").setNumber(1);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenUnlock5000_Active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Unlock_Ui5000"), gdjs.WarCode.GDUnlock_95Ui5000Objects2);
{for(var i = 0, len = gdjs.WarCode.GDUnlock_95Ui5000Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDUnlock_95Ui5000Objects2[i].getBehavior("Tween").addObjectPositionYTween("UnlockUi5000_Move", 909, "easeInQuad", 50, false);
}
}}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects2Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects = Hashtable.newFrom({"Bullet3": gdjs.WarCode.GDBullet3Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects = Hashtable.newFrom({"Bullet2": gdjs.WarCode.GDBullet2Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects = Hashtable.newFrom({"Bullet4": gdjs.WarCode.GDBullet4Objects2});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects = Hashtable.newFrom({"Crosshair_Clone": gdjs.WarCode.GDCrosshair_95CloneObjects2});
gdjs.WarCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects2);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
gdjs.WarCode.condition3IsTrue_0.val = false;
gdjs.WarCode.condition4IsTrue_0.val = false;
gdjs.WarCode.condition5IsTrue_0.val = false;
gdjs.WarCode.condition6IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects2Objects, runtimeScene, true, true);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Bullet_Exists")) == 0;
}if ( gdjs.WarCode.condition2IsTrue_0.val ) {
{
gdjs.WarCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Cannon_Active")) == 0;
}if ( gdjs.WarCode.condition3IsTrue_0.val ) {
{
gdjs.WarCode.condition4IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 5000;
}if ( gdjs.WarCode.condition4IsTrue_0.val ) {
{
gdjs.WarCode.condition5IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TripleShotActive_Manual")) == 1;
}if ( gdjs.WarCode.condition5IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition6IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11132084);
}
}}
}
}
}
}
}
if (gdjs.WarCode.condition6IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon1"), gdjs.WarCode.GDCannon1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects2);
gdjs.WarCode.GDBullet2Objects2.length = 0;

gdjs.WarCode.GDBullet3Objects2.length = 0;

gdjs.WarCode.GDBullet4Objects2.length = 0;

gdjs.WarCode.GDCrosshair_95CloneObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet3Objects2Objects, (( gdjs.WarCode.GDCannon3Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects2[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon3Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon3Objects2[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet2Objects2Objects, (( gdjs.WarCode.GDCannon2Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects2[0].getPointX("Bullet_Spawn")), (( gdjs.WarCode.GDCannon2Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon2Objects2[0].getPointY("Bullet_Spawn")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBullet4Objects2Objects, (( gdjs.WarCode.GDCannon1Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects2[0].getPointX("BulletPoint")), (( gdjs.WarCode.GDCannon1Objects2.length === 0 ) ? 0 :gdjs.WarCode.GDCannon1Objects2[0].getPointY("BulletPoint")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCrosshair_9595CloneObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "155790__deleted-user-1941307__shipboard-railgun.mp3", false, 100, 1);
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(1);
}{for(var i = 0, len = gdjs.WarCode.GDBullet2Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet2Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.WarCode.GDBullet3Objects2.length ;i < len;++i) {
    gdjs.WarCode.GDBullet3Objects2[i].setAnimation(1);
}
}}

}


{


{
}

}


};gdjs.WarCode.eventsList45 = function(runtimeScene) {

{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 100;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DoubleShotAuto"), gdjs.WarCode.GDDoubleShotAutoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnDouble"), gdjs.WarCode.GDTest_95SpawnDoubleObjects2);
{runtimeScene.getVariables().get("DoubleShotActive_Auto").setNumber(1);
}{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnDoubleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnDoubleObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.WarCode.GDDoubleShotAutoObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDDoubleShotAutoObjects2[i].hide(false);
}
}}

}


{


gdjs.WarCode.eventsList25(runtimeScene);
}


{


gdjs.WarCode.eventsList28(runtimeScene);
}


{


gdjs.WarCode.eventsList32(runtimeScene);
}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 500;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnTriple"), gdjs.WarCode.GDTest_95SpawnTripleObjects2);
gdjs.copyArray(runtimeScene.getObjects("TripleShotAuto"), gdjs.WarCode.GDTripleShotAutoObjects2);
{runtimeScene.getVariables().get("DoubleShotActive_Manual").setNumber(1);
}{for(var i = 0, len = gdjs.WarCode.GDTripleShotAutoObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTripleShotAutoObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnTripleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnTripleObjects2[i].hide(false);
}
}}

}


{


gdjs.WarCode.eventsList33(runtimeScene);
}


{


gdjs.WarCode.eventsList37(runtimeScene);
}


{


gdjs.WarCode.eventsList38(runtimeScene);
}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 1000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("DoubleShotActive_Auto").setNumber(0);
}{runtimeScene.getVariables().get("TripleShotActive_Auto").setNumber(1);
}}

}


{


gdjs.WarCode.eventsList39(runtimeScene);
}


{


gdjs.WarCode.eventsList42(runtimeScene);
}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 5000;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("DoubleShotActive_Manual").setNumber(0);
}{runtimeScene.getVariables().get("TripleShotActive_Manual").setNumber(1);
}}

}


{


gdjs.WarCode.eventsList43(runtimeScene);
}


{


gdjs.WarCode.eventsList44(runtimeScene);
}


};gdjs.WarCode.eventsList46 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DoubleShotAuto"), gdjs.WarCode.GDDoubleShotAutoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnDouble"), gdjs.WarCode.GDTest_95SpawnDoubleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Test_SpawnTriple"), gdjs.WarCode.GDTest_95SpawnTripleObjects2);
gdjs.copyArray(runtimeScene.getObjects("TripleShotAuto"), gdjs.WarCode.GDTripleShotAutoObjects2);
{for(var i = 0, len = gdjs.WarCode.GDDoubleShotAutoObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDDoubleShotAutoObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnDoubleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnDoubleObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.WarCode.GDTripleShotAutoObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTripleShotAutoObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.WarCode.GDTest_95SpawnTripleObjects2.length ;i < len;++i) {
    gdjs.WarCode.GDTest_95SpawnTripleObjects2[i].hide();
}
}}

}


{



}


{


{

{ //Subevents
gdjs.WarCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects3Objects = Hashtable.newFrom({"EnemyMaster": gdjs.WarCode.GDEnemyMasterObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects3Objects = Hashtable.newFrom({"EnemySmall": gdjs.WarCode.GDEnemySmallObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.WarCode.GDEnemyObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects = Hashtable.newFrom({"Plane": gdjs.WarCode.GDPlaneObjects3});
gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects = Hashtable.newFrom({"Collide_Explosion": gdjs.WarCode.GDCollide_95ExplosionObjects2});
gdjs.WarCode.eventsList47 = function(runtimeScene) {

{

gdjs.WarCode.GDEnemyObjects2.length = 0;

gdjs.WarCode.GDEnemyMasterObjects2.length = 0;

gdjs.WarCode.GDEnemySmallObjects2.length = 0;

gdjs.WarCode.GDPlaneObjects2.length = 0;


gdjs.WarCode.condition0IsTrue_0.val = false;
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition0IsTrue_0;
gdjs.WarCode.GDEnemyObjects2_1final.length = 0;gdjs.WarCode.GDEnemyMasterObjects2_1final.length = 0;gdjs.WarCode.GDEnemySmallObjects2_1final.length = 0;gdjs.WarCode.GDPlaneObjects2_1final.length = 0;gdjs.WarCode.condition0IsTrue_1.val = false;
gdjs.WarCode.condition1IsTrue_1.val = false;
gdjs.WarCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyMaster"), gdjs.WarCode.GDEnemyMasterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
gdjs.WarCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyMasterObjects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition0IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDEnemyMasterObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDEnemyMasterObjects2_1final.indexOf(gdjs.WarCode.GDEnemyMasterObjects3[j]) === -1 )
            gdjs.WarCode.GDEnemyMasterObjects2_1final.push(gdjs.WarCode.GDEnemyMasterObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDPlaneObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDPlaneObjects2_1final.indexOf(gdjs.WarCode.GDPlaneObjects3[j]) === -1 )
            gdjs.WarCode.GDPlaneObjects2_1final.push(gdjs.WarCode.GDPlaneObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemySmall"), gdjs.WarCode.GDEnemySmallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
gdjs.WarCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemySmallObjects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition1IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDEnemySmallObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDEnemySmallObjects2_1final.indexOf(gdjs.WarCode.GDEnemySmallObjects3[j]) === -1 )
            gdjs.WarCode.GDEnemySmallObjects2_1final.push(gdjs.WarCode.GDEnemySmallObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDPlaneObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDPlaneObjects2_1final.indexOf(gdjs.WarCode.GDPlaneObjects3[j]) === -1 )
            gdjs.WarCode.GDPlaneObjects2_1final.push(gdjs.WarCode.GDPlaneObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.WarCode.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.WarCode.GDPlaneObjects3);
gdjs.WarCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDEnemyObjects3Objects, gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDPlaneObjects3Objects, false, runtimeScene, false);
if( gdjs.WarCode.condition2IsTrue_1.val ) {
    gdjs.WarCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.WarCode.GDEnemyObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDEnemyObjects2_1final.indexOf(gdjs.WarCode.GDEnemyObjects3[j]) === -1 )
            gdjs.WarCode.GDEnemyObjects2_1final.push(gdjs.WarCode.GDEnemyObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.WarCode.GDPlaneObjects3.length;j<jLen;++j) {
        if ( gdjs.WarCode.GDPlaneObjects2_1final.indexOf(gdjs.WarCode.GDPlaneObjects3[j]) === -1 )
            gdjs.WarCode.GDPlaneObjects2_1final.push(gdjs.WarCode.GDPlaneObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.WarCode.GDEnemyObjects2_1final, gdjs.WarCode.GDEnemyObjects2);
gdjs.copyArray(gdjs.WarCode.GDEnemyMasterObjects2_1final, gdjs.WarCode.GDEnemyMasterObjects2);
gdjs.copyArray(gdjs.WarCode.GDEnemySmallObjects2_1final, gdjs.WarCode.GDEnemySmallObjects2);
gdjs.copyArray(gdjs.WarCode.GDPlaneObjects2_1final, gdjs.WarCode.GDPlaneObjects2);
}
}
}if (gdjs.WarCode.condition0IsTrue_0.val) {
/* Reuse gdjs.WarCode.GDPlaneObjects2 */
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDCollide_9595ExplosionObjects2Objects, (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointX("")), (( gdjs.WarCode.GDPlaneObjects2.length === 0 ) ? 0 :gdjs.WarCode.GDPlaneObjects2[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End", false);
}}

}


{


{
}

}


};gdjs.WarCode.eventsList48 = function(runtimeScene) {

{


gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition1IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10958580);
}
}}
if (gdjs.WarCode.condition1IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Ui");
}{runtimeScene.getVariables().get("TweenTutorial_active").setNumber(1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("Game_Start"), false);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenTutorial_active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial"), gdjs.WarCode.GDTutorialObjects1);
{for(var i = 0, len = gdjs.WarCode.GDTutorialObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDTutorialObjects1[i].getBehavior("Tween").addObjectPositionYTween("Tutorial", 1, "easeInQuad", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.WarCode.GDBackgroundObjects1);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBackgroundObjects1Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
gdjs.WarCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenTutorial_active")) == 1;
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Ui");
}{runtimeScene.getVariables().get("TweenTutorial_active").setNumber(2);
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("TweenTutorial_active")) == 2;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial"), gdjs.WarCode.GDTutorialObjects1);
{for(var i = 0, len = gdjs.WarCode.GDTutorialObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDTutorialObjects1[i].getBehavior("Tween").addObjectPositionYTween("Tutorial", -(873), "easeInQuad", 100, false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DragObjectBorder"), gdjs.WarCode.GDDragObjectBorderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stars"), gdjs.WarCode.GDStarsObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getVariables().get("Bullet_Exists").setNumber(0);
}{gdjs.evtTools.sound.playMusic(runtimeScene, "war.mp3", true, 80, 1);
}{for(var i = 0, len = gdjs.WarCode.GDDragObjectBorderObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDDragObjectBorderObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.WarCode.GDStarsObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDStarsObjects1[i].rotate(15, runtimeScene);
}
}}

}


{


{
}

}


{


gdjs.WarCode.eventsList1(runtimeScene);
}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Cannon_Active")) == 0;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cannon1"), gdjs.WarCode.GDCannon1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Cannon2"), gdjs.WarCode.GDCannon2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Cannon3"), gdjs.WarCode.GDCannon3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects1);
{for(var i = 0, len = gdjs.WarCode.GDCrosshairObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshairObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.WarCode.GDCannon1Objects1.length ;i < len;++i) {
    gdjs.WarCode.GDCannon1Objects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDCannon2Objects1.length ;i < len;++i) {
    gdjs.WarCode.GDCannon2Objects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDCannon3Objects1.length ;i < len;++i) {
    gdjs.WarCode.GDCannon3Objects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.WarCode.GDCrosshairObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshairObjects1[i].hide(false);
}
}}

}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Cannon_Active")) == 1;
}if (gdjs.WarCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Crosshair"), gdjs.WarCode.GDCrosshairObjects1);
{for(var i = 0, len = gdjs.WarCode.GDCrosshairObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDCrosshairObjects1[i].hide();
}
}}

}


{



}


{


gdjs.WarCode.condition0IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("Game_Start"), true);
}if (gdjs.WarCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.WarCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.WarCode.eventsList7(runtimeScene);
}


{


{
}

}


{



}


{


gdjs.WarCode.eventsList12(runtimeScene);
}


{


gdjs.WarCode.eventsList17(runtimeScene);
}


{


gdjs.WarCode.eventsList22(runtimeScene);
}


{


{
}

}


{


{
}

}


{



}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("POIN"), gdjs.WarCode.GDPOINObjects1);
{for(var i = 0, len = gdjs.WarCode.GDPOINObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDPOINObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Btn_back"), gdjs.WarCode.GDBtn_95backObjects1);

gdjs.WarCode.condition0IsTrue_0.val = false;
gdjs.WarCode.condition1IsTrue_0.val = false;
gdjs.WarCode.condition2IsTrue_0.val = false;
{
gdjs.WarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.WarCode.mapOfGDgdjs_46WarCode_46GDBtn_9595backObjects1Objects, runtimeScene, true, false);
}if ( gdjs.WarCode.condition0IsTrue_0.val ) {
{
gdjs.WarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WarCode.condition1IsTrue_0.val ) {
{
{gdjs.WarCode.conditionTrue_1 = gdjs.WarCode.condition2IsTrue_0;
gdjs.WarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11060244);
}
}}
}
if (gdjs.WarCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


gdjs.WarCode.eventsList23(runtimeScene);
}


{


gdjs.WarCode.eventsList24(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("EndText"), gdjs.WarCode.GDEndTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartText"), gdjs.WarCode.GDStartTextObjects1);
{for(var i = 0, len = gdjs.WarCode.GDStartTextObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDStartTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Start_Point")));
}
}{for(var i = 0, len = gdjs.WarCode.GDEndTextObjects1.length ;i < len;++i) {
    gdjs.WarCode.GDEndTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("End_Point")));
}
}}

}


{


gdjs.WarCode.eventsList46(runtimeScene);
}


{


gdjs.WarCode.eventsList47(runtimeScene);
}


{



}


{


{
}

}


};

gdjs.WarCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.WarCode.GDBackgroundObjects1.length = 0;
gdjs.WarCode.GDBackgroundObjects2.length = 0;
gdjs.WarCode.GDBackgroundObjects3.length = 0;
gdjs.WarCode.GDBackgroundObjects4.length = 0;
gdjs.WarCode.GDBackgroundObjects5.length = 0;
gdjs.WarCode.GDCollide_95ExplosionObjects1.length = 0;
gdjs.WarCode.GDCollide_95ExplosionObjects2.length = 0;
gdjs.WarCode.GDCollide_95ExplosionObjects3.length = 0;
gdjs.WarCode.GDCollide_95ExplosionObjects4.length = 0;
gdjs.WarCode.GDCollide_95ExplosionObjects5.length = 0;
gdjs.WarCode.GDEnemyObjects1.length = 0;
gdjs.WarCode.GDEnemyObjects2.length = 0;
gdjs.WarCode.GDEnemyObjects3.length = 0;
gdjs.WarCode.GDEnemyObjects4.length = 0;
gdjs.WarCode.GDEnemyObjects5.length = 0;
gdjs.WarCode.GDEnemyDummyObjects1.length = 0;
gdjs.WarCode.GDEnemyDummyObjects2.length = 0;
gdjs.WarCode.GDEnemyDummyObjects3.length = 0;
gdjs.WarCode.GDEnemyDummyObjects4.length = 0;
gdjs.WarCode.GDEnemyDummyObjects5.length = 0;
gdjs.WarCode.GDEnemyMasterObjects1.length = 0;
gdjs.WarCode.GDEnemyMasterObjects2.length = 0;
gdjs.WarCode.GDEnemyMasterObjects3.length = 0;
gdjs.WarCode.GDEnemyMasterObjects4.length = 0;
gdjs.WarCode.GDEnemyMasterObjects5.length = 0;
gdjs.WarCode.GDEnemySmallObjects1.length = 0;
gdjs.WarCode.GDEnemySmallObjects2.length = 0;
gdjs.WarCode.GDEnemySmallObjects3.length = 0;
gdjs.WarCode.GDEnemySmallObjects4.length = 0;
gdjs.WarCode.GDEnemySmallObjects5.length = 0;
gdjs.WarCode.GDPlaneObjects1.length = 0;
gdjs.WarCode.GDPlaneObjects2.length = 0;
gdjs.WarCode.GDPlaneObjects3.length = 0;
gdjs.WarCode.GDPlaneObjects4.length = 0;
gdjs.WarCode.GDPlaneObjects5.length = 0;
gdjs.WarCode.GDBulletObjects1.length = 0;
gdjs.WarCode.GDBulletObjects2.length = 0;
gdjs.WarCode.GDBulletObjects3.length = 0;
gdjs.WarCode.GDBulletObjects4.length = 0;
gdjs.WarCode.GDBulletObjects5.length = 0;
gdjs.WarCode.GDBullet2Objects1.length = 0;
gdjs.WarCode.GDBullet2Objects2.length = 0;
gdjs.WarCode.GDBullet2Objects3.length = 0;
gdjs.WarCode.GDBullet2Objects4.length = 0;
gdjs.WarCode.GDBullet2Objects5.length = 0;
gdjs.WarCode.GDBullet3Objects1.length = 0;
gdjs.WarCode.GDBullet3Objects2.length = 0;
gdjs.WarCode.GDBullet3Objects3.length = 0;
gdjs.WarCode.GDBullet3Objects4.length = 0;
gdjs.WarCode.GDBullet3Objects5.length = 0;
gdjs.WarCode.GDBullet4Objects1.length = 0;
gdjs.WarCode.GDBullet4Objects2.length = 0;
gdjs.WarCode.GDBullet4Objects3.length = 0;
gdjs.WarCode.GDBullet4Objects4.length = 0;
gdjs.WarCode.GDBullet4Objects5.length = 0;
gdjs.WarCode.GDEnemySpawnLocationObjects1.length = 0;
gdjs.WarCode.GDEnemySpawnLocationObjects2.length = 0;
gdjs.WarCode.GDEnemySpawnLocationObjects3.length = 0;
gdjs.WarCode.GDEnemySpawnLocationObjects4.length = 0;
gdjs.WarCode.GDEnemySpawnLocationObjects5.length = 0;
gdjs.WarCode.GDCrosshairObjects1.length = 0;
gdjs.WarCode.GDCrosshairObjects2.length = 0;
gdjs.WarCode.GDCrosshairObjects3.length = 0;
gdjs.WarCode.GDCrosshairObjects4.length = 0;
gdjs.WarCode.GDCrosshairObjects5.length = 0;
gdjs.WarCode.GDCrosshair_95CloneObjects1.length = 0;
gdjs.WarCode.GDCrosshair_95CloneObjects2.length = 0;
gdjs.WarCode.GDCrosshair_95CloneObjects3.length = 0;
gdjs.WarCode.GDCrosshair_95CloneObjects4.length = 0;
gdjs.WarCode.GDCrosshair_95CloneObjects5.length = 0;
gdjs.WarCode.GDCrosshair_95TutorialObjects1.length = 0;
gdjs.WarCode.GDCrosshair_95TutorialObjects2.length = 0;
gdjs.WarCode.GDCrosshair_95TutorialObjects3.length = 0;
gdjs.WarCode.GDCrosshair_95TutorialObjects4.length = 0;
gdjs.WarCode.GDCrosshair_95TutorialObjects5.length = 0;
gdjs.WarCode.GDPOINObjects1.length = 0;
gdjs.WarCode.GDPOINObjects2.length = 0;
gdjs.WarCode.GDPOINObjects3.length = 0;
gdjs.WarCode.GDPOINObjects4.length = 0;
gdjs.WarCode.GDPOINObjects5.length = 0;
gdjs.WarCode.GDCannon_95RefillAnimObjects1.length = 0;
gdjs.WarCode.GDCannon_95RefillAnimObjects2.length = 0;
gdjs.WarCode.GDCannon_95RefillAnimObjects3.length = 0;
gdjs.WarCode.GDCannon_95RefillAnimObjects4.length = 0;
gdjs.WarCode.GDCannon_95RefillAnimObjects5.length = 0;
gdjs.WarCode.GDStarsObjects1.length = 0;
gdjs.WarCode.GDStarsObjects2.length = 0;
gdjs.WarCode.GDStarsObjects3.length = 0;
gdjs.WarCode.GDStarsObjects4.length = 0;
gdjs.WarCode.GDStarsObjects5.length = 0;
gdjs.WarCode.GDAddScoreObjects1.length = 0;
gdjs.WarCode.GDAddScoreObjects2.length = 0;
gdjs.WarCode.GDAddScoreObjects3.length = 0;
gdjs.WarCode.GDAddScoreObjects4.length = 0;
gdjs.WarCode.GDAddScoreObjects5.length = 0;
gdjs.WarCode.GDAddScore2Objects1.length = 0;
gdjs.WarCode.GDAddScore2Objects2.length = 0;
gdjs.WarCode.GDAddScore2Objects3.length = 0;
gdjs.WarCode.GDAddScore2Objects4.length = 0;
gdjs.WarCode.GDAddScore2Objects5.length = 0;
gdjs.WarCode.GDBtn_95backObjects1.length = 0;
gdjs.WarCode.GDBtn_95backObjects2.length = 0;
gdjs.WarCode.GDBtn_95backObjects3.length = 0;
gdjs.WarCode.GDBtn_95backObjects4.length = 0;
gdjs.WarCode.GDBtn_95backObjects5.length = 0;
gdjs.WarCode.GDTripleShotObjects1.length = 0;
gdjs.WarCode.GDTripleShotObjects2.length = 0;
gdjs.WarCode.GDTripleShotObjects3.length = 0;
gdjs.WarCode.GDTripleShotObjects4.length = 0;
gdjs.WarCode.GDTripleShotObjects5.length = 0;
gdjs.WarCode.GDTest_95SpawnDoubleObjects1.length = 0;
gdjs.WarCode.GDTest_95SpawnDoubleObjects2.length = 0;
gdjs.WarCode.GDTest_95SpawnDoubleObjects3.length = 0;
gdjs.WarCode.GDTest_95SpawnDoubleObjects4.length = 0;
gdjs.WarCode.GDTest_95SpawnDoubleObjects5.length = 0;
gdjs.WarCode.GDTest_95SpawnTripleObjects1.length = 0;
gdjs.WarCode.GDTest_95SpawnTripleObjects2.length = 0;
gdjs.WarCode.GDTest_95SpawnTripleObjects3.length = 0;
gdjs.WarCode.GDTest_95SpawnTripleObjects4.length = 0;
gdjs.WarCode.GDTest_95SpawnTripleObjects5.length = 0;
gdjs.WarCode.GDDragObjectBorderObjects1.length = 0;
gdjs.WarCode.GDDragObjectBorderObjects2.length = 0;
gdjs.WarCode.GDDragObjectBorderObjects3.length = 0;
gdjs.WarCode.GDDragObjectBorderObjects4.length = 0;
gdjs.WarCode.GDDragObjectBorderObjects5.length = 0;
gdjs.WarCode.GDCannon1Objects1.length = 0;
gdjs.WarCode.GDCannon1Objects2.length = 0;
gdjs.WarCode.GDCannon1Objects3.length = 0;
gdjs.WarCode.GDCannon1Objects4.length = 0;
gdjs.WarCode.GDCannon1Objects5.length = 0;
gdjs.WarCode.GDCannon3Objects1.length = 0;
gdjs.WarCode.GDCannon3Objects2.length = 0;
gdjs.WarCode.GDCannon3Objects3.length = 0;
gdjs.WarCode.GDCannon3Objects4.length = 0;
gdjs.WarCode.GDCannon3Objects5.length = 0;
gdjs.WarCode.GDCannon2Objects1.length = 0;
gdjs.WarCode.GDCannon2Objects2.length = 0;
gdjs.WarCode.GDCannon2Objects3.length = 0;
gdjs.WarCode.GDCannon2Objects4.length = 0;
gdjs.WarCode.GDCannon2Objects5.length = 0;
gdjs.WarCode.GDTapScreenObjects1.length = 0;
gdjs.WarCode.GDTapScreenObjects2.length = 0;
gdjs.WarCode.GDTapScreenObjects3.length = 0;
gdjs.WarCode.GDTapScreenObjects4.length = 0;
gdjs.WarCode.GDTapScreenObjects5.length = 0;
gdjs.WarCode.GDGameStatusObjects1.length = 0;
gdjs.WarCode.GDGameStatusObjects2.length = 0;
gdjs.WarCode.GDGameStatusObjects3.length = 0;
gdjs.WarCode.GDGameStatusObjects4.length = 0;
gdjs.WarCode.GDGameStatusObjects5.length = 0;
gdjs.WarCode.GDTimerEnemyObjects1.length = 0;
gdjs.WarCode.GDTimerEnemyObjects2.length = 0;
gdjs.WarCode.GDTimerEnemyObjects3.length = 0;
gdjs.WarCode.GDTimerEnemyObjects4.length = 0;
gdjs.WarCode.GDTimerEnemyObjects5.length = 0;
gdjs.WarCode.GDTimerEnemy2Objects1.length = 0;
gdjs.WarCode.GDTimerEnemy2Objects2.length = 0;
gdjs.WarCode.GDTimerEnemy2Objects3.length = 0;
gdjs.WarCode.GDTimerEnemy2Objects4.length = 0;
gdjs.WarCode.GDTimerEnemy2Objects5.length = 0;
gdjs.WarCode.GDTimerEnemy3Objects1.length = 0;
gdjs.WarCode.GDTimerEnemy3Objects2.length = 0;
gdjs.WarCode.GDTimerEnemy3Objects3.length = 0;
gdjs.WarCode.GDTimerEnemy3Objects4.length = 0;
gdjs.WarCode.GDTimerEnemy3Objects5.length = 0;
gdjs.WarCode.GDProgressBarObjects1.length = 0;
gdjs.WarCode.GDProgressBarObjects2.length = 0;
gdjs.WarCode.GDProgressBarObjects3.length = 0;
gdjs.WarCode.GDProgressBarObjects4.length = 0;
gdjs.WarCode.GDProgressBarObjects5.length = 0;
gdjs.WarCode.GDStartTextObjects1.length = 0;
gdjs.WarCode.GDStartTextObjects2.length = 0;
gdjs.WarCode.GDStartTextObjects3.length = 0;
gdjs.WarCode.GDStartTextObjects4.length = 0;
gdjs.WarCode.GDStartTextObjects5.length = 0;
gdjs.WarCode.GDEndTextObjects1.length = 0;
gdjs.WarCode.GDEndTextObjects2.length = 0;
gdjs.WarCode.GDEndTextObjects3.length = 0;
gdjs.WarCode.GDEndTextObjects4.length = 0;
gdjs.WarCode.GDEndTextObjects5.length = 0;
gdjs.WarCode.GDBarObjects1.length = 0;
gdjs.WarCode.GDBarObjects2.length = 0;
gdjs.WarCode.GDBarObjects3.length = 0;
gdjs.WarCode.GDBarObjects4.length = 0;
gdjs.WarCode.GDBarObjects5.length = 0;
gdjs.WarCode.GDTutorialObjects1.length = 0;
gdjs.WarCode.GDTutorialObjects2.length = 0;
gdjs.WarCode.GDTutorialObjects3.length = 0;
gdjs.WarCode.GDTutorialObjects4.length = 0;
gdjs.WarCode.GDTutorialObjects5.length = 0;
gdjs.WarCode.GDUnlockObjects1.length = 0;
gdjs.WarCode.GDUnlockObjects2.length = 0;
gdjs.WarCode.GDUnlockObjects3.length = 0;
gdjs.WarCode.GDUnlockObjects4.length = 0;
gdjs.WarCode.GDUnlockObjects5.length = 0;
gdjs.WarCode.GDDoubleShotAutoObjects1.length = 0;
gdjs.WarCode.GDDoubleShotAutoObjects2.length = 0;
gdjs.WarCode.GDDoubleShotAutoObjects3.length = 0;
gdjs.WarCode.GDDoubleShotAutoObjects4.length = 0;
gdjs.WarCode.GDDoubleShotAutoObjects5.length = 0;
gdjs.WarCode.GDTripleShotAutoObjects1.length = 0;
gdjs.WarCode.GDTripleShotAutoObjects2.length = 0;
gdjs.WarCode.GDTripleShotAutoObjects3.length = 0;
gdjs.WarCode.GDTripleShotAutoObjects4.length = 0;
gdjs.WarCode.GDTripleShotAutoObjects5.length = 0;
gdjs.WarCode.GDUnlock_95Ui100Objects1.length = 0;
gdjs.WarCode.GDUnlock_95Ui100Objects2.length = 0;
gdjs.WarCode.GDUnlock_95Ui100Objects3.length = 0;
gdjs.WarCode.GDUnlock_95Ui100Objects4.length = 0;
gdjs.WarCode.GDUnlock_95Ui100Objects5.length = 0;
gdjs.WarCode.GDUnlock_95Ui500Objects1.length = 0;
gdjs.WarCode.GDUnlock_95Ui500Objects2.length = 0;
gdjs.WarCode.GDUnlock_95Ui500Objects3.length = 0;
gdjs.WarCode.GDUnlock_95Ui500Objects4.length = 0;
gdjs.WarCode.GDUnlock_95Ui500Objects5.length = 0;
gdjs.WarCode.GDUnlock_95Ui1000Objects1.length = 0;
gdjs.WarCode.GDUnlock_95Ui1000Objects2.length = 0;
gdjs.WarCode.GDUnlock_95Ui1000Objects3.length = 0;
gdjs.WarCode.GDUnlock_95Ui1000Objects4.length = 0;
gdjs.WarCode.GDUnlock_95Ui1000Objects5.length = 0;
gdjs.WarCode.GDUnlock_95Ui5000Objects1.length = 0;
gdjs.WarCode.GDUnlock_95Ui5000Objects2.length = 0;
gdjs.WarCode.GDUnlock_95Ui5000Objects3.length = 0;
gdjs.WarCode.GDUnlock_95Ui5000Objects4.length = 0;
gdjs.WarCode.GDUnlock_95Ui5000Objects5.length = 0;

gdjs.WarCode.eventsList48(runtimeScene);
return;

}

gdjs['WarCode'] = gdjs.WarCode;
