gdjs.GameplayCode = {};
gdjs.GameplayCode.GDControlSwipeObjects2_1final = [];

gdjs.GameplayCode.GDControlSwipeObjects2_2final = [];

gdjs.GameplayCode.GDObstacle_9511Objects2_1final = [];

gdjs.GameplayCode.GDObstacle_9512Objects2_1final = [];

gdjs.GameplayCode.GDObstacle_9521Objects2_1final = [];

gdjs.GameplayCode.GDObstacle_9522Objects2_1final = [];

gdjs.GameplayCode.GDObstacle_953Objects2_1final = [];

gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final = [];

gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final = [];

gdjs.GameplayCode.GDStage1Objects2_1final = [];

gdjs.GameplayCode.GDStage2Objects2_1final = [];

gdjs.GameplayCode.GDStage3Objects2_1final = [];

gdjs.GameplayCode.GDStage4Objects2_1final = [];

gdjs.GameplayCode.GDStage4Objects2_2final = [];

gdjs.GameplayCode.GDStage6Objects1_1final = [];

gdjs.GameplayCode.GDStage6Objects2_2final = [];

gdjs.GameplayCode.GDSwipeDirectionObjects2_2final = [];

gdjs.GameplayCode.GDTitleObjects2_1final = [];

gdjs.GameplayCode.GDTitleObjects1= [];
gdjs.GameplayCode.GDTitleObjects2= [];
gdjs.GameplayCode.GDTitleObjects3= [];
gdjs.GameplayCode.GDTitleObjects4= [];
gdjs.GameplayCode.GDBGObjects1= [];
gdjs.GameplayCode.GDBGObjects2= [];
gdjs.GameplayCode.GDBGObjects3= [];
gdjs.GameplayCode.GDBGObjects4= [];
gdjs.GameplayCode.GDPlayer_95HitboxObjects1= [];
gdjs.GameplayCode.GDPlayer_95HitboxObjects2= [];
gdjs.GameplayCode.GDPlayer_95HitboxObjects3= [];
gdjs.GameplayCode.GDPlayer_95HitboxObjects4= [];
gdjs.GameplayCode.GDTween_95CurtainObjects1= [];
gdjs.GameplayCode.GDTween_95CurtainObjects2= [];
gdjs.GameplayCode.GDTween_95CurtainObjects3= [];
gdjs.GameplayCode.GDTween_95CurtainObjects4= [];
gdjs.GameplayCode.GDPlayerObjects1= [];
gdjs.GameplayCode.GDPlayerObjects2= [];
gdjs.GameplayCode.GDPlayerObjects3= [];
gdjs.GameplayCode.GDPlayerObjects4= [];
gdjs.GameplayCode.GDStage1Objects1= [];
gdjs.GameplayCode.GDStage1Objects2= [];
gdjs.GameplayCode.GDStage1Objects3= [];
gdjs.GameplayCode.GDStage1Objects4= [];
gdjs.GameplayCode.GDStage2Objects1= [];
gdjs.GameplayCode.GDStage2Objects2= [];
gdjs.GameplayCode.GDStage2Objects3= [];
gdjs.GameplayCode.GDStage2Objects4= [];
gdjs.GameplayCode.GDStage3Objects1= [];
gdjs.GameplayCode.GDStage3Objects2= [];
gdjs.GameplayCode.GDStage3Objects3= [];
gdjs.GameplayCode.GDStage3Objects4= [];
gdjs.GameplayCode.GDStage4Objects1= [];
gdjs.GameplayCode.GDStage4Objects2= [];
gdjs.GameplayCode.GDStage4Objects3= [];
gdjs.GameplayCode.GDStage4Objects4= [];
gdjs.GameplayCode.GDStage5Objects1= [];
gdjs.GameplayCode.GDStage5Objects2= [];
gdjs.GameplayCode.GDStage5Objects3= [];
gdjs.GameplayCode.GDStage5Objects4= [];
gdjs.GameplayCode.GDStage6Objects1= [];
gdjs.GameplayCode.GDStage6Objects2= [];
gdjs.GameplayCode.GDStage6Objects3= [];
gdjs.GameplayCode.GDStage6Objects4= [];
gdjs.GameplayCode.GDCheckerObjects1= [];
gdjs.GameplayCode.GDCheckerObjects2= [];
gdjs.GameplayCode.GDCheckerObjects3= [];
gdjs.GameplayCode.GDCheckerObjects4= [];
gdjs.GameplayCode.GDObstacle_9511Objects1= [];
gdjs.GameplayCode.GDObstacle_9511Objects2= [];
gdjs.GameplayCode.GDObstacle_9511Objects3= [];
gdjs.GameplayCode.GDObstacle_9511Objects4= [];
gdjs.GameplayCode.GDObstacle_9512Objects1= [];
gdjs.GameplayCode.GDObstacle_9512Objects2= [];
gdjs.GameplayCode.GDObstacle_9512Objects3= [];
gdjs.GameplayCode.GDObstacle_9512Objects4= [];
gdjs.GameplayCode.GDObstacle_9521Objects1= [];
gdjs.GameplayCode.GDObstacle_9521Objects2= [];
gdjs.GameplayCode.GDObstacle_9521Objects3= [];
gdjs.GameplayCode.GDObstacle_9521Objects4= [];
gdjs.GameplayCode.GDObstacle_9522Objects1= [];
gdjs.GameplayCode.GDObstacle_9522Objects2= [];
gdjs.GameplayCode.GDObstacle_9522Objects3= [];
gdjs.GameplayCode.GDObstacle_9522Objects4= [];
gdjs.GameplayCode.GDObstacle_953Objects1= [];
gdjs.GameplayCode.GDObstacle_953Objects2= [];
gdjs.GameplayCode.GDObstacle_953Objects3= [];
gdjs.GameplayCode.GDObstacle_953Objects4= [];
gdjs.GameplayCode.GDObstacle_9544Objects1= [];
gdjs.GameplayCode.GDObstacle_9544Objects2= [];
gdjs.GameplayCode.GDObstacle_9544Objects3= [];
gdjs.GameplayCode.GDObstacle_9544Objects4= [];
gdjs.GameplayCode.GDObstacle_9543Objects1= [];
gdjs.GameplayCode.GDObstacle_9543Objects2= [];
gdjs.GameplayCode.GDObstacle_9543Objects3= [];
gdjs.GameplayCode.GDObstacle_9543Objects4= [];
gdjs.GameplayCode.GDObstacle_9542Objects1= [];
gdjs.GameplayCode.GDObstacle_9542Objects2= [];
gdjs.GameplayCode.GDObstacle_9542Objects3= [];
gdjs.GameplayCode.GDObstacle_9542Objects4= [];
gdjs.GameplayCode.GDObstacle_9541Objects1= [];
gdjs.GameplayCode.GDObstacle_9541Objects2= [];
gdjs.GameplayCode.GDObstacle_9541Objects3= [];
gdjs.GameplayCode.GDObstacle_9541Objects4= [];
gdjs.GameplayCode.GDObstacleChecker_95wObjects1= [];
gdjs.GameplayCode.GDObstacleChecker_95wObjects2= [];
gdjs.GameplayCode.GDObstacleChecker_95wObjects3= [];
gdjs.GameplayCode.GDObstacleChecker_95wObjects4= [];
gdjs.GameplayCode.GDObstacleChecker_95aObjects1= [];
gdjs.GameplayCode.GDObstacleChecker_95aObjects2= [];
gdjs.GameplayCode.GDObstacleChecker_95aObjects3= [];
gdjs.GameplayCode.GDObstacleChecker_95aObjects4= [];
gdjs.GameplayCode.GDObstacleChecker_95sObjects1= [];
gdjs.GameplayCode.GDObstacleChecker_95sObjects2= [];
gdjs.GameplayCode.GDObstacleChecker_95sObjects3= [];
gdjs.GameplayCode.GDObstacleChecker_95sObjects4= [];
gdjs.GameplayCode.GDObstacleChecker_95dObjects1= [];
gdjs.GameplayCode.GDObstacleChecker_95dObjects2= [];
gdjs.GameplayCode.GDObstacleChecker_95dObjects3= [];
gdjs.GameplayCode.GDObstacleChecker_95dObjects4= [];
gdjs.GameplayCode.GDScoreObjects1= [];
gdjs.GameplayCode.GDScoreObjects2= [];
gdjs.GameplayCode.GDScoreObjects3= [];
gdjs.GameplayCode.GDScoreObjects4= [];
gdjs.GameplayCode.GDTrainCheckerObjects1= [];
gdjs.GameplayCode.GDTrainCheckerObjects2= [];
gdjs.GameplayCode.GDTrainCheckerObjects3= [];
gdjs.GameplayCode.GDTrainCheckerObjects4= [];
gdjs.GameplayCode.GDLightObjects1= [];
gdjs.GameplayCode.GDLightObjects2= [];
gdjs.GameplayCode.GDLightObjects3= [];
gdjs.GameplayCode.GDLightObjects4= [];
gdjs.GameplayCode.GDTapLogoObjects1= [];
gdjs.GameplayCode.GDTapLogoObjects2= [];
gdjs.GameplayCode.GDTapLogoObjects3= [];
gdjs.GameplayCode.GDTapLogoObjects4= [];
gdjs.GameplayCode.GDSwipeToStartObjects1= [];
gdjs.GameplayCode.GDSwipeToStartObjects2= [];
gdjs.GameplayCode.GDSwipeToStartObjects3= [];
gdjs.GameplayCode.GDSwipeToStartObjects4= [];
gdjs.GameplayCode.GDNewBBTextObjects1= [];
gdjs.GameplayCode.GDNewBBTextObjects2= [];
gdjs.GameplayCode.GDNewBBTextObjects3= [];
gdjs.GameplayCode.GDNewBBTextObjects4= [];
gdjs.GameplayCode.GDDeathTriggerObjects1= [];
gdjs.GameplayCode.GDDeathTriggerObjects2= [];
gdjs.GameplayCode.GDDeathTriggerObjects3= [];
gdjs.GameplayCode.GDDeathTriggerObjects4= [];
gdjs.GameplayCode.GDMove_95ForwardObjects1= [];
gdjs.GameplayCode.GDMove_95ForwardObjects2= [];
gdjs.GameplayCode.GDMove_95ForwardObjects3= [];
gdjs.GameplayCode.GDMove_95ForwardObjects4= [];
gdjs.GameplayCode.GDMove_95LeftObjects1= [];
gdjs.GameplayCode.GDMove_95LeftObjects2= [];
gdjs.GameplayCode.GDMove_95LeftObjects3= [];
gdjs.GameplayCode.GDMove_95LeftObjects4= [];
gdjs.GameplayCode.GDMove_95RightObjects1= [];
gdjs.GameplayCode.GDMove_95RightObjects2= [];
gdjs.GameplayCode.GDMove_95RightObjects3= [];
gdjs.GameplayCode.GDMove_95RightObjects4= [];
gdjs.GameplayCode.GDMove_95BackwardObjects1= [];
gdjs.GameplayCode.GDMove_95BackwardObjects2= [];
gdjs.GameplayCode.GDMove_95BackwardObjects3= [];
gdjs.GameplayCode.GDMove_95BackwardObjects4= [];
gdjs.GameplayCode.GDTutorial_95UIObjects1= [];
gdjs.GameplayCode.GDTutorial_95UIObjects2= [];
gdjs.GameplayCode.GDTutorial_95UIObjects3= [];
gdjs.GameplayCode.GDTutorial_95UIObjects4= [];
gdjs.GameplayCode.GDNewSprite2Objects1= [];
gdjs.GameplayCode.GDNewSprite2Objects2= [];
gdjs.GameplayCode.GDNewSprite2Objects3= [];
gdjs.GameplayCode.GDNewSprite2Objects4= [];
gdjs.GameplayCode.GDControlSwipeObjects1= [];
gdjs.GameplayCode.GDControlSwipeObjects2= [];
gdjs.GameplayCode.GDControlSwipeObjects3= [];
gdjs.GameplayCode.GDControlSwipeObjects4= [];
gdjs.GameplayCode.GDSwipeDirectionObjects1= [];
gdjs.GameplayCode.GDSwipeDirectionObjects2= [];
gdjs.GameplayCode.GDSwipeDirectionObjects3= [];
gdjs.GameplayCode.GDSwipeDirectionObjects4= [];
gdjs.GameplayCode.GDCurrentURLObjects1= [];
gdjs.GameplayCode.GDCurrentURLObjects2= [];
gdjs.GameplayCode.GDCurrentURLObjects3= [];
gdjs.GameplayCode.GDCurrentURLObjects4= [];
gdjs.GameplayCode.GDGetParameterObjects1= [];
gdjs.GameplayCode.GDGetParameterObjects2= [];
gdjs.GameplayCode.GDGetParameterObjects3= [];
gdjs.GameplayCode.GDGetParameterObjects4= [];

gdjs.GameplayCode.conditionTrue_0 = {val:false};
gdjs.GameplayCode.condition0IsTrue_0 = {val:false};
gdjs.GameplayCode.condition1IsTrue_0 = {val:false};
gdjs.GameplayCode.condition2IsTrue_0 = {val:false};
gdjs.GameplayCode.condition3IsTrue_0 = {val:false};
gdjs.GameplayCode.condition4IsTrue_0 = {val:false};
gdjs.GameplayCode.condition5IsTrue_0 = {val:false};
gdjs.GameplayCode.condition6IsTrue_0 = {val:false};
gdjs.GameplayCode.condition7IsTrue_0 = {val:false};
gdjs.GameplayCode.condition8IsTrue_0 = {val:false};
gdjs.GameplayCode.condition9IsTrue_0 = {val:false};
gdjs.GameplayCode.conditionTrue_1 = {val:false};
gdjs.GameplayCode.condition0IsTrue_1 = {val:false};
gdjs.GameplayCode.condition1IsTrue_1 = {val:false};
gdjs.GameplayCode.condition2IsTrue_1 = {val:false};
gdjs.GameplayCode.condition3IsTrue_1 = {val:false};
gdjs.GameplayCode.condition4IsTrue_1 = {val:false};
gdjs.GameplayCode.condition5IsTrue_1 = {val:false};
gdjs.GameplayCode.condition6IsTrue_1 = {val:false};
gdjs.GameplayCode.condition7IsTrue_1 = {val:false};
gdjs.GameplayCode.condition8IsTrue_1 = {val:false};
gdjs.GameplayCode.condition9IsTrue_1 = {val:false};
gdjs.GameplayCode.conditionTrue_2 = {val:false};
gdjs.GameplayCode.condition0IsTrue_2 = {val:false};
gdjs.GameplayCode.condition1IsTrue_2 = {val:false};
gdjs.GameplayCode.condition2IsTrue_2 = {val:false};
gdjs.GameplayCode.condition3IsTrue_2 = {val:false};
gdjs.GameplayCode.condition4IsTrue_2 = {val:false};
gdjs.GameplayCode.condition5IsTrue_2 = {val:false};
gdjs.GameplayCode.condition6IsTrue_2 = {val:false};
gdjs.GameplayCode.condition7IsTrue_2 = {val:false};
gdjs.GameplayCode.condition8IsTrue_2 = {val:false};
gdjs.GameplayCode.condition9IsTrue_2 = {val:false};


gdjs.GameplayCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("CurrentURL"), gdjs.GameplayCode.GDCurrentURLObjects1);
gdjs.copyArray(runtimeScene.getObjects("GetParameter"), gdjs.GameplayCode.GDGetParameterObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDCurrentURLObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCurrentURLObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.GameplayCode.GDGetParameterObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGetParameterObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}}

}


};gdjs.GameplayCode.eventsList1 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString(gdjs.evtsExt__URLTools__CurrentURL.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setString(gdjs.evtsExt__URLTools__URLQueryStringParameter.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)), "ContractID", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().getFromIndex(10).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
{ //Subevents
gdjs.GameplayCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects2[i].hide();
}
}}

}


{

gdjs.GameplayCode.GDControlSwipeObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition1IsTrue_1;
gdjs.GameplayCode.GDControlSwipeObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ControlSwipe"), gdjs.GameplayCode.GDControlSwipeObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDControlSwipeObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDControlSwipeObjects3[i].getBehavior("Swipe").IsDone((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameplayCode.condition1IsTrue_2.val = true;
        gdjs.GameplayCode.GDControlSwipeObjects3[k] = gdjs.GameplayCode.GDControlSwipeObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDControlSwipeObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDControlSwipeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDControlSwipeObjects2_2final.indexOf(gdjs.GameplayCode.GDControlSwipeObjects3[j]) === -1 )
            gdjs.GameplayCode.GDControlSwipeObjects2_2final.push(gdjs.GameplayCode.GDControlSwipeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDControlSwipeObjects2_2final, gdjs.GameplayCode.GDControlSwipeObjects2);
}
}
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("SwipeToStart"), gdjs.GameplayCode.GDSwipeToStartObjects2);
gdjs.copyArray(runtimeScene.getObjects("TapLogo"), gdjs.GameplayCode.GDTapLogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_UI"), gdjs.GameplayCode.GDTutorial_95UIObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.GameplayCode.GDTapLogoObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTapLogoObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDSwipeToStartObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeToStartObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTutorial_95UIObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTutorial_95UIObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects2[i].getBehavior("Tween").addObjectPositionTween("MoveUp", (gdjs.GameplayCode.GDTitleObjects2[i].getPointX("")), -(500), "linear", 1000, false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DeathTrigger"), gdjs.GameplayCode.GDDeathTriggerObjects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "Obstacle", 0) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))), "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "Player", 0) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))), "Player", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))), "", 0);
}{for(var i = 0, len = gdjs.GameplayCode.GDDeathTriggerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDDeathTriggerObjects2[i].setY(gdjs.GameplayCode.GDDeathTriggerObjects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_a"), gdjs.GameplayCode.GDObstacleChecker_95aObjects1);
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_d"), gdjs.GameplayCode.GDObstacleChecker_95dObjects1);
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_s"), gdjs.GameplayCode.GDObstacleChecker_95sObjects1);
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_w"), gdjs.GameplayCode.GDObstacleChecker_95wObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("TrainChecker"), gdjs.GameplayCode.GDTrainCheckerObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95wObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95wObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95sObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95sObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95aObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95aObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95dObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95dObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDCheckerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCheckerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDTrainCheckerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTrainCheckerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects1[i].hide();
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDControlSwipeObjects2Objects = Hashtable.newFrom({"ControlSwipe": gdjs.GameplayCode.GDControlSwipeObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects = Hashtable.newFrom({"ObstacleChecker_w": gdjs.GameplayCode.GDObstacleChecker_95wObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects = Hashtable.newFrom({"Obstacle_41": gdjs.GameplayCode.GDObstacle_9541Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects = Hashtable.newFrom({"ObstacleChecker_w": gdjs.GameplayCode.GDObstacleChecker_95wObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects = Hashtable.newFrom({"Obstacle_42": gdjs.GameplayCode.GDObstacle_9542Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects = Hashtable.newFrom({"ObstacleChecker_w": gdjs.GameplayCode.GDObstacleChecker_95wObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects = Hashtable.newFrom({"Obstacle_44": gdjs.GameplayCode.GDObstacle_9544Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects = Hashtable.newFrom({"ObstacleChecker_w": gdjs.GameplayCode.GDObstacleChecker_95wObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects = Hashtable.newFrom({"Obstacle_43": gdjs.GameplayCode.GDObstacle_9543Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects = Hashtable.newFrom({"ObstacleChecker_s": gdjs.GameplayCode.GDObstacleChecker_95sObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects = Hashtable.newFrom({"Obstacle_41": gdjs.GameplayCode.GDObstacle_9541Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects = Hashtable.newFrom({"ObstacleChecker_s": gdjs.GameplayCode.GDObstacleChecker_95sObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects = Hashtable.newFrom({"Obstacle_42": gdjs.GameplayCode.GDObstacle_9542Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects = Hashtable.newFrom({"ObstacleChecker_s": gdjs.GameplayCode.GDObstacleChecker_95sObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects = Hashtable.newFrom({"Obstacle_44": gdjs.GameplayCode.GDObstacle_9544Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects = Hashtable.newFrom({"ObstacleChecker_s": gdjs.GameplayCode.GDObstacleChecker_95sObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects = Hashtable.newFrom({"Obstacle_43": gdjs.GameplayCode.GDObstacle_9543Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects = Hashtable.newFrom({"ObstacleChecker_a": gdjs.GameplayCode.GDObstacleChecker_95aObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects = Hashtable.newFrom({"Obstacle_41": gdjs.GameplayCode.GDObstacle_9541Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects = Hashtable.newFrom({"ObstacleChecker_a": gdjs.GameplayCode.GDObstacleChecker_95aObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects = Hashtable.newFrom({"Obstacle_42": gdjs.GameplayCode.GDObstacle_9542Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects = Hashtable.newFrom({"ObstacleChecker_a": gdjs.GameplayCode.GDObstacleChecker_95aObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects = Hashtable.newFrom({"Obstacle_44": gdjs.GameplayCode.GDObstacle_9544Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects = Hashtable.newFrom({"ObstacleChecker_a": gdjs.GameplayCode.GDObstacleChecker_95aObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects = Hashtable.newFrom({"Obstacle_43": gdjs.GameplayCode.GDObstacle_9543Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects = Hashtable.newFrom({"ObstacleChecker_d": gdjs.GameplayCode.GDObstacleChecker_95dObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects = Hashtable.newFrom({"Obstacle_41": gdjs.GameplayCode.GDObstacle_9541Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects = Hashtable.newFrom({"ObstacleChecker_d": gdjs.GameplayCode.GDObstacleChecker_95dObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects = Hashtable.newFrom({"Obstacle_42": gdjs.GameplayCode.GDObstacle_9542Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects = Hashtable.newFrom({"ObstacleChecker_d": gdjs.GameplayCode.GDObstacleChecker_95dObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects = Hashtable.newFrom({"Obstacle_44": gdjs.GameplayCode.GDObstacle_9544Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects = Hashtable.newFrom({"ObstacleChecker_d": gdjs.GameplayCode.GDObstacleChecker_95dObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects = Hashtable.newFrom({"Obstacle_43": gdjs.GameplayCode.GDObstacle_9543Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects2});
gdjs.GameplayCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects3);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects, true, runtimeScene, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() >= 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() < 50 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10948652);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].setX(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects3);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects, true, runtimeScene, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() >= 50 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() < 150 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10950044);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].setX(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects3);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects, true, runtimeScene, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() >= 150 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() < 250 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10952892);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].setX(200);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects3);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects, true, runtimeScene, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() >= 250 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() < 350 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10953716);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects3 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].setX(300);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects, true, runtimeScene, false);
}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getX() >= 350 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects2[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getX() < 400 ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects2[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = k;}}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10957100);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].setX(400);
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDeathTriggerObjects2Objects = Hashtable.newFrom({"DeathTrigger": gdjs.GameplayCode.GDDeathTriggerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959512Objects3Objects = Hashtable.newFrom({"Obstacle_12": gdjs.GameplayCode.GDObstacle_9512Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959511Objects3Objects = Hashtable.newFrom({"Obstacle_11": gdjs.GameplayCode.GDObstacle_9511Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_95953Objects3Objects = Hashtable.newFrom({"Obstacle_3": gdjs.GameplayCode.GDObstacle_953Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage4Objects3Objects = Hashtable.newFrom({"Stage4": gdjs.GameplayCode.GDStage4Objects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects = Hashtable.newFrom({"Player_Hitbox": gdjs.GameplayCode.GDPlayer_95HitboxObjects3});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage6Objects3Objects = Hashtable.newFrom({"Stage6": gdjs.GameplayCode.GDStage6Objects3});
gdjs.GameplayCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DeathTrigger"), gdjs.GameplayCode.GDDeathTriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDDeathTriggerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10957492);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "60013__qubodup__whoosh.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectOpacityTween("PlayerOpacity", 0, "linear", 500, true);
}
}}

}


{

gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() > 405 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i].getX() < -(5) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects3[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final, gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10959332);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "421184__inspectorj__water-pouring-a.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectOpacityTween("PlayerOpacity", 0, "linear", 1000, true);
}
}}

}


{

gdjs.GameplayCode.GDObstacle_9511Objects2.length = 0;

gdjs.GameplayCode.GDObstacle_9512Objects2.length = 0;

gdjs.GameplayCode.GDObstacle_953Objects2.length = 0;

gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDObstacle_9511Objects2_1final.length = 0;gdjs.GameplayCode.GDObstacle_9512Objects2_1final.length = 0;gdjs.GameplayCode.GDObstacle_953Objects2_1final.length = 0;gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle_12"), gdjs.GameplayCode.GDObstacle_9512Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959512Objects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDObstacle_9512Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDObstacle_9512Objects2_1final.indexOf(gdjs.GameplayCode.GDObstacle_9512Objects3[j]) === -1 )
            gdjs.GameplayCode.GDObstacle_9512Objects2_1final.push(gdjs.GameplayCode.GDObstacle_9512Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle_11"), gdjs.GameplayCode.GDObstacle_9511Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959511Objects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDObstacle_9511Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDObstacle_9511Objects2_1final.indexOf(gdjs.GameplayCode.GDObstacle_9511Objects3[j]) === -1 )
            gdjs.GameplayCode.GDObstacle_9511Objects2_1final.push(gdjs.GameplayCode.GDObstacle_9511Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle_3"), gdjs.GameplayCode.GDObstacle_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_95953Objects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDObstacle_953Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDObstacle_953Objects2_1final.indexOf(gdjs.GameplayCode.GDObstacle_953Objects3[j]) === -1 )
            gdjs.GameplayCode.GDObstacle_953Objects2_1final.push(gdjs.GameplayCode.GDObstacle_953Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDObstacle_9511Objects2_1final, gdjs.GameplayCode.GDObstacle_9511Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDObstacle_9512Objects2_1final, gdjs.GameplayCode.GDObstacle_9512Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDObstacle_953Objects2_1final, gdjs.GameplayCode.GDObstacle_953Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final, gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10961372);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "144113__avakas__man-hit-by-car-[AudioTrimmer.com].wav", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectOpacityTween("PlayerOpacity", 0, "linear", 500, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
gdjs.GameplayCode.GDStage4Objects2.length = 0;

gdjs.GameplayCode.GDStage6Objects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition2IsTrue_1;
gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final.length = 0;gdjs.GameplayCode.GDStage4Objects2_2final.length = 0;gdjs.GameplayCode.GDStage6Objects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2, gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.copyArray(runtimeScene.getObjects("Stage4"), gdjs.GameplayCode.GDStage4Objects3);
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage4Objects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage4Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage4Objects2_2final.indexOf(gdjs.GameplayCode.GDStage4Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage4Objects2_2final.push(gdjs.GameplayCode.GDStage4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2, gdjs.GameplayCode.GDPlayer_95HitboxObjects3);

gdjs.copyArray(runtimeScene.getObjects("Stage6"), gdjs.GameplayCode.GDStage6Objects3);
gdjs.GameplayCode.condition1IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage6Objects3Objects, false, runtimeScene, false);
if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage6Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage6Objects2_2final.indexOf(gdjs.GameplayCode.GDStage6Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage6Objects2_2final.push(gdjs.GameplayCode.GDStage6Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2_2final, gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
gdjs.copyArray(gdjs.GameplayCode.GDStage4Objects2_2final, gdjs.GameplayCode.GDStage4Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDStage6Objects2_2final, gdjs.GameplayCode.GDStage6Objects2);
}
}
}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10963452);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "110393__soundscalpel-com__water-splash.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectOpacityTween("PlayerOpacity", 0, "linear", 500, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects1[i].getOpacity() <= 0 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects1[k] = gdjs.GameplayCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects1.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10966164);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.GameplayCode.eventsList5 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10891436);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.GameplayCode.GDControlSwipeObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimation(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDControlSwipeObjects2Objects, 0, 0, "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ControlSwipe"), gdjs.GameplayCode.GDControlSwipeObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDControlSwipeObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDControlSwipeObjects2[i].getBehavior("Swipe").IsDone((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDControlSwipeObjects2[k] = gdjs.GameplayCode.GDControlSwipeObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDControlSwipeObjects2.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDControlSwipeObjects2 */
gdjs.copyArray(runtimeScene.getObjects("SwipeDirection"), gdjs.GameplayCode.GDSwipeDirectionObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDSwipeDirectionObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeDirectionObjects2[i].setString((( gdjs.GameplayCode.GDControlSwipeObjects2.length === 0 ) ? "" :gdjs.GameplayCode.GDControlSwipeObjects2[0].getBehavior("Swipe").Average4Direction((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setPosition((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 10,(( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) - 5);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_w"), gdjs.GameplayCode.GDObstacleChecker_95wObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95wObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95wObjects2[i].setPosition((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 25,(( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) - 75);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_a"), gdjs.GameplayCode.GDObstacleChecker_95aObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95aObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95aObjects2[i].setPosition((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) - 75,(( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) + 25);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_s"), gdjs.GameplayCode.GDObstacleChecker_95sObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95sObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95sObjects2[i].setPosition((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 25,(( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) + 125);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_d"), gdjs.GameplayCode.GDObstacleChecker_95dObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDObstacleChecker_95dObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacleChecker_95dObjects2[i].setPosition((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 125,(( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) + 25);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_w"), gdjs.GameplayCode.GDObstacleChecker_95wObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_41"), gdjs.GameplayCode.GDObstacle_9541Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_42"), gdjs.GameplayCode.GDObstacle_9542Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_43"), gdjs.GameplayCode.GDObstacle_9543Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_44"), gdjs.GameplayCode.GDObstacle_9544Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.GameplayCode.GDSwipeDirectionObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
gdjs.GameplayCode.condition7IsTrue_1.val = false;
gdjs.GameplayCode.condition8IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "s"));
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
gdjs.GameplayCode.condition5IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
gdjs.GameplayCode.condition6IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595wObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition6IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition7IsTrue_1;
gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "w");
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SwipeDirection"), gdjs.GameplayCode.GDSwipeDirectionObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDSwipeDirectionObjects3[i].getString() == "UP" ) {
        gdjs.GameplayCode.condition1IsTrue_2.val = true;
        gdjs.GameplayCode.GDSwipeDirectionObjects3[k] = gdjs.GameplayCode.GDSwipeDirectionObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDSwipeDirectionObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.indexOf(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]) === -1 )
            gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.push(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDSwipeDirectionObjects2_2final, gdjs.GameplayCode.GDSwipeDirectionObjects2);
}
}
}if ( gdjs.GameplayCode.condition7IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition8IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
}
}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val && gdjs.GameplayCode.condition7IsTrue_1.val && gdjs.GameplayCode.condition8IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10913324);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DeathTrigger"), gdjs.GameplayCode.GDDeathTriggerObjects2);
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
/* Reuse gdjs.GameplayCode.GDSwipeDirectionObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Jump Back");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getBehavior("Tween").addObjectPositionYTween("Move_Up", (gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getPointY("")) - 100, "linear", 300, false);
}
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - (50), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "Player", 0) - (50), "Player", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "Obstacle", 0) - (50), "Obstacle", 0);
}{for(var i = 0, len = gdjs.GameplayCode.GDDeathTriggerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDDeathTriggerObjects2[i].setY(gdjs.GameplayCode.GDDeathTriggerObjects2[i].getY() - (50));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "187024__lloydevans09__jump2.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDSwipeDirectionObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeDirectionObjects2[i].setString("0");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_s"), gdjs.GameplayCode.GDObstacleChecker_95sObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_41"), gdjs.GameplayCode.GDObstacle_9541Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_42"), gdjs.GameplayCode.GDObstacle_9542Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_43"), gdjs.GameplayCode.GDObstacle_9543Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_44"), gdjs.GameplayCode.GDObstacle_9544Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.GameplayCode.GDSwipeDirectionObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
gdjs.GameplayCode.condition7IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
gdjs.GameplayCode.condition4IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595sObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition5IsTrue_1;
gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SwipeDirection"), gdjs.GameplayCode.GDSwipeDirectionObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDSwipeDirectionObjects3[i].getString() == "DOWN" ) {
        gdjs.GameplayCode.condition1IsTrue_2.val = true;
        gdjs.GameplayCode.GDSwipeDirectionObjects3[k] = gdjs.GameplayCode.GDSwipeDirectionObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDSwipeDirectionObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.indexOf(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]) === -1 )
            gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.push(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDSwipeDirectionObjects2_2final, gdjs.GameplayCode.GDSwipeDirectionObjects2);
}
}
}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
gdjs.GameplayCode.condition6IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition6IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition7IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val && gdjs.GameplayCode.condition7IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10920396);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
/* Reuse gdjs.GameplayCode.GDSwipeDirectionObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Jump Front");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getBehavior("Tween").addObjectPositionYTween("Move_Down", (gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getPointY("")) + 100, "linear", 300, false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "187024__lloydevans09__jump2.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDSwipeDirectionObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeDirectionObjects2[i].setString("0");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_a"), gdjs.GameplayCode.GDObstacleChecker_95aObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_41"), gdjs.GameplayCode.GDObstacle_9541Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_42"), gdjs.GameplayCode.GDObstacle_9542Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_43"), gdjs.GameplayCode.GDObstacle_9543Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_44"), gdjs.GameplayCode.GDObstacle_9544Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
gdjs.GameplayCode.GDSwipeDirectionObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getX() >= 100 ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects2[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595aObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition4IsTrue_1;
gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SwipeDirection"), gdjs.GameplayCode.GDSwipeDirectionObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDSwipeDirectionObjects3[i].getString() == "LEFT" ) {
        gdjs.GameplayCode.condition1IsTrue_2.val = true;
        gdjs.GameplayCode.GDSwipeDirectionObjects3[k] = gdjs.GameplayCode.GDSwipeDirectionObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDSwipeDirectionObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.indexOf(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]) === -1 )
            gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.push(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDSwipeDirectionObjects2_2final, gdjs.GameplayCode.GDSwipeDirectionObjects2);
}
}
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
gdjs.GameplayCode.condition5IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10923508);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
/* Reuse gdjs.GameplayCode.GDSwipeDirectionObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Jump Side Left");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getBehavior("Tween").addObjectPositionXTween("Move_Left", (gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getPointX("")) - 100, "linear", 300, false);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "Obstacle", 0) - (100), "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "Player", 0) - (100), "Player", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (100), "", 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "187024__lloydevans09__jump2.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDSwipeDirectionObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeDirectionObjects2[i].setString("0");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ObstacleChecker_d"), gdjs.GameplayCode.GDObstacleChecker_95dObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_41"), gdjs.GameplayCode.GDObstacle_9541Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_42"), gdjs.GameplayCode.GDObstacle_9542Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_43"), gdjs.GameplayCode.GDObstacle_9543Objects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle_44"), gdjs.GameplayCode.GDObstacle_9544Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
gdjs.GameplayCode.GDSwipeDirectionObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
gdjs.GameplayCode.condition3IsTrue_1.val = false;
gdjs.GameplayCode.condition4IsTrue_1.val = false;
gdjs.GameplayCode.condition5IsTrue_1.val = false;
gdjs.GameplayCode.condition6IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959541Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959542Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959544Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition2IsTrue_1.val ) {
{
gdjs.GameplayCode.condition3IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacleChecker_9595dObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959543Objects2Objects, true, runtimeScene, false);
}if ( gdjs.GameplayCode.condition3IsTrue_1.val ) {
{
{gdjs.GameplayCode.conditionTrue_2 = gdjs.GameplayCode.condition4IsTrue_1;
gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.length = 0;gdjs.GameplayCode.condition0IsTrue_2.val = false;
gdjs.GameplayCode.condition1IsTrue_2.val = false;
{
gdjs.GameplayCode.condition0IsTrue_2.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if( gdjs.GameplayCode.condition0IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SwipeDirection"), gdjs.GameplayCode.GDSwipeDirectionObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDSwipeDirectionObjects3[i].getString() == "RIGHT" ) {
        gdjs.GameplayCode.condition1IsTrue_2.val = true;
        gdjs.GameplayCode.GDSwipeDirectionObjects3[k] = gdjs.GameplayCode.GDSwipeDirectionObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDSwipeDirectionObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_2.val ) {
    gdjs.GameplayCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDSwipeDirectionObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.indexOf(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]) === -1 )
            gdjs.GameplayCode.GDSwipeDirectionObjects2_2final.push(gdjs.GameplayCode.GDSwipeDirectionObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDSwipeDirectionObjects2_2final, gdjs.GameplayCode.GDSwipeDirectionObjects2);
}
}
}if ( gdjs.GameplayCode.condition4IsTrue_1.val ) {
{
gdjs.GameplayCode.condition5IsTrue_1.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.GameplayCode.condition5IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].getVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameplayCode.condition6IsTrue_1.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
}
}
}
}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val && gdjs.GameplayCode.condition3IsTrue_1.val && gdjs.GameplayCode.condition4IsTrue_1.val && gdjs.GameplayCode.condition5IsTrue_1.val && gdjs.GameplayCode.condition6IsTrue_1.val;
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getX() <= 300 ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayer_95HitboxObjects2[k] = gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10931316);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
/* Reuse gdjs.GameplayCode.GDSwipeDirectionObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Jump Side Right");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getBehavior("Tween").addObjectPositionXTween("Move_Right", (gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].getPointX("")) + 100, "linear", 300, false);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "Obstacle", 0) + (100), "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "Player", 0) + (100), "Player", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (100), "", 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "187024__lloydevans09__jump2.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.GameplayCode.GDSwipeDirectionObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDSwipeDirectionObjects2[i].setString("0");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Front") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Idle Front");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Back") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Idle Back");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Side Left") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Idle Side Left");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Side Right") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setAnimationName("Idle Side Right");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Front") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded()) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Back") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded()) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Side Left") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded()) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameplayCode.GDPlayerObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDPlayerObjects2[i].isCurrentAnimationName("Jump Side Right") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDPlayerObjects2[i].hasAnimationEnded()) ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDPlayerObjects2[k] = gdjs.GameplayCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDPlayerObjects2.length = k;}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.GameplayCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].addForce(100, 0, 0);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Player", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPlayer_95HitboxObjects2[i].addForce(-(100), 0, 0);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Player", 0);
}}

}


{

gdjs.GameplayCode.GDObstacle_9521Objects2.length = 0;

gdjs.GameplayCode.GDObstacle_9522Objects2.length = 0;

gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDObstacle_9521Objects2_1final.length = 0;gdjs.GameplayCode.GDObstacle_9522Objects2_1final.length = 0;gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle_21"), gdjs.GameplayCode.GDObstacle_9521Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects3Objects, true, runtimeScene, false);
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDObstacle_9521Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDObstacle_9521Objects2_1final.indexOf(gdjs.GameplayCode.GDObstacle_9521Objects3[j]) === -1 )
            gdjs.GameplayCode.GDObstacle_9521Objects2_1final.push(gdjs.GameplayCode.GDObstacle_9521Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle_22"), gdjs.GameplayCode.GDObstacle_9522Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects3);
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPlayer_9595HitboxObjects3Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects3Objects, true, runtimeScene, false);
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDObstacle_9522Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDObstacle_9522Objects2_1final.indexOf(gdjs.GameplayCode.GDObstacle_9522Objects3[j]) === -1 )
            gdjs.GameplayCode.GDObstacle_9522Objects2_1final.push(gdjs.GameplayCode.GDObstacle_9522Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.indexOf(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]) === -1 )
            gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final.push(gdjs.GameplayCode.GDPlayer_95HitboxObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDObstacle_9521Objects2_1final, gdjs.GameplayCode.GDObstacle_9521Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDObstacle_9522Objects2_1final, gdjs.GameplayCode.GDObstacle_9522Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDPlayer_95HitboxObjects2_1final, gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDPlayer_95HitboxObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Obstacle", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 50, "Player", 0);
}}

}


{


gdjs.GameplayCode.eventsList3(runtimeScene);
}


{


gdjs.GameplayCode.eventsList4(runtimeScene);
}


};gdjs.GameplayCode.eventsList6 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.eventsList5(runtimeScene);
}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage1Objects2Objects = Hashtable.newFrom({"Stage1": gdjs.GameplayCode.GDStage1Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_95953Objects2Objects = Hashtable.newFrom({"Obstacle_3": gdjs.GameplayCode.GDObstacle_953Objects2});
gdjs.GameplayCode.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDStage1Objects2 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDStage1Objects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDStage1Objects2, gdjs.GameplayCode.GDStage1Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage1Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage1Objects3[i].getVariableNumber(gdjs.GameplayCode.GDStage1Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage1Objects3[k] = gdjs.GameplayCode.GDStage1Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage1Objects3.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage1Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage1Objects2_1final.indexOf(gdjs.GameplayCode.GDStage1Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage1Objects2_1final.push(gdjs.GameplayCode.GDStage1Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage1Objects2, gdjs.GameplayCode.GDStage1Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage1Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage1Objects3[i].getTimerElapsedTimeInSecondsOrNaN("ObstacleDelay") > (gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDStage1Objects3[i].getVariables().getFromIndex(0))) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage1Objects3[k] = gdjs.GameplayCode.GDStage1Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage1Objects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage1Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage1Objects2_1final.indexOf(gdjs.GameplayCode.GDStage1Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage1Objects2_1final.push(gdjs.GameplayCode.GDStage1Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage1Objects2_1final, gdjs.GameplayCode.GDStage1Objects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDStage1Objects2 */
gdjs.GameplayCode.GDObstacle_953Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_95953Objects2Objects, 1000, (( gdjs.GameplayCode.GDStage1Objects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDStage1Objects2[0].getPointY("")) - 10, "Obstacle");
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacle_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacle_953Objects2[i].addForce(-(1000), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage1Objects2[i].resetTimer("ObstacleDelay");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage1Objects2[i].returnVariable(gdjs.GameplayCode.GDStage1Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(4, 6));
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage2Objects2Objects = Hashtable.newFrom({"Stage2": gdjs.GameplayCode.GDStage2Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959512Objects2Objects = Hashtable.newFrom({"Obstacle_12": gdjs.GameplayCode.GDObstacle_9512Objects2});
gdjs.GameplayCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDStage2Objects2 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDStage2Objects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDStage2Objects2, gdjs.GameplayCode.GDStage2Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage2Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage2Objects3[i].getVariableNumber(gdjs.GameplayCode.GDStage2Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage2Objects3[k] = gdjs.GameplayCode.GDStage2Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage2Objects3.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage2Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage2Objects2_1final.indexOf(gdjs.GameplayCode.GDStage2Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage2Objects2_1final.push(gdjs.GameplayCode.GDStage2Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage2Objects2, gdjs.GameplayCode.GDStage2Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage2Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage2Objects3[i].getTimerElapsedTimeInSecondsOrNaN("ObstacleDelay") > (gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDStage2Objects3[i].getVariables().getFromIndex(0))) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage2Objects3[k] = gdjs.GameplayCode.GDStage2Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage2Objects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage2Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage2Objects2_1final.indexOf(gdjs.GameplayCode.GDStage2Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage2Objects2_1final.push(gdjs.GameplayCode.GDStage2Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage2Objects2_1final, gdjs.GameplayCode.GDStage2Objects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDStage2Objects2 */
gdjs.GameplayCode.GDObstacle_9512Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959512Objects2Objects, 1000, (( gdjs.GameplayCode.GDStage2Objects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDStage2Objects2[0].getPointY("")), "Obstacle");
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacle_9512Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacle_9512Objects2[i].addForce(-(200), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage2Objects2[i].resetTimer("ObstacleDelay");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage2Objects2[i].returnVariable(gdjs.GameplayCode.GDStage2Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(3, 5));
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage3Objects2Objects = Hashtable.newFrom({"Stage3": gdjs.GameplayCode.GDStage3Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959511Objects2Objects = Hashtable.newFrom({"Obstacle_11": gdjs.GameplayCode.GDObstacle_9511Objects2});
gdjs.GameplayCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDStage3Objects2 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDStage3Objects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDStage3Objects2, gdjs.GameplayCode.GDStage3Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage3Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage3Objects3[i].getVariableNumber(gdjs.GameplayCode.GDStage3Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage3Objects3[k] = gdjs.GameplayCode.GDStage3Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage3Objects3.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage3Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage3Objects2_1final.indexOf(gdjs.GameplayCode.GDStage3Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage3Objects2_1final.push(gdjs.GameplayCode.GDStage3Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage3Objects2, gdjs.GameplayCode.GDStage3Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage3Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage3Objects3[i].getTimerElapsedTimeInSecondsOrNaN("ObstacleDelay") > (gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDStage3Objects3[i].getVariables().getFromIndex(0))) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage3Objects3[k] = gdjs.GameplayCode.GDStage3Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage3Objects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage3Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage3Objects2_1final.indexOf(gdjs.GameplayCode.GDStage3Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage3Objects2_1final.push(gdjs.GameplayCode.GDStage3Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage3Objects2_1final, gdjs.GameplayCode.GDStage3Objects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDStage3Objects2 */
gdjs.GameplayCode.GDObstacle_9511Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959511Objects2Objects, -(500), (( gdjs.GameplayCode.GDStage3Objects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDStage3Objects2[0].getPointY("")), "Obstacle");
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacle_9511Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacle_9511Objects2[i].addForce(200, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage3Objects2[i].resetTimer("ObstacleDelay");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage3Objects2[i].returnVariable(gdjs.GameplayCode.GDStage3Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(3, 5));
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage4Objects2Objects = Hashtable.newFrom({"Stage4": gdjs.GameplayCode.GDStage4Objects2});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects = Hashtable.newFrom({"Obstacle_21": gdjs.GameplayCode.GDObstacle_9521Objects2});
gdjs.GameplayCode.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDStage4Objects2 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDStage4Objects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDStage4Objects2, gdjs.GameplayCode.GDStage4Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage4Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage4Objects3[i].getVariableNumber(gdjs.GameplayCode.GDStage4Objects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage4Objects3[k] = gdjs.GameplayCode.GDStage4Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage4Objects3.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage4Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage4Objects2_1final.indexOf(gdjs.GameplayCode.GDStage4Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage4Objects2_1final.push(gdjs.GameplayCode.GDStage4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage4Objects2, gdjs.GameplayCode.GDStage4Objects3);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage4Objects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage4Objects3[i].getTimerElapsedTimeInSecondsOrNaN("ObstacleDelay") > (gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDStage4Objects3[i].getVariables().getFromIndex(0))) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage4Objects3[k] = gdjs.GameplayCode.GDStage4Objects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage4Objects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage4Objects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage4Objects2_1final.indexOf(gdjs.GameplayCode.GDStage4Objects3[j]) === -1 )
            gdjs.GameplayCode.GDStage4Objects2_1final.push(gdjs.GameplayCode.GDStage4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage4Objects2_1final, gdjs.GameplayCode.GDStage4Objects2);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDStage4Objects2 */
gdjs.GameplayCode.GDObstacle_9521Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959521Objects2Objects, -(500), (( gdjs.GameplayCode.GDStage4Objects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDStage4Objects2[0].getPointY("")), "Obstacle");
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacle_9521Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacle_9521Objects2[i].addForce(100, 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage4Objects2[i].resetTimer("ObstacleDelay");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage4Objects2[i].returnVariable(gdjs.GameplayCode.GDStage4Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(3, 5));
}
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects1Objects = Hashtable.newFrom({"Checker": gdjs.GameplayCode.GDCheckerObjects1});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage6Objects1Objects = Hashtable.newFrom({"Stage6": gdjs.GameplayCode.GDStage6Objects1});
gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects1Objects = Hashtable.newFrom({"Obstacle_22": gdjs.GameplayCode.GDObstacle_9522Objects1});
gdjs.GameplayCode.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.GameplayCode.GDStage6Objects1 */

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDStage6Objects1_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameplayCode.GDStage6Objects1, gdjs.GameplayCode.GDStage6Objects2);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage6Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage6Objects2[i].getVariableNumber(gdjs.GameplayCode.GDStage6Objects2[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.GameplayCode.condition0IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage6Objects2[k] = gdjs.GameplayCode.GDStage6Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage6Objects2.length = k;if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage6Objects2.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage6Objects1_1final.indexOf(gdjs.GameplayCode.GDStage6Objects2[j]) === -1 )
            gdjs.GameplayCode.GDStage6Objects1_1final.push(gdjs.GameplayCode.GDStage6Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage6Objects1, gdjs.GameplayCode.GDStage6Objects2);

for(var i = 0, k = 0, l = gdjs.GameplayCode.GDStage6Objects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDStage6Objects2[i].getTimerElapsedTimeInSecondsOrNaN("ObstacleDelay") > (gdjs.RuntimeObject.getVariableNumber(gdjs.GameplayCode.GDStage6Objects2[i].getVariables().getFromIndex(0))) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDStage6Objects2[k] = gdjs.GameplayCode.GDStage6Objects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDStage6Objects2.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDStage6Objects2.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDStage6Objects1_1final.indexOf(gdjs.GameplayCode.GDStage6Objects2[j]) === -1 )
            gdjs.GameplayCode.GDStage6Objects1_1final.push(gdjs.GameplayCode.GDStage6Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDStage6Objects1_1final, gdjs.GameplayCode.GDStage6Objects1);
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDStage6Objects1 */
gdjs.GameplayCode.GDObstacle_9522Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDObstacle_959522Objects1Objects, 1000, (( gdjs.GameplayCode.GDStage6Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDStage6Objects1[0].getPointY("")), "Obstacle");
}{for(var i = 0, len = gdjs.GameplayCode.GDObstacle_9522Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDObstacle_9522Objects1[i].addForce(-(100), 0, 1);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage6Objects1[i].resetTimer("ObstacleDelay");
}
}{for(var i = 0, len = gdjs.GameplayCode.GDStage6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDStage6Objects1[i].returnVariable(gdjs.GameplayCode.GDStage6Objects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(4, 6));
}
}}

}


};gdjs.GameplayCode.eventsList12 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10776564);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, 200);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10777284);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, 100);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10778004);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, 0);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10778804);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(100));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10779476);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(200));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10780188);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(300));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10780860);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(400));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10781436);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(500));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10781764);
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(600));
}}

}


{



}


{

gdjs.GameplayCode.GDControlSwipeObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDControlSwipeObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "w");
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ControlSwipe"), gdjs.GameplayCode.GDControlSwipeObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDControlSwipeObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDControlSwipeObjects3[i].getBehavior("Swipe").IsDone((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDControlSwipeObjects3[k] = gdjs.GameplayCode.GDControlSwipeObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDControlSwipeObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDControlSwipeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDControlSwipeObjects2_1final.indexOf(gdjs.GameplayCode.GDControlSwipeObjects3[j]) === -1 )
            gdjs.GameplayCode.GDControlSwipeObjects2_1final.push(gdjs.GameplayCode.GDControlSwipeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDControlSwipeObjects2_1final, gdjs.GameplayCode.GDControlSwipeObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10783796);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Stage" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 8)), 0, -(600) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(100);
}}

}


{



}


{

gdjs.GameplayCode.GDControlSwipeObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDControlSwipeObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "w");
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ControlSwipe"), gdjs.GameplayCode.GDControlSwipeObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDControlSwipeObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDControlSwipeObjects3[i].getBehavior("Swipe").IsDone((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDControlSwipeObjects3[k] = gdjs.GameplayCode.GDControlSwipeObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDControlSwipeObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDControlSwipeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDControlSwipeObjects2_1final.indexOf(gdjs.GameplayCode.GDControlSwipeObjects3[j]) === -1 )
            gdjs.GameplayCode.GDControlSwipeObjects2_1final.push(gdjs.GameplayCode.GDControlSwipeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDControlSwipeObjects2_1final, gdjs.GameplayCode.GDControlSwipeObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10785196);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
gdjs.GameplayCode.GDCheckerObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointX("")) + 25, (( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) - 1075, "Player");
}{for(var i = 0, len = gdjs.GameplayCode.GDCheckerObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDCheckerObjects2[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Stage1"), gdjs.GameplayCode.GDStage1Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage1Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Stage2"), gdjs.GameplayCode.GDStage2Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage2Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Stage3"), gdjs.GameplayCode.GDStage3Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage3Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Stage4"), gdjs.GameplayCode.GDStage4Objects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects2Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage4Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checker"), gdjs.GameplayCode.GDCheckerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stage6"), gdjs.GameplayCode.GDStage6Objects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDCheckerObjects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStage6Objects1Objects, false, runtimeScene, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList13 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList12(runtimeScene);
}


};gdjs.GameplayCode.eventsList14 = function(runtimeScene) {

{

gdjs.GameplayCode.GDTitleObjects2.length = 0;


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.GDTitleObjects2_1final.length = 0;gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTitleObjects3.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDTitleObjects3[i].getBehavior("Tween").exists("Animasi2")) ) {
        gdjs.GameplayCode.condition1IsTrue_1.val = true;
        gdjs.GameplayCode.GDTitleObjects3[k] = gdjs.GameplayCode.GDTitleObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTitleObjects3.length = k;if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDTitleObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDTitleObjects2_1final.indexOf(gdjs.GameplayCode.GDTitleObjects3[j]) === -1 )
            gdjs.GameplayCode.GDTitleObjects2_1final.push(gdjs.GameplayCode.GDTitleObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects3);
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTitleObjects3.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTitleObjects3[i].getBehavior("Tween").hasFinished("Animasi2") ) {
        gdjs.GameplayCode.condition2IsTrue_1.val = true;
        gdjs.GameplayCode.GDTitleObjects3[k] = gdjs.GameplayCode.GDTitleObjects3[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTitleObjects3.length = k;if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameplayCode.GDTitleObjects3.length;j<jLen;++j) {
        if ( gdjs.GameplayCode.GDTitleObjects2_1final.indexOf(gdjs.GameplayCode.GDTitleObjects3[j]) === -1 )
            gdjs.GameplayCode.GDTitleObjects2_1final.push(gdjs.GameplayCode.GDTitleObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameplayCode.GDTitleObjects2_1final, gdjs.GameplayCode.GDTitleObjects2);
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10799044);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTitleObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects2[i].getBehavior("Tween").addObjectScaleTween("Animasi1", 0.43, 0.43, "linear", 650, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.GameplayCode.GDTitleObjects2);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDTitleObjects2.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDTitleObjects2[i].getBehavior("Tween").hasFinished("Animasi1") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDTitleObjects2[k] = gdjs.GameplayCode.GDTitleObjects2[i];
        ++k;
    }
}
gdjs.GameplayCode.GDTitleObjects2.length = k;}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10800484);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDTitleObjects2 */
{for(var i = 0, len = gdjs.GameplayCode.GDTitleObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTitleObjects2[i].getBehavior("Tween").addObjectScaleTween("Animasi2", 0.39, 0.39, "linear", 650, false, true);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player_Hitbox"), gdjs.GameplayCode.GDPlayer_95HitboxObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(Math.floor(((( gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length === 0 ) ? 0 :gdjs.GameplayCode.GDPlayer_95HitboxObjects2[0].getPointY("")) - 600) / -(100)));
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}
}}

}


};gdjs.GameplayCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_CarHorn");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_CarPass");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_TrainHorn");
}{gdjs.evtTools.sound.playSound(runtimeScene, "Car Passing- Sound Effect.mp3", false, gdjs.randomInRange(10, 25), 1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Sound_CarHorn") > gdjs.randomInRange(10, 15);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Car horn sound effect (Copyright Free).mp3", false, gdjs.randomInRange(10, 25), 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_CarHorn");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Sound_CarPass") > gdjs.randomInRange(10, 15);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Car Passing- Sound Effect.mp3", false, gdjs.randomInRange(10, 25), 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_CarPass");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Sound_TrainHorn") > gdjs.randomInRange(10, 20);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Train Horn - Sound Effect (HD).mp3", false, gdjs.randomInRange(10, 25), 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Sound_TrainHorn");
}}

}


};gdjs.GameplayCode.eventsList16 = function(runtimeScene) {

{


gdjs.GameplayCode.eventsList1(runtimeScene);
}


{


gdjs.GameplayCode.eventsList2(runtimeScene);
}


{


gdjs.GameplayCode.eventsList6(runtimeScene);
}


{


gdjs.GameplayCode.eventsList13(runtimeScene);
}


{


gdjs.GameplayCode.eventsList14(runtimeScene);
}


{


gdjs.GameplayCode.eventsList15(runtimeScene);
}


};

gdjs.GameplayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameplayCode.GDTitleObjects1.length = 0;
gdjs.GameplayCode.GDTitleObjects2.length = 0;
gdjs.GameplayCode.GDTitleObjects3.length = 0;
gdjs.GameplayCode.GDTitleObjects4.length = 0;
gdjs.GameplayCode.GDBGObjects1.length = 0;
gdjs.GameplayCode.GDBGObjects2.length = 0;
gdjs.GameplayCode.GDBGObjects3.length = 0;
gdjs.GameplayCode.GDBGObjects4.length = 0;
gdjs.GameplayCode.GDPlayer_95HitboxObjects1.length = 0;
gdjs.GameplayCode.GDPlayer_95HitboxObjects2.length = 0;
gdjs.GameplayCode.GDPlayer_95HitboxObjects3.length = 0;
gdjs.GameplayCode.GDPlayer_95HitboxObjects4.length = 0;
gdjs.GameplayCode.GDTween_95CurtainObjects1.length = 0;
gdjs.GameplayCode.GDTween_95CurtainObjects2.length = 0;
gdjs.GameplayCode.GDTween_95CurtainObjects3.length = 0;
gdjs.GameplayCode.GDTween_95CurtainObjects4.length = 0;
gdjs.GameplayCode.GDPlayerObjects1.length = 0;
gdjs.GameplayCode.GDPlayerObjects2.length = 0;
gdjs.GameplayCode.GDPlayerObjects3.length = 0;
gdjs.GameplayCode.GDPlayerObjects4.length = 0;
gdjs.GameplayCode.GDStage1Objects1.length = 0;
gdjs.GameplayCode.GDStage1Objects2.length = 0;
gdjs.GameplayCode.GDStage1Objects3.length = 0;
gdjs.GameplayCode.GDStage1Objects4.length = 0;
gdjs.GameplayCode.GDStage2Objects1.length = 0;
gdjs.GameplayCode.GDStage2Objects2.length = 0;
gdjs.GameplayCode.GDStage2Objects3.length = 0;
gdjs.GameplayCode.GDStage2Objects4.length = 0;
gdjs.GameplayCode.GDStage3Objects1.length = 0;
gdjs.GameplayCode.GDStage3Objects2.length = 0;
gdjs.GameplayCode.GDStage3Objects3.length = 0;
gdjs.GameplayCode.GDStage3Objects4.length = 0;
gdjs.GameplayCode.GDStage4Objects1.length = 0;
gdjs.GameplayCode.GDStage4Objects2.length = 0;
gdjs.GameplayCode.GDStage4Objects3.length = 0;
gdjs.GameplayCode.GDStage4Objects4.length = 0;
gdjs.GameplayCode.GDStage5Objects1.length = 0;
gdjs.GameplayCode.GDStage5Objects2.length = 0;
gdjs.GameplayCode.GDStage5Objects3.length = 0;
gdjs.GameplayCode.GDStage5Objects4.length = 0;
gdjs.GameplayCode.GDStage6Objects1.length = 0;
gdjs.GameplayCode.GDStage6Objects2.length = 0;
gdjs.GameplayCode.GDStage6Objects3.length = 0;
gdjs.GameplayCode.GDStage6Objects4.length = 0;
gdjs.GameplayCode.GDCheckerObjects1.length = 0;
gdjs.GameplayCode.GDCheckerObjects2.length = 0;
gdjs.GameplayCode.GDCheckerObjects3.length = 0;
gdjs.GameplayCode.GDCheckerObjects4.length = 0;
gdjs.GameplayCode.GDObstacle_9511Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9511Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9511Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9511Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9512Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9512Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9512Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9512Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9521Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9521Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9521Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9521Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9522Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9522Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9522Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9522Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_953Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_953Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_953Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_953Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9544Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9544Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9544Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9544Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9543Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9543Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9543Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9543Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9542Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9542Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9542Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9542Objects4.length = 0;
gdjs.GameplayCode.GDObstacle_9541Objects1.length = 0;
gdjs.GameplayCode.GDObstacle_9541Objects2.length = 0;
gdjs.GameplayCode.GDObstacle_9541Objects3.length = 0;
gdjs.GameplayCode.GDObstacle_9541Objects4.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95wObjects1.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95wObjects2.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95wObjects3.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95wObjects4.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95aObjects1.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95aObjects2.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95aObjects3.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95aObjects4.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95sObjects1.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95sObjects2.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95sObjects3.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95sObjects4.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95dObjects1.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95dObjects2.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95dObjects3.length = 0;
gdjs.GameplayCode.GDObstacleChecker_95dObjects4.length = 0;
gdjs.GameplayCode.GDScoreObjects1.length = 0;
gdjs.GameplayCode.GDScoreObjects2.length = 0;
gdjs.GameplayCode.GDScoreObjects3.length = 0;
gdjs.GameplayCode.GDScoreObjects4.length = 0;
gdjs.GameplayCode.GDTrainCheckerObjects1.length = 0;
gdjs.GameplayCode.GDTrainCheckerObjects2.length = 0;
gdjs.GameplayCode.GDTrainCheckerObjects3.length = 0;
gdjs.GameplayCode.GDTrainCheckerObjects4.length = 0;
gdjs.GameplayCode.GDLightObjects1.length = 0;
gdjs.GameplayCode.GDLightObjects2.length = 0;
gdjs.GameplayCode.GDLightObjects3.length = 0;
gdjs.GameplayCode.GDLightObjects4.length = 0;
gdjs.GameplayCode.GDTapLogoObjects1.length = 0;
gdjs.GameplayCode.GDTapLogoObjects2.length = 0;
gdjs.GameplayCode.GDTapLogoObjects3.length = 0;
gdjs.GameplayCode.GDTapLogoObjects4.length = 0;
gdjs.GameplayCode.GDSwipeToStartObjects1.length = 0;
gdjs.GameplayCode.GDSwipeToStartObjects2.length = 0;
gdjs.GameplayCode.GDSwipeToStartObjects3.length = 0;
gdjs.GameplayCode.GDSwipeToStartObjects4.length = 0;
gdjs.GameplayCode.GDNewBBTextObjects1.length = 0;
gdjs.GameplayCode.GDNewBBTextObjects2.length = 0;
gdjs.GameplayCode.GDNewBBTextObjects3.length = 0;
gdjs.GameplayCode.GDNewBBTextObjects4.length = 0;
gdjs.GameplayCode.GDDeathTriggerObjects1.length = 0;
gdjs.GameplayCode.GDDeathTriggerObjects2.length = 0;
gdjs.GameplayCode.GDDeathTriggerObjects3.length = 0;
gdjs.GameplayCode.GDDeathTriggerObjects4.length = 0;
gdjs.GameplayCode.GDMove_95ForwardObjects1.length = 0;
gdjs.GameplayCode.GDMove_95ForwardObjects2.length = 0;
gdjs.GameplayCode.GDMove_95ForwardObjects3.length = 0;
gdjs.GameplayCode.GDMove_95ForwardObjects4.length = 0;
gdjs.GameplayCode.GDMove_95LeftObjects1.length = 0;
gdjs.GameplayCode.GDMove_95LeftObjects2.length = 0;
gdjs.GameplayCode.GDMove_95LeftObjects3.length = 0;
gdjs.GameplayCode.GDMove_95LeftObjects4.length = 0;
gdjs.GameplayCode.GDMove_95RightObjects1.length = 0;
gdjs.GameplayCode.GDMove_95RightObjects2.length = 0;
gdjs.GameplayCode.GDMove_95RightObjects3.length = 0;
gdjs.GameplayCode.GDMove_95RightObjects4.length = 0;
gdjs.GameplayCode.GDMove_95BackwardObjects1.length = 0;
gdjs.GameplayCode.GDMove_95BackwardObjects2.length = 0;
gdjs.GameplayCode.GDMove_95BackwardObjects3.length = 0;
gdjs.GameplayCode.GDMove_95BackwardObjects4.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects1.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects2.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects3.length = 0;
gdjs.GameplayCode.GDTutorial_95UIObjects4.length = 0;
gdjs.GameplayCode.GDNewSprite2Objects1.length = 0;
gdjs.GameplayCode.GDNewSprite2Objects2.length = 0;
gdjs.GameplayCode.GDNewSprite2Objects3.length = 0;
gdjs.GameplayCode.GDNewSprite2Objects4.length = 0;
gdjs.GameplayCode.GDControlSwipeObjects1.length = 0;
gdjs.GameplayCode.GDControlSwipeObjects2.length = 0;
gdjs.GameplayCode.GDControlSwipeObjects3.length = 0;
gdjs.GameplayCode.GDControlSwipeObjects4.length = 0;
gdjs.GameplayCode.GDSwipeDirectionObjects1.length = 0;
gdjs.GameplayCode.GDSwipeDirectionObjects2.length = 0;
gdjs.GameplayCode.GDSwipeDirectionObjects3.length = 0;
gdjs.GameplayCode.GDSwipeDirectionObjects4.length = 0;
gdjs.GameplayCode.GDCurrentURLObjects1.length = 0;
gdjs.GameplayCode.GDCurrentURLObjects2.length = 0;
gdjs.GameplayCode.GDCurrentURLObjects3.length = 0;
gdjs.GameplayCode.GDCurrentURLObjects4.length = 0;
gdjs.GameplayCode.GDGetParameterObjects1.length = 0;
gdjs.GameplayCode.GDGetParameterObjects2.length = 0;
gdjs.GameplayCode.GDGetParameterObjects3.length = 0;
gdjs.GameplayCode.GDGetParameterObjects4.length = 0;

gdjs.GameplayCode.eventsList16(runtimeScene);
return;

}

gdjs['GameplayCode'] = gdjs.GameplayCode;
