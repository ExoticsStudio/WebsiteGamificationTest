gdjs.LeaderboardCode = {};
gdjs.LeaderboardCode.GDSkor1Objects1= [];
gdjs.LeaderboardCode.GDSkor1Objects2= [];
gdjs.LeaderboardCode.GDSkor1Objects3= [];
gdjs.LeaderboardCode.GDSkor1Objects4= [];
gdjs.LeaderboardCode.GDSkor6Objects1= [];
gdjs.LeaderboardCode.GDSkor6Objects2= [];
gdjs.LeaderboardCode.GDSkor6Objects3= [];
gdjs.LeaderboardCode.GDSkor6Objects4= [];
gdjs.LeaderboardCode.GDSkor5Objects1= [];
gdjs.LeaderboardCode.GDSkor5Objects2= [];
gdjs.LeaderboardCode.GDSkor5Objects3= [];
gdjs.LeaderboardCode.GDSkor5Objects4= [];
gdjs.LeaderboardCode.GDSkor4Objects1= [];
gdjs.LeaderboardCode.GDSkor4Objects2= [];
gdjs.LeaderboardCode.GDSkor4Objects3= [];
gdjs.LeaderboardCode.GDSkor4Objects4= [];
gdjs.LeaderboardCode.GDSkor3Objects1= [];
gdjs.LeaderboardCode.GDSkor3Objects2= [];
gdjs.LeaderboardCode.GDSkor3Objects3= [];
gdjs.LeaderboardCode.GDSkor3Objects4= [];
gdjs.LeaderboardCode.GDSkor2Objects1= [];
gdjs.LeaderboardCode.GDSkor2Objects2= [];
gdjs.LeaderboardCode.GDSkor2Objects3= [];
gdjs.LeaderboardCode.GDSkor2Objects4= [];
gdjs.LeaderboardCode.GDBackGround0Objects1= [];
gdjs.LeaderboardCode.GDBackGround0Objects2= [];
gdjs.LeaderboardCode.GDBackGround0Objects3= [];
gdjs.LeaderboardCode.GDBackGround0Objects4= [];
gdjs.LeaderboardCode.GDBackGround6Objects1= [];
gdjs.LeaderboardCode.GDBackGround6Objects2= [];
gdjs.LeaderboardCode.GDBackGround6Objects3= [];
gdjs.LeaderboardCode.GDBackGround6Objects4= [];
gdjs.LeaderboardCode.GDBackGround5Objects1= [];
gdjs.LeaderboardCode.GDBackGround5Objects2= [];
gdjs.LeaderboardCode.GDBackGround5Objects3= [];
gdjs.LeaderboardCode.GDBackGround5Objects4= [];
gdjs.LeaderboardCode.GDBackGround4Objects1= [];
gdjs.LeaderboardCode.GDBackGround4Objects2= [];
gdjs.LeaderboardCode.GDBackGround4Objects3= [];
gdjs.LeaderboardCode.GDBackGround4Objects4= [];
gdjs.LeaderboardCode.GDBackGround3Objects1= [];
gdjs.LeaderboardCode.GDBackGround3Objects2= [];
gdjs.LeaderboardCode.GDBackGround3Objects3= [];
gdjs.LeaderboardCode.GDBackGround3Objects4= [];
gdjs.LeaderboardCode.GDBackGround2Objects1= [];
gdjs.LeaderboardCode.GDBackGround2Objects2= [];
gdjs.LeaderboardCode.GDBackGround2Objects3= [];
gdjs.LeaderboardCode.GDBackGround2Objects4= [];
gdjs.LeaderboardCode.GDBackGround1Objects1= [];
gdjs.LeaderboardCode.GDBackGround1Objects2= [];
gdjs.LeaderboardCode.GDBackGround1Objects3= [];
gdjs.LeaderboardCode.GDBackGround1Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock6Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock6Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock6Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock6Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock5Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock5Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock5Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock5Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock4Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock4Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock4Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock4Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock3Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock3Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock3Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock3Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock2Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock2Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock2Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock2Objects4= [];
gdjs.LeaderboardCode.GDGreenBlock1Objects1= [];
gdjs.LeaderboardCode.GDGreenBlock1Objects2= [];
gdjs.LeaderboardCode.GDGreenBlock1Objects3= [];
gdjs.LeaderboardCode.GDGreenBlock1Objects4= [];
gdjs.LeaderboardCode.GDGAME1Objects1= [];
gdjs.LeaderboardCode.GDGAME1Objects2= [];
gdjs.LeaderboardCode.GDGAME1Objects3= [];
gdjs.LeaderboardCode.GDGAME1Objects4= [];
gdjs.LeaderboardCode.GDGAME2Objects1= [];
gdjs.LeaderboardCode.GDGAME2Objects2= [];
gdjs.LeaderboardCode.GDGAME2Objects3= [];
gdjs.LeaderboardCode.GDGAME2Objects4= [];
gdjs.LeaderboardCode.GDGAME3Objects1= [];
gdjs.LeaderboardCode.GDGAME3Objects2= [];
gdjs.LeaderboardCode.GDGAME3Objects3= [];
gdjs.LeaderboardCode.GDGAME3Objects4= [];
gdjs.LeaderboardCode.GDGAME4Objects1= [];
gdjs.LeaderboardCode.GDGAME4Objects2= [];
gdjs.LeaderboardCode.GDGAME4Objects3= [];
gdjs.LeaderboardCode.GDGAME4Objects4= [];
gdjs.LeaderboardCode.GDGAME5Objects1= [];
gdjs.LeaderboardCode.GDGAME5Objects2= [];
gdjs.LeaderboardCode.GDGAME5Objects3= [];
gdjs.LeaderboardCode.GDGAME5Objects4= [];
gdjs.LeaderboardCode.GDGAME6Objects1= [];
gdjs.LeaderboardCode.GDGAME6Objects2= [];
gdjs.LeaderboardCode.GDGAME6Objects3= [];
gdjs.LeaderboardCode.GDGAME6Objects4= [];
gdjs.LeaderboardCode.GDText6Objects1= [];
gdjs.LeaderboardCode.GDText6Objects2= [];
gdjs.LeaderboardCode.GDText6Objects3= [];
gdjs.LeaderboardCode.GDText6Objects4= [];
gdjs.LeaderboardCode.GDText5Objects1= [];
gdjs.LeaderboardCode.GDText5Objects2= [];
gdjs.LeaderboardCode.GDText5Objects3= [];
gdjs.LeaderboardCode.GDText5Objects4= [];
gdjs.LeaderboardCode.GDText4Objects1= [];
gdjs.LeaderboardCode.GDText4Objects2= [];
gdjs.LeaderboardCode.GDText4Objects3= [];
gdjs.LeaderboardCode.GDText4Objects4= [];
gdjs.LeaderboardCode.GDText3Objects1= [];
gdjs.LeaderboardCode.GDText3Objects2= [];
gdjs.LeaderboardCode.GDText3Objects3= [];
gdjs.LeaderboardCode.GDText3Objects4= [];
gdjs.LeaderboardCode.GDText2Objects1= [];
gdjs.LeaderboardCode.GDText2Objects2= [];
gdjs.LeaderboardCode.GDText2Objects3= [];
gdjs.LeaderboardCode.GDText2Objects4= [];
gdjs.LeaderboardCode.GDText1Objects1= [];
gdjs.LeaderboardCode.GDText1Objects2= [];
gdjs.LeaderboardCode.GDText1Objects3= [];
gdjs.LeaderboardCode.GDText1Objects4= [];
gdjs.LeaderboardCode.GDTitle6Objects1= [];
gdjs.LeaderboardCode.GDTitle6Objects2= [];
gdjs.LeaderboardCode.GDTitle6Objects3= [];
gdjs.LeaderboardCode.GDTitle6Objects4= [];
gdjs.LeaderboardCode.GDTitle5Objects1= [];
gdjs.LeaderboardCode.GDTitle5Objects2= [];
gdjs.LeaderboardCode.GDTitle5Objects3= [];
gdjs.LeaderboardCode.GDTitle5Objects4= [];
gdjs.LeaderboardCode.GDTitle4Objects1= [];
gdjs.LeaderboardCode.GDTitle4Objects2= [];
gdjs.LeaderboardCode.GDTitle4Objects3= [];
gdjs.LeaderboardCode.GDTitle4Objects4= [];
gdjs.LeaderboardCode.GDTitle3Objects1= [];
gdjs.LeaderboardCode.GDTitle3Objects2= [];
gdjs.LeaderboardCode.GDTitle3Objects3= [];
gdjs.LeaderboardCode.GDTitle3Objects4= [];
gdjs.LeaderboardCode.GDTitle2Objects1= [];
gdjs.LeaderboardCode.GDTitle2Objects2= [];
gdjs.LeaderboardCode.GDTitle2Objects3= [];
gdjs.LeaderboardCode.GDTitle2Objects4= [];
gdjs.LeaderboardCode.GDTitle1Objects1= [];
gdjs.LeaderboardCode.GDTitle1Objects2= [];
gdjs.LeaderboardCode.GDTitle1Objects3= [];
gdjs.LeaderboardCode.GDTitle1Objects4= [];
gdjs.LeaderboardCode.GDMaskObjects1= [];
gdjs.LeaderboardCode.GDMaskObjects2= [];
gdjs.LeaderboardCode.GDMaskObjects3= [];
gdjs.LeaderboardCode.GDMaskObjects4= [];
gdjs.LeaderboardCode.GDMask2Objects1= [];
gdjs.LeaderboardCode.GDMask2Objects2= [];
gdjs.LeaderboardCode.GDMask2Objects3= [];
gdjs.LeaderboardCode.GDMask2Objects4= [];
gdjs.LeaderboardCode.GDConsoleObjects1= [];
gdjs.LeaderboardCode.GDConsoleObjects2= [];
gdjs.LeaderboardCode.GDConsoleObjects3= [];
gdjs.LeaderboardCode.GDConsoleObjects4= [];
gdjs.LeaderboardCode.GDNamaPribadiObjects1= [];
gdjs.LeaderboardCode.GDNamaPribadiObjects2= [];
gdjs.LeaderboardCode.GDNamaPribadiObjects3= [];
gdjs.LeaderboardCode.GDNamaPribadiObjects4= [];
gdjs.LeaderboardCode.GDScorePribadiObjects1= [];
gdjs.LeaderboardCode.GDScorePribadiObjects2= [];
gdjs.LeaderboardCode.GDScorePribadiObjects3= [];
gdjs.LeaderboardCode.GDScorePribadiObjects4= [];
gdjs.LeaderboardCode.GDRankNama1Objects1= [];
gdjs.LeaderboardCode.GDRankNama1Objects2= [];
gdjs.LeaderboardCode.GDRankNama1Objects3= [];
gdjs.LeaderboardCode.GDRankNama1Objects4= [];
gdjs.LeaderboardCode.GDRankScore1Objects1= [];
gdjs.LeaderboardCode.GDRankScore1Objects2= [];
gdjs.LeaderboardCode.GDRankScore1Objects3= [];
gdjs.LeaderboardCode.GDRankScore1Objects4= [];
gdjs.LeaderboardCode.GDRankNama2Objects1= [];
gdjs.LeaderboardCode.GDRankNama2Objects2= [];
gdjs.LeaderboardCode.GDRankNama2Objects3= [];
gdjs.LeaderboardCode.GDRankNama2Objects4= [];
gdjs.LeaderboardCode.GDRankScore2Objects1= [];
gdjs.LeaderboardCode.GDRankScore2Objects2= [];
gdjs.LeaderboardCode.GDRankScore2Objects3= [];
gdjs.LeaderboardCode.GDRankScore2Objects4= [];
gdjs.LeaderboardCode.GDRankNama3Objects1= [];
gdjs.LeaderboardCode.GDRankNama3Objects2= [];
gdjs.LeaderboardCode.GDRankNama3Objects3= [];
gdjs.LeaderboardCode.GDRankNama3Objects4= [];
gdjs.LeaderboardCode.GDRankScore3Objects1= [];
gdjs.LeaderboardCode.GDRankScore3Objects2= [];
gdjs.LeaderboardCode.GDRankScore3Objects3= [];
gdjs.LeaderboardCode.GDRankScore3Objects4= [];
gdjs.LeaderboardCode.GDTitleObjects1= [];
gdjs.LeaderboardCode.GDTitleObjects2= [];
gdjs.LeaderboardCode.GDTitleObjects3= [];
gdjs.LeaderboardCode.GDTitleObjects4= [];
gdjs.LeaderboardCode.GDMedal1Objects1= [];
gdjs.LeaderboardCode.GDMedal1Objects2= [];
gdjs.LeaderboardCode.GDMedal1Objects3= [];
gdjs.LeaderboardCode.GDMedal1Objects4= [];
gdjs.LeaderboardCode.GDMedal2Objects1= [];
gdjs.LeaderboardCode.GDMedal2Objects2= [];
gdjs.LeaderboardCode.GDMedal2Objects3= [];
gdjs.LeaderboardCode.GDMedal2Objects4= [];
gdjs.LeaderboardCode.GDMedal3Objects1= [];
gdjs.LeaderboardCode.GDMedal3Objects2= [];
gdjs.LeaderboardCode.GDMedal3Objects3= [];
gdjs.LeaderboardCode.GDMedal3Objects4= [];
gdjs.LeaderboardCode.GDTestAPIObjects1= [];
gdjs.LeaderboardCode.GDTestAPIObjects2= [];
gdjs.LeaderboardCode.GDTestAPIObjects3= [];
gdjs.LeaderboardCode.GDTestAPIObjects4= [];
gdjs.LeaderboardCode.GDNewBBTextObjects1= [];
gdjs.LeaderboardCode.GDNewBBTextObjects2= [];
gdjs.LeaderboardCode.GDNewBBTextObjects3= [];
gdjs.LeaderboardCode.GDNewBBTextObjects4= [];

gdjs.LeaderboardCode.conditionTrue_0 = {val:false};
gdjs.LeaderboardCode.condition0IsTrue_0 = {val:false};
gdjs.LeaderboardCode.condition1IsTrue_0 = {val:false};
gdjs.LeaderboardCode.condition2IsTrue_0 = {val:false};
gdjs.LeaderboardCode.conditionTrue_1 = {val:false};
gdjs.LeaderboardCode.condition0IsTrue_1 = {val:false};
gdjs.LeaderboardCode.condition1IsTrue_1 = {val:false};
gdjs.LeaderboardCode.condition2IsTrue_1 = {val:false};


gdjs.LeaderboardCode.eventsList0 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"1\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_1"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"2\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_2"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"3\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_3"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"4\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_4"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"5\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_5"), gdjs.VariablesContainer.badVariable);
}}

}


{



}


{


{
{gdjs.evtTools.network.sendAsyncRequest(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("LinkAPI")), "{ \"Leaderboard\": \"6\" }", "POST", "application/json", runtimeScene.getVariables().get("Return_Get_Leaderboard_6"), gdjs.VariablesContainer.badVariable);
}}

}


{


{
}

}


};gdjs.LeaderboardCode.eventsList1 = function(runtimeScene) {

{


gdjs.LeaderboardCode.eventsList0(runtimeScene);
}


};gdjs.LeaderboardCode.eventsList2 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_1")), runtimeScene.getVariables().get("Leaderboard_1"));
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_2")), runtimeScene.getVariables().get("Leaderboard_2"));
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_3")), runtimeScene.getVariables().get("Leaderboard_3"));
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_4")), runtimeScene.getVariables().get("Leaderboard_4"));
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_5")), runtimeScene.getVariables().get("Leaderboard_5"));
}}

}


{


{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Return_Get_Leaderboard_6")), runtimeScene.getVariables().get("Leaderboard_6"));
}}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME1Objects2Objects = Hashtable.newFrom({"GAME1": gdjs.LeaderboardCode.GDGAME1Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround1Objects2Objects = Hashtable.newFrom({"BackGround1": gdjs.LeaderboardCode.GDBackGround1Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock1Objects2Objects = Hashtable.newFrom({"GreenBlock1": gdjs.LeaderboardCode.GDGreenBlock1Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle1Objects2Objects = Hashtable.newFrom({"Title1": gdjs.LeaderboardCode.GDTitle1Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText1Objects2Objects = Hashtable.newFrom({"Text1": gdjs.LeaderboardCode.GDText1Objects2});
gdjs.LeaderboardCode.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround1"), gdjs.LeaderboardCode.GDBackGround1Objects2);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock1"), gdjs.LeaderboardCode.GDGreenBlock1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Skor1"), gdjs.LeaderboardCode.GDSkor1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Text1"), gdjs.LeaderboardCode.GDText1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Title1"), gdjs.LeaderboardCode.GDTitle1Objects2);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("0").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("1").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("2").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("3").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("4").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("5").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("6").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("7").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("8").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("9").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects2[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround1Objects2Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock1Objects2Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle1Objects2Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText1Objects2Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LeaderboardCode.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_1").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


gdjs.LeaderboardCode.eventsList3(runtimeScene);
}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME2Objects2Objects = Hashtable.newFrom({"GAME2": gdjs.LeaderboardCode.GDGAME2Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround2Objects3Objects = Hashtable.newFrom({"BackGround2": gdjs.LeaderboardCode.GDBackGround2Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock2Objects3Objects = Hashtable.newFrom({"GreenBlock2": gdjs.LeaderboardCode.GDGreenBlock2Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle2Objects3Objects = Hashtable.newFrom({"Title2": gdjs.LeaderboardCode.GDTitle2Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText2Objects3Objects = Hashtable.newFrom({"Text2": gdjs.LeaderboardCode.GDText2Objects3});
gdjs.LeaderboardCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround2"), gdjs.LeaderboardCode.GDBackGround2Objects3);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock2"), gdjs.LeaderboardCode.GDGreenBlock2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Skor2"), gdjs.LeaderboardCode.GDSkor2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Text2"), gdjs.LeaderboardCode.GDText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Title2"), gdjs.LeaderboardCode.GDTitle2Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("0").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("1").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("2").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("3").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("4").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("5").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("6").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("7").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("8").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("9").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects3[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround2Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock2Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle2Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText2Objects3Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LeaderboardCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_2").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


gdjs.LeaderboardCode.eventsList5(runtimeScene);
}


{


{
}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME3Objects2Objects = Hashtable.newFrom({"GAME3": gdjs.LeaderboardCode.GDGAME3Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround3Objects3Objects = Hashtable.newFrom({"BackGround3": gdjs.LeaderboardCode.GDBackGround3Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock3Objects3Objects = Hashtable.newFrom({"GreenBlock3": gdjs.LeaderboardCode.GDGreenBlock3Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle3Objects3Objects = Hashtable.newFrom({"Title3": gdjs.LeaderboardCode.GDTitle3Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText3Objects3Objects = Hashtable.newFrom({"Text3": gdjs.LeaderboardCode.GDText3Objects3});
gdjs.LeaderboardCode.eventsList7 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround3"), gdjs.LeaderboardCode.GDBackGround3Objects3);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock3"), gdjs.LeaderboardCode.GDGreenBlock3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Skor3"), gdjs.LeaderboardCode.GDSkor3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Text3"), gdjs.LeaderboardCode.GDText3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Title3"), gdjs.LeaderboardCode.GDTitle3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("0").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("1").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("2").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("3").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("4").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("5").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("6").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("7").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("8").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("9").getChild("moneyUser")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects3[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround3Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock3Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle3Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText3Objects3Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LeaderboardCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_3").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


gdjs.LeaderboardCode.eventsList7(runtimeScene);
}


{


{
}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME4Objects2Objects = Hashtable.newFrom({"GAME4": gdjs.LeaderboardCode.GDGAME4Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround4Objects3Objects = Hashtable.newFrom({"BackGround4": gdjs.LeaderboardCode.GDBackGround4Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock4Objects3Objects = Hashtable.newFrom({"GreenBlock4": gdjs.LeaderboardCode.GDGreenBlock4Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle4Objects3Objects = Hashtable.newFrom({"Title4": gdjs.LeaderboardCode.GDTitle4Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText4Objects3Objects = Hashtable.newFrom({"Text4": gdjs.LeaderboardCode.GDText4Objects3});
gdjs.LeaderboardCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround4"), gdjs.LeaderboardCode.GDBackGround4Objects3);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock4"), gdjs.LeaderboardCode.GDGreenBlock4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Skor4"), gdjs.LeaderboardCode.GDSkor4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Text4"), gdjs.LeaderboardCode.GDText4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Title4"), gdjs.LeaderboardCode.GDTitle4Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("0").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("1").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("2").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("3").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("4").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("5").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("6").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("7").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("8").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("9").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects3[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround4Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock4Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle4Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText4Objects3Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LeaderboardCode.eventsList10 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_4").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


gdjs.LeaderboardCode.eventsList9(runtimeScene);
}


{


{
}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME5Objects2Objects = Hashtable.newFrom({"GAME5": gdjs.LeaderboardCode.GDGAME5Objects2});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround5Objects3Objects = Hashtable.newFrom({"BackGround5": gdjs.LeaderboardCode.GDBackGround5Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock5Objects3Objects = Hashtable.newFrom({"GreenBlock5": gdjs.LeaderboardCode.GDGreenBlock5Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle5Objects3Objects = Hashtable.newFrom({"Title5": gdjs.LeaderboardCode.GDTitle5Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText5Objects3Objects = Hashtable.newFrom({"Text5": gdjs.LeaderboardCode.GDText5Objects3});
gdjs.LeaderboardCode.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround5"), gdjs.LeaderboardCode.GDBackGround5Objects3);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock5"), gdjs.LeaderboardCode.GDGreenBlock5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Skor5"), gdjs.LeaderboardCode.GDSkor5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Text5"), gdjs.LeaderboardCode.GDText5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Title5"), gdjs.LeaderboardCode.GDTitle5Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("0").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("1").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("2").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("3").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("4").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("5").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("6").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("7").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("8").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("9").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects3[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround5Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock5Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle5Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText5Objects3Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LeaderboardCode.eventsList12 = function(runtimeScene) {

{


gdjs.LeaderboardCode.eventsList11(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects3);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects3[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_5").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


{
}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME6Objects1Objects = Hashtable.newFrom({"GAME6": gdjs.LeaderboardCode.GDGAME6Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround6Objects3Objects = Hashtable.newFrom({"BackGround6": gdjs.LeaderboardCode.GDBackGround6Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock6Objects3Objects = Hashtable.newFrom({"GreenBlock6": gdjs.LeaderboardCode.GDGreenBlock6Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle6Objects3Objects = Hashtable.newFrom({"Title6": gdjs.LeaderboardCode.GDTitle6Objects3});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText6Objects3Objects = Hashtable.newFrom({"Text6": gdjs.LeaderboardCode.GDText6Objects3});
gdjs.LeaderboardCode.eventsList13 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround6"), gdjs.LeaderboardCode.GDBackGround6Objects3);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock6"), gdjs.LeaderboardCode.GDGreenBlock6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Skor6"), gdjs.LeaderboardCode.GDSkor6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Text6"), gdjs.LeaderboardCode.GDText6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Title6"), gdjs.LeaderboardCode.GDTitle6Objects3);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("1", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("0").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("0").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("2", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("1").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("1").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("3", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("2").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("2").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("4", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("3").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("3").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("5", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("4").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("4").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("6", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("5").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("5").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("7", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("6").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("6").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("8", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("7").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("7").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("9", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("8").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("8").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").AddItem("10", gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("9").getChild("username")), gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("9").getChild("highscore")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects3.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects3[i].getBehavior("SimpleScrollableListBehavior").CreateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround6Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock6Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle6Objects3Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText6Objects3Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
}

}


};gdjs.LeaderboardCode.eventsList14 = function(runtimeScene) {

{


gdjs.LeaderboardCode.eventsList13(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("RankNama1"), gdjs.LeaderboardCode.GDRankNama1Objects2);
gdjs.copyArray(runtimeScene.getObjects("RankNama2"), gdjs.LeaderboardCode.GDRankNama2Objects2);
gdjs.copyArray(runtimeScene.getObjects("RankNama3"), gdjs.LeaderboardCode.GDRankNama3Objects2);
gdjs.copyArray(runtimeScene.getObjects("RankScore1"), gdjs.LeaderboardCode.GDRankScore1Objects2);
gdjs.copyArray(runtimeScene.getObjects("RankScore2"), gdjs.LeaderboardCode.GDRankScore2Objects2);
gdjs.copyArray(runtimeScene.getObjects("RankScore3"), gdjs.LeaderboardCode.GDRankScore3Objects2);
{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama1Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("0").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore1Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore1Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("0").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama2Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama2Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("1").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore2Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore2Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("1").getChild("highscore")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankNama3Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankNama3Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("2").getChild("username")));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDRankScore3Objects2.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDRankScore3Objects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Leaderboard_6").getChild("data").getChild("2").getChild("highscore")));
}
}}

}


{


{
}

}


};gdjs.LeaderboardCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME1"), gdjs.LeaderboardCode.GDGAME1Objects2);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME1Objects2Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME2"), gdjs.LeaderboardCode.GDGAME2Objects2);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME2Objects2Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME3"), gdjs.LeaderboardCode.GDGAME3Objects2);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME3Objects2Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME4"), gdjs.LeaderboardCode.GDGAME4Objects2);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME4Objects2Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME5"), gdjs.LeaderboardCode.GDGAME5Objects2);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME5Objects2Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GAME6"), gdjs.LeaderboardCode.GDGAME6Objects1);

gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGAME6Objects1Objects, runtimeScene, true, false);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "GAME6");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.LeaderboardCode.eventsList16 = function(runtimeScene) {

{


gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
gdjs.LeaderboardCode.condition1IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.LeaderboardCode.condition0IsTrue_0.val ) {
{
{gdjs.LeaderboardCode.conditionTrue_1 = gdjs.LeaderboardCode.condition1IsTrue_0;
gdjs.LeaderboardCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9061844);
}
}}
if (gdjs.LeaderboardCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.LeaderboardCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround1Objects1Objects = Hashtable.newFrom({"BackGround1": gdjs.LeaderboardCode.GDBackGround1Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock1Objects1Objects = Hashtable.newFrom({"GreenBlock1": gdjs.LeaderboardCode.GDGreenBlock1Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle1Objects1Objects = Hashtable.newFrom({"Title1": gdjs.LeaderboardCode.GDTitle1Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText1Objects1Objects = Hashtable.newFrom({"Text1": gdjs.LeaderboardCode.GDText1Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround2Objects1Objects = Hashtable.newFrom({"BackGround2": gdjs.LeaderboardCode.GDBackGround2Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock2Objects1Objects = Hashtable.newFrom({"GreenBlock2": gdjs.LeaderboardCode.GDGreenBlock2Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle2Objects1Objects = Hashtable.newFrom({"Title2": gdjs.LeaderboardCode.GDTitle2Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText2Objects1Objects = Hashtable.newFrom({"Text2": gdjs.LeaderboardCode.GDText2Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround3Objects1Objects = Hashtable.newFrom({"BackGround3": gdjs.LeaderboardCode.GDBackGround3Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock3Objects1Objects = Hashtable.newFrom({"GreenBlock3": gdjs.LeaderboardCode.GDGreenBlock3Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle3Objects1Objects = Hashtable.newFrom({"Title3": gdjs.LeaderboardCode.GDTitle3Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText3Objects1Objects = Hashtable.newFrom({"Text3": gdjs.LeaderboardCode.GDText3Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround4Objects1Objects = Hashtable.newFrom({"BackGround4": gdjs.LeaderboardCode.GDBackGround4Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock4Objects1Objects = Hashtable.newFrom({"GreenBlock4": gdjs.LeaderboardCode.GDGreenBlock4Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle4Objects1Objects = Hashtable.newFrom({"Title4": gdjs.LeaderboardCode.GDTitle4Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText4Objects1Objects = Hashtable.newFrom({"Text4": gdjs.LeaderboardCode.GDText4Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround5Objects1Objects = Hashtable.newFrom({"BackGround5": gdjs.LeaderboardCode.GDBackGround5Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock5Objects1Objects = Hashtable.newFrom({"GreenBlock5": gdjs.LeaderboardCode.GDGreenBlock5Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle5Objects1Objects = Hashtable.newFrom({"Title5": gdjs.LeaderboardCode.GDTitle5Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText5Objects1Objects = Hashtable.newFrom({"Text5": gdjs.LeaderboardCode.GDText5Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround6Objects1Objects = Hashtable.newFrom({"BackGround6": gdjs.LeaderboardCode.GDBackGround6Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock6Objects1Objects = Hashtable.newFrom({"GreenBlock6": gdjs.LeaderboardCode.GDGreenBlock6Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle6Objects1Objects = Hashtable.newFrom({"Title6": gdjs.LeaderboardCode.GDTitle6Objects1});
gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText6Objects1Objects = Hashtable.newFrom({"Text6": gdjs.LeaderboardCode.GDText6Objects1});
gdjs.LeaderboardCode.eventsList17 = function(runtimeScene) {

{


gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME1");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME2");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME3");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME4");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME5");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "GAME6");
}}

}


{


gdjs.LeaderboardCode.condition0IsTrue_0.val = false;
{
gdjs.LeaderboardCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LeaderboardCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("LinkAPI").setString("http://10.1.86.38:8981/api/Gamification2022/Gamification/GetLeaderboard");
}
{ //Subevents
gdjs.LeaderboardCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.LeaderboardCode.eventsList2(runtimeScene);
}


{


gdjs.LeaderboardCode.eventsList16(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackGround1"), gdjs.LeaderboardCode.GDBackGround1Objects1);
gdjs.copyArray(runtimeScene.getObjects("BackGround2"), gdjs.LeaderboardCode.GDBackGround2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BackGround3"), gdjs.LeaderboardCode.GDBackGround3Objects1);
gdjs.copyArray(runtimeScene.getObjects("BackGround4"), gdjs.LeaderboardCode.GDBackGround4Objects1);
gdjs.copyArray(runtimeScene.getObjects("BackGround5"), gdjs.LeaderboardCode.GDBackGround5Objects1);
gdjs.copyArray(runtimeScene.getObjects("BackGround6"), gdjs.LeaderboardCode.GDBackGround6Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock1"), gdjs.LeaderboardCode.GDGreenBlock1Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock2"), gdjs.LeaderboardCode.GDGreenBlock2Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock3"), gdjs.LeaderboardCode.GDGreenBlock3Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock4"), gdjs.LeaderboardCode.GDGreenBlock4Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock5"), gdjs.LeaderboardCode.GDGreenBlock5Objects1);
gdjs.copyArray(runtimeScene.getObjects("GreenBlock6"), gdjs.LeaderboardCode.GDGreenBlock6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor1"), gdjs.LeaderboardCode.GDSkor1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor2"), gdjs.LeaderboardCode.GDSkor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor3"), gdjs.LeaderboardCode.GDSkor3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor4"), gdjs.LeaderboardCode.GDSkor4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor5"), gdjs.LeaderboardCode.GDSkor5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Skor6"), gdjs.LeaderboardCode.GDSkor6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text1"), gdjs.LeaderboardCode.GDText1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text2"), gdjs.LeaderboardCode.GDText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text3"), gdjs.LeaderboardCode.GDText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text4"), gdjs.LeaderboardCode.GDText4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text5"), gdjs.LeaderboardCode.GDText5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text6"), gdjs.LeaderboardCode.GDText6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title1"), gdjs.LeaderboardCode.GDTitle1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title2"), gdjs.LeaderboardCode.GDTitle2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title3"), gdjs.LeaderboardCode.GDTitle3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title4"), gdjs.LeaderboardCode.GDTitle4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title5"), gdjs.LeaderboardCode.GDTitle5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Title6"), gdjs.LeaderboardCode.GDTitle6Objects1);
{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor1Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor1Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround1Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock1Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle1Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText1Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor2Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor2Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround2Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock2Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle2Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor3Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor3Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround3Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock3Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle3Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText3Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor4Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor4Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround4Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock4Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle4Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText4Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor5Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor5Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround5Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock5Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle5Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText5Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LeaderboardCode.GDSkor6Objects1.length ;i < len;++i) {
    gdjs.LeaderboardCode.GDSkor6Objects1[i].getBehavior("SimpleScrollableListBehavior").UpdateList(gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDBackGround6Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDGreenBlock6Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDTitle6Objects1Objects, gdjs.LeaderboardCode.mapOfGDgdjs_46LeaderboardCode_46GDText6Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{



}


};

gdjs.LeaderboardCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LeaderboardCode.GDSkor1Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor1Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor1Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor1Objects4.length = 0;
gdjs.LeaderboardCode.GDSkor6Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor6Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor6Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor6Objects4.length = 0;
gdjs.LeaderboardCode.GDSkor5Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor5Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor5Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor5Objects4.length = 0;
gdjs.LeaderboardCode.GDSkor4Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor4Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor4Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor4Objects4.length = 0;
gdjs.LeaderboardCode.GDSkor3Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor3Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor3Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor3Objects4.length = 0;
gdjs.LeaderboardCode.GDSkor2Objects1.length = 0;
gdjs.LeaderboardCode.GDSkor2Objects2.length = 0;
gdjs.LeaderboardCode.GDSkor2Objects3.length = 0;
gdjs.LeaderboardCode.GDSkor2Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround0Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround0Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround0Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround0Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround6Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround6Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround6Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround6Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround5Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround5Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround5Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround5Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround4Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround4Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround4Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround4Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround3Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround3Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround3Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround3Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround2Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround2Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround2Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround2Objects4.length = 0;
gdjs.LeaderboardCode.GDBackGround1Objects1.length = 0;
gdjs.LeaderboardCode.GDBackGround1Objects2.length = 0;
gdjs.LeaderboardCode.GDBackGround1Objects3.length = 0;
gdjs.LeaderboardCode.GDBackGround1Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock6Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock6Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock6Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock6Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock5Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock5Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock5Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock5Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock4Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock4Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock4Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock4Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock3Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock3Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock3Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock3Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock2Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock2Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock2Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock2Objects4.length = 0;
gdjs.LeaderboardCode.GDGreenBlock1Objects1.length = 0;
gdjs.LeaderboardCode.GDGreenBlock1Objects2.length = 0;
gdjs.LeaderboardCode.GDGreenBlock1Objects3.length = 0;
gdjs.LeaderboardCode.GDGreenBlock1Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME1Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME1Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME1Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME1Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME2Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME2Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME2Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME2Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME3Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME3Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME3Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME3Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME4Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME4Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME4Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME4Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME5Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME5Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME5Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME5Objects4.length = 0;
gdjs.LeaderboardCode.GDGAME6Objects1.length = 0;
gdjs.LeaderboardCode.GDGAME6Objects2.length = 0;
gdjs.LeaderboardCode.GDGAME6Objects3.length = 0;
gdjs.LeaderboardCode.GDGAME6Objects4.length = 0;
gdjs.LeaderboardCode.GDText6Objects1.length = 0;
gdjs.LeaderboardCode.GDText6Objects2.length = 0;
gdjs.LeaderboardCode.GDText6Objects3.length = 0;
gdjs.LeaderboardCode.GDText6Objects4.length = 0;
gdjs.LeaderboardCode.GDText5Objects1.length = 0;
gdjs.LeaderboardCode.GDText5Objects2.length = 0;
gdjs.LeaderboardCode.GDText5Objects3.length = 0;
gdjs.LeaderboardCode.GDText5Objects4.length = 0;
gdjs.LeaderboardCode.GDText4Objects1.length = 0;
gdjs.LeaderboardCode.GDText4Objects2.length = 0;
gdjs.LeaderboardCode.GDText4Objects3.length = 0;
gdjs.LeaderboardCode.GDText4Objects4.length = 0;
gdjs.LeaderboardCode.GDText3Objects1.length = 0;
gdjs.LeaderboardCode.GDText3Objects2.length = 0;
gdjs.LeaderboardCode.GDText3Objects3.length = 0;
gdjs.LeaderboardCode.GDText3Objects4.length = 0;
gdjs.LeaderboardCode.GDText2Objects1.length = 0;
gdjs.LeaderboardCode.GDText2Objects2.length = 0;
gdjs.LeaderboardCode.GDText2Objects3.length = 0;
gdjs.LeaderboardCode.GDText2Objects4.length = 0;
gdjs.LeaderboardCode.GDText1Objects1.length = 0;
gdjs.LeaderboardCode.GDText1Objects2.length = 0;
gdjs.LeaderboardCode.GDText1Objects3.length = 0;
gdjs.LeaderboardCode.GDText1Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle6Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle6Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle6Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle6Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle5Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle5Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle5Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle5Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle4Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle4Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle4Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle4Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle3Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle3Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle3Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle3Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle2Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle2Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle2Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle2Objects4.length = 0;
gdjs.LeaderboardCode.GDTitle1Objects1.length = 0;
gdjs.LeaderboardCode.GDTitle1Objects2.length = 0;
gdjs.LeaderboardCode.GDTitle1Objects3.length = 0;
gdjs.LeaderboardCode.GDTitle1Objects4.length = 0;
gdjs.LeaderboardCode.GDMaskObjects1.length = 0;
gdjs.LeaderboardCode.GDMaskObjects2.length = 0;
gdjs.LeaderboardCode.GDMaskObjects3.length = 0;
gdjs.LeaderboardCode.GDMaskObjects4.length = 0;
gdjs.LeaderboardCode.GDMask2Objects1.length = 0;
gdjs.LeaderboardCode.GDMask2Objects2.length = 0;
gdjs.LeaderboardCode.GDMask2Objects3.length = 0;
gdjs.LeaderboardCode.GDMask2Objects4.length = 0;
gdjs.LeaderboardCode.GDConsoleObjects1.length = 0;
gdjs.LeaderboardCode.GDConsoleObjects2.length = 0;
gdjs.LeaderboardCode.GDConsoleObjects3.length = 0;
gdjs.LeaderboardCode.GDConsoleObjects4.length = 0;
gdjs.LeaderboardCode.GDNamaPribadiObjects1.length = 0;
gdjs.LeaderboardCode.GDNamaPribadiObjects2.length = 0;
gdjs.LeaderboardCode.GDNamaPribadiObjects3.length = 0;
gdjs.LeaderboardCode.GDNamaPribadiObjects4.length = 0;
gdjs.LeaderboardCode.GDScorePribadiObjects1.length = 0;
gdjs.LeaderboardCode.GDScorePribadiObjects2.length = 0;
gdjs.LeaderboardCode.GDScorePribadiObjects3.length = 0;
gdjs.LeaderboardCode.GDScorePribadiObjects4.length = 0;
gdjs.LeaderboardCode.GDRankNama1Objects1.length = 0;
gdjs.LeaderboardCode.GDRankNama1Objects2.length = 0;
gdjs.LeaderboardCode.GDRankNama1Objects3.length = 0;
gdjs.LeaderboardCode.GDRankNama1Objects4.length = 0;
gdjs.LeaderboardCode.GDRankScore1Objects1.length = 0;
gdjs.LeaderboardCode.GDRankScore1Objects2.length = 0;
gdjs.LeaderboardCode.GDRankScore1Objects3.length = 0;
gdjs.LeaderboardCode.GDRankScore1Objects4.length = 0;
gdjs.LeaderboardCode.GDRankNama2Objects1.length = 0;
gdjs.LeaderboardCode.GDRankNama2Objects2.length = 0;
gdjs.LeaderboardCode.GDRankNama2Objects3.length = 0;
gdjs.LeaderboardCode.GDRankNama2Objects4.length = 0;
gdjs.LeaderboardCode.GDRankScore2Objects1.length = 0;
gdjs.LeaderboardCode.GDRankScore2Objects2.length = 0;
gdjs.LeaderboardCode.GDRankScore2Objects3.length = 0;
gdjs.LeaderboardCode.GDRankScore2Objects4.length = 0;
gdjs.LeaderboardCode.GDRankNama3Objects1.length = 0;
gdjs.LeaderboardCode.GDRankNama3Objects2.length = 0;
gdjs.LeaderboardCode.GDRankNama3Objects3.length = 0;
gdjs.LeaderboardCode.GDRankNama3Objects4.length = 0;
gdjs.LeaderboardCode.GDRankScore3Objects1.length = 0;
gdjs.LeaderboardCode.GDRankScore3Objects2.length = 0;
gdjs.LeaderboardCode.GDRankScore3Objects3.length = 0;
gdjs.LeaderboardCode.GDRankScore3Objects4.length = 0;
gdjs.LeaderboardCode.GDTitleObjects1.length = 0;
gdjs.LeaderboardCode.GDTitleObjects2.length = 0;
gdjs.LeaderboardCode.GDTitleObjects3.length = 0;
gdjs.LeaderboardCode.GDTitleObjects4.length = 0;
gdjs.LeaderboardCode.GDMedal1Objects1.length = 0;
gdjs.LeaderboardCode.GDMedal1Objects2.length = 0;
gdjs.LeaderboardCode.GDMedal1Objects3.length = 0;
gdjs.LeaderboardCode.GDMedal1Objects4.length = 0;
gdjs.LeaderboardCode.GDMedal2Objects1.length = 0;
gdjs.LeaderboardCode.GDMedal2Objects2.length = 0;
gdjs.LeaderboardCode.GDMedal2Objects3.length = 0;
gdjs.LeaderboardCode.GDMedal2Objects4.length = 0;
gdjs.LeaderboardCode.GDMedal3Objects1.length = 0;
gdjs.LeaderboardCode.GDMedal3Objects2.length = 0;
gdjs.LeaderboardCode.GDMedal3Objects3.length = 0;
gdjs.LeaderboardCode.GDMedal3Objects4.length = 0;
gdjs.LeaderboardCode.GDTestAPIObjects1.length = 0;
gdjs.LeaderboardCode.GDTestAPIObjects2.length = 0;
gdjs.LeaderboardCode.GDTestAPIObjects3.length = 0;
gdjs.LeaderboardCode.GDTestAPIObjects4.length = 0;
gdjs.LeaderboardCode.GDNewBBTextObjects1.length = 0;
gdjs.LeaderboardCode.GDNewBBTextObjects2.length = 0;
gdjs.LeaderboardCode.GDNewBBTextObjects3.length = 0;
gdjs.LeaderboardCode.GDNewBBTextObjects4.length = 0;

gdjs.LeaderboardCode.eventsList17(runtimeScene);
return;

}

gdjs['LeaderboardCode'] = gdjs.LeaderboardCode;
