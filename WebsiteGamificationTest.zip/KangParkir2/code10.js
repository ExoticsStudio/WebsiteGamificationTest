gdjs.Stage10Code = {};
gdjs.Stage10Code.GDCarObjects3_1final = [];

gdjs.Stage10Code.GDLoadingObjects3_1final = [];

gdjs.Stage10Code.GDRoadDown2Objects3_1final = [];

gdjs.Stage10Code.GDRoadDownObjects3_1final = [];

gdjs.Stage10Code.GDRoadLeft2Objects3_1final = [];

gdjs.Stage10Code.GDRoadLeftObjects3_1final = [];

gdjs.Stage10Code.GDRoadRight2Objects3_1final = [];

gdjs.Stage10Code.GDRoadRightObjects3_1final = [];

gdjs.Stage10Code.GDRoadUp2Objects3_1final = [];

gdjs.Stage10Code.GDRoadUpObjects3_1final = [];

gdjs.Stage10Code.forEachIndex3 = 0;

gdjs.Stage10Code.forEachObjects3 = [];

gdjs.Stage10Code.forEachTemporary3 = null;

gdjs.Stage10Code.forEachTotalCount3 = 0;

gdjs.Stage10Code.GDPauseResumeButtonObjects1= [];
gdjs.Stage10Code.GDPauseResumeButtonObjects2= [];
gdjs.Stage10Code.GDPauseResumeButtonObjects3= [];
gdjs.Stage10Code.GDPauseResumeButtonObjects4= [];
gdjs.Stage10Code.GDPauseResumeButtonObjects5= [];
gdjs.Stage10Code.GDPauseBackgroundObjects1= [];
gdjs.Stage10Code.GDPauseBackgroundObjects2= [];
gdjs.Stage10Code.GDPauseBackgroundObjects3= [];
gdjs.Stage10Code.GDPauseBackgroundObjects4= [];
gdjs.Stage10Code.GDPauseBackgroundObjects5= [];
gdjs.Stage10Code.GDGamePausedTextObjects1= [];
gdjs.Stage10Code.GDGamePausedTextObjects2= [];
gdjs.Stage10Code.GDGamePausedTextObjects3= [];
gdjs.Stage10Code.GDGamePausedTextObjects4= [];
gdjs.Stage10Code.GDGamePausedTextObjects5= [];
gdjs.Stage10Code.GDHomeButtonObjects1= [];
gdjs.Stage10Code.GDHomeButtonObjects2= [];
gdjs.Stage10Code.GDHomeButtonObjects3= [];
gdjs.Stage10Code.GDHomeButtonObjects4= [];
gdjs.Stage10Code.GDHomeButtonObjects5= [];
gdjs.Stage10Code.GDNewTiledSpriteObjects1= [];
gdjs.Stage10Code.GDNewTiledSpriteObjects2= [];
gdjs.Stage10Code.GDNewTiledSpriteObjects3= [];
gdjs.Stage10Code.GDNewTiledSpriteObjects4= [];
gdjs.Stage10Code.GDNewTiledSpriteObjects5= [];
gdjs.Stage10Code.GDObstacleObjects1= [];
gdjs.Stage10Code.GDObstacleObjects2= [];
gdjs.Stage10Code.GDObstacleObjects3= [];
gdjs.Stage10Code.GDObstacleObjects4= [];
gdjs.Stage10Code.GDObstacleObjects5= [];
gdjs.Stage10Code.GDTutorialTextObjects1= [];
gdjs.Stage10Code.GDTutorialTextObjects2= [];
gdjs.Stage10Code.GDTutorialTextObjects3= [];
gdjs.Stage10Code.GDTutorialTextObjects4= [];
gdjs.Stage10Code.GDTutorialTextObjects5= [];
gdjs.Stage10Code.GDRoadRightObjects1= [];
gdjs.Stage10Code.GDRoadRightObjects2= [];
gdjs.Stage10Code.GDRoadRightObjects3= [];
gdjs.Stage10Code.GDRoadRightObjects4= [];
gdjs.Stage10Code.GDRoadRightObjects5= [];
gdjs.Stage10Code.GDRoadRight2Objects1= [];
gdjs.Stage10Code.GDRoadRight2Objects2= [];
gdjs.Stage10Code.GDRoadRight2Objects3= [];
gdjs.Stage10Code.GDRoadRight2Objects4= [];
gdjs.Stage10Code.GDRoadRight2Objects5= [];
gdjs.Stage10Code.GDRoadDownObjects1= [];
gdjs.Stage10Code.GDRoadDownObjects2= [];
gdjs.Stage10Code.GDRoadDownObjects3= [];
gdjs.Stage10Code.GDRoadDownObjects4= [];
gdjs.Stage10Code.GDRoadDownObjects5= [];
gdjs.Stage10Code.GDRoadDown2Objects1= [];
gdjs.Stage10Code.GDRoadDown2Objects2= [];
gdjs.Stage10Code.GDRoadDown2Objects3= [];
gdjs.Stage10Code.GDRoadDown2Objects4= [];
gdjs.Stage10Code.GDRoadDown2Objects5= [];
gdjs.Stage10Code.GDRoadLeftObjects1= [];
gdjs.Stage10Code.GDRoadLeftObjects2= [];
gdjs.Stage10Code.GDRoadLeftObjects3= [];
gdjs.Stage10Code.GDRoadLeftObjects4= [];
gdjs.Stage10Code.GDRoadLeftObjects5= [];
gdjs.Stage10Code.GDRoadLeft2Objects1= [];
gdjs.Stage10Code.GDRoadLeft2Objects2= [];
gdjs.Stage10Code.GDRoadLeft2Objects3= [];
gdjs.Stage10Code.GDRoadLeft2Objects4= [];
gdjs.Stage10Code.GDRoadLeft2Objects5= [];
gdjs.Stage10Code.GDRoadUpObjects1= [];
gdjs.Stage10Code.GDRoadUpObjects2= [];
gdjs.Stage10Code.GDRoadUpObjects3= [];
gdjs.Stage10Code.GDRoadUpObjects4= [];
gdjs.Stage10Code.GDRoadUpObjects5= [];
gdjs.Stage10Code.GDRoadUp2Objects1= [];
gdjs.Stage10Code.GDRoadUp2Objects2= [];
gdjs.Stage10Code.GDRoadUp2Objects3= [];
gdjs.Stage10Code.GDRoadUp2Objects4= [];
gdjs.Stage10Code.GDRoadUp2Objects5= [];
gdjs.Stage10Code.GDCarObjects1= [];
gdjs.Stage10Code.GDCarObjects2= [];
gdjs.Stage10Code.GDCarObjects3= [];
gdjs.Stage10Code.GDCarObjects4= [];
gdjs.Stage10Code.GDCarObjects5= [];
gdjs.Stage10Code.GDGrassObjects1= [];
gdjs.Stage10Code.GDGrassObjects2= [];
gdjs.Stage10Code.GDGrassObjects3= [];
gdjs.Stage10Code.GDGrassObjects4= [];
gdjs.Stage10Code.GDGrassObjects5= [];
gdjs.Stage10Code.GDObstacleObjects1= [];
gdjs.Stage10Code.GDObstacleObjects2= [];
gdjs.Stage10Code.GDObstacleObjects3= [];
gdjs.Stage10Code.GDObstacleObjects4= [];
gdjs.Stage10Code.GDObstacleObjects5= [];
gdjs.Stage10Code.GDGrassBGObjects1= [];
gdjs.Stage10Code.GDGrassBGObjects2= [];
gdjs.Stage10Code.GDGrassBGObjects3= [];
gdjs.Stage10Code.GDGrassBGObjects4= [];
gdjs.Stage10Code.GDGrassBGObjects5= [];
gdjs.Stage10Code.GDDecorObjects1= [];
gdjs.Stage10Code.GDDecorObjects2= [];
gdjs.Stage10Code.GDDecorObjects3= [];
gdjs.Stage10Code.GDDecorObjects4= [];
gdjs.Stage10Code.GDDecorObjects5= [];
gdjs.Stage10Code.GDTimerObjects1= [];
gdjs.Stage10Code.GDTimerObjects2= [];
gdjs.Stage10Code.GDTimerObjects3= [];
gdjs.Stage10Code.GDTimerObjects4= [];
gdjs.Stage10Code.GDTimerObjects5= [];
gdjs.Stage10Code.GDStageClearedObjects1= [];
gdjs.Stage10Code.GDStageClearedObjects2= [];
gdjs.Stage10Code.GDStageClearedObjects3= [];
gdjs.Stage10Code.GDStageClearedObjects4= [];
gdjs.Stage10Code.GDStageClearedObjects5= [];
gdjs.Stage10Code.GDNewTextObjects1= [];
gdjs.Stage10Code.GDNewTextObjects2= [];
gdjs.Stage10Code.GDNewTextObjects3= [];
gdjs.Stage10Code.GDNewTextObjects4= [];
gdjs.Stage10Code.GDNewTextObjects5= [];
gdjs.Stage10Code.GDLoadingObjects1= [];
gdjs.Stage10Code.GDLoadingObjects2= [];
gdjs.Stage10Code.GDLoadingObjects3= [];
gdjs.Stage10Code.GDLoadingObjects4= [];
gdjs.Stage10Code.GDLoadingObjects5= [];

gdjs.Stage10Code.conditionTrue_0 = {val:false};
gdjs.Stage10Code.condition0IsTrue_0 = {val:false};
gdjs.Stage10Code.condition1IsTrue_0 = {val:false};
gdjs.Stage10Code.condition2IsTrue_0 = {val:false};
gdjs.Stage10Code.condition3IsTrue_0 = {val:false};
gdjs.Stage10Code.condition4IsTrue_0 = {val:false};
gdjs.Stage10Code.conditionTrue_1 = {val:false};
gdjs.Stage10Code.condition0IsTrue_1 = {val:false};
gdjs.Stage10Code.condition1IsTrue_1 = {val:false};
gdjs.Stage10Code.condition2IsTrue_1 = {val:false};
gdjs.Stage10Code.condition3IsTrue_1 = {val:false};
gdjs.Stage10Code.condition4IsTrue_1 = {val:false};


gdjs.Stage10Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects3, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.Stage10Code.GDGrassObjects4);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects4.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects4[i].getBehavior("Physics2").addPrismaticJoint((gdjs.Stage10Code.GDCarObjects4[i].getCenterXInScene()), (gdjs.Stage10Code.GDCarObjects4[i].getCenterYInScene()), (gdjs.Stage10Code.GDGrassObjects4.length !== 0 ? gdjs.Stage10Code.GDGrassObjects4[0] : null), (gdjs.Stage10Code.GDCarObjects4[i].getCenterXInScene()), (gdjs.Stage10Code.GDCarObjects4[i].getCenterYInScene()), (gdjs.Stage10Code.GDCarObjects4[i].getAngle()), 0, false, 100, 100, false, 0, 0, false, runtimeScene.getVariables().get("JointID"));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects4.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects4[i].returnVariable(gdjs.Stage10Code.GDCarObjects4[i].getVariables().get("JointID")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("JointID")));
}
}}

}


};gdjs.Stage10Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);

for(gdjs.Stage10Code.forEachIndex3 = 0;gdjs.Stage10Code.forEachIndex3 < gdjs.Stage10Code.GDCarObjects2.length;++gdjs.Stage10Code.forEachIndex3) {
gdjs.Stage10Code.GDCarObjects3.length = 0;


gdjs.Stage10Code.forEachTemporary3 = gdjs.Stage10Code.GDCarObjects2[gdjs.Stage10Code.forEachIndex3];
gdjs.Stage10Code.GDCarObjects3.push(gdjs.Stage10Code.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.Stage10Code.eventsList0(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Stage10Code.eventsList2 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("DrivingSpeed").setNumber(350);
}{runtimeScene.getVariables().get("RotationSpeed").setNumber(450);
}}

}


};gdjs.Stage10Code.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].setAnimationFrame(gdjs.randomInRange(0, 8));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].pauseAnimation();
}
}}

}


};gdjs.Stage10Code.eventsList4 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("SceneTimeLeft").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDTimerObjects2Objects = Hashtable.newFrom({"Timer": gdjs.Stage10Code.GDTimerObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDStageClearedObjects2Objects = Hashtable.newFrom({"StageCleared": gdjs.Stage10Code.GDStageClearedObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDHomeButtonObjects2Objects = Hashtable.newFrom({"HomeButton": gdjs.Stage10Code.GDHomeButtonObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects = Hashtable.newFrom({"PauseResumeButton": gdjs.Stage10Code.GDPauseResumeButtonObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDGamePausedTextObjects2Objects = Hashtable.newFrom({"GamePausedText": gdjs.Stage10Code.GDGamePausedTextObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDLoadingObjects2Objects = Hashtable.newFrom({"Loading": gdjs.Stage10Code.GDLoadingObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseBackgroundObjects2Objects = Hashtable.newFrom({"PauseBackground": gdjs.Stage10Code.GDPauseBackgroundObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDNewTiledSpriteObjects2Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.Stage10Code.GDNewTiledSpriteObjects2});
gdjs.Stage10Code.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Stage10Code.GDGrassBGObjects2);
gdjs.Stage10Code.GDGamePausedTextObjects2.length = 0;

gdjs.Stage10Code.GDHomeButtonObjects2.length = 0;

gdjs.Stage10Code.GDLoadingObjects2.length = 0;

gdjs.Stage10Code.GDNewTiledSpriteObjects2.length = 0;

gdjs.Stage10Code.GDPauseBackgroundObjects2.length = 0;

gdjs.Stage10Code.GDPauseResumeButtonObjects2.length = 0;

gdjs.Stage10Code.GDStageClearedObjects2.length = 0;

gdjs.Stage10Code.GDTimerObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDTimerObjects2Objects, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getWidth()) / 2 - (( gdjs.Stage10Code.GDTimerObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDTimerObjects2[0].getWidth()) / 2, 25, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDStageClearedObjects2Objects, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getWidth()) / 2 - (( gdjs.Stage10Code.GDStageClearedObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDStageClearedObjects2[0].getWidth()) / 2, 75, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDHomeButtonObjects2Objects, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getWidth()) / 2 + 100, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getHeight()) / 2, "");
}{for(var i = 0, len = gdjs.Stage10Code.GDHomeButtonObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDHomeButtonObjects2[i].setScale(0.125);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getWidth()) - 40, 40, "");
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects2[i].setScale(0.075);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDGamePausedTextObjects2Objects, 50, (( gdjs.Stage10Code.GDGrassBGObjects2.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects2[0].getHeight()) / 4, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDLoadingObjects2Objects, 0, -(100), "Loading");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseBackgroundObjects2Objects, 0, 0, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDNewTiledSpriteObjects2Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseBackgroundObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseBackgroundObjects2[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDNewTiledSpriteObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDNewTiledSpriteObjects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseBackgroundObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseBackgroundObjects2[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDGamePausedTextObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDGamePausedTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDHomeButtonObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDHomeButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDNewTiledSpriteObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDNewTiledSpriteObjects2[i].hide();
}
}}

}


};gdjs.Stage10Code.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].activateBehavior("DraggablePhysics", false);
}
}}

}


};gdjs.Stage10Code.eventsList7 = function(runtimeScene) {

{


{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("GamePaused"), true);
}}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDTutorialTextObjects1Objects = Hashtable.newFrom({"TutorialText": gdjs.Stage10Code.GDTutorialTextObjects1});
gdjs.Stage10Code.eventsList8 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), true);
}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Stage10Code.GDGrassBGObjects1);
gdjs.Stage10Code.GDTutorialTextObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDTutorialTextObjects1Objects, (( gdjs.Stage10Code.GDGrassBGObjects1.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects1[0].getWidth()) / 2 - (249 / 2), (( gdjs.Stage10Code.GDGrassBGObjects1.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects1[0].getHeight()) / 2 - (270 / 2), "");
}}

}


};gdjs.Stage10Code.eventsList9 = function(runtimeScene) {

{


gdjs.Stage10Code.eventsList1(runtimeScene);
}


{


gdjs.Stage10Code.eventsList2(runtimeScene);
}


{


gdjs.Stage10Code.eventsList3(runtimeScene);
}


{


gdjs.Stage10Code.eventsList4(runtimeScene);
}


{


gdjs.Stage10Code.eventsList5(runtimeScene);
}


{


gdjs.Stage10Code.eventsList6(runtimeScene);
}


{


gdjs.Stage10Code.eventsList7(runtimeScene);
}


{


gdjs.Stage10Code.eventsList8(runtimeScene);
}


};gdjs.Stage10Code.eventsList10 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Stage10Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.Stage10Code.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.Stage10Code.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.Stage10Code.GDNewTiledSpriteObjects1[i].setYOffset(gdjs.Stage10Code.GDNewTiledSpriteObjects1[i].getYOffset() + (2));
}
}}

}


};gdjs.Stage10Code.eventsList12 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) >= 0;
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) < 10;
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Stage10Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDTimerObjects2[i].setString(gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft"))), 0, 3));
}
}}

}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) >= 10;
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) < 100;
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Stage10Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDTimerObjects2[i].setString(gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft"))), 0, 4));
}
}}

}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) >= 100;
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) < 1000;
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Stage10Code.GDTimerObjects1);
{for(var i = 0, len = gdjs.Stage10Code.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Stage10Code.GDTimerObjects1[i].setString(gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft"))), 0, 5));
}
}}

}


};gdjs.Stage10Code.eventsList13 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("StageCleared"), gdjs.Stage10Code.GDStageClearedObjects1);
{for(var i = 0, len = gdjs.Stage10Code.GDStageClearedObjects1.length ;i < len;++i) {
    gdjs.Stage10Code.GDStageClearedObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}
{ //Subevents
gdjs.Stage10Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Loading"), gdjs.Stage10Code.GDLoadingObjects3);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDLoadingObjects3.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDLoadingObjects3[i].getBehavior("Tween").hasFinished("LoadingOut") ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDLoadingObjects3[k] = gdjs.Stage10Code.GDLoadingObjects3[i];
        ++k;
    }
}
gdjs.Stage10Code.GDLoadingObjects3.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13397652);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].activateBehavior("DraggablePhysics", true);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("GamePaused"), false);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SecondsTimer");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), false);
}}

}


};gdjs.Stage10Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Loading"), gdjs.Stage10Code.GDLoadingObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDLoadingObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDLoadingObjects2[i].getBehavior("Tween").hasFinished("LoadingOut") ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDLoadingObjects2[k] = gdjs.Stage10Code.GDLoadingObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDLoadingObjects2.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13399908);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].activateBehavior("DraggablePhysics", true);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("GamePaused"), false);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SecondsTimer");
}}

}


};gdjs.Stage10Code.eventsList16 = function(runtimeScene) {

{



}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), true);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition2IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13397212);
}
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList14(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13399172);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.eventsList17 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SecondsTimer") >= 0.1;
}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("SceneTimeLeft").sub(0.1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SecondsTimer");
}}

}


};gdjs.Stage10Code.eventsList18 = function(runtimeScene) {

{


gdjs.Stage10Code.eventsList16(runtimeScene);
}


{


gdjs.Stage10Code.eventsList17(runtimeScene);
}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects2Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDGrassObjects2Objects = Hashtable.newFrom({"Grass": gdjs.Stage10Code.GDGrassObjects2});
gdjs.Stage10Code.eventsList19 = function(runtimeScene) {

{


{
/* Reuse gdjs.Stage10Code.GDCarObjects2 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].getBehavior("Physics2").removeJoint((gdjs.RuntimeObject.getVariableNumber(gdjs.Stage10Code.GDCarObjects2[i].getVariables().get("JointID"))));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].activateBehavior("DraggablePhysics", false);
}
}}

}


};gdjs.Stage10Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.Stage10Code.GDGrassObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects2[i].getVariableBoolean(gdjs.Stage10Code.GDCarObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects2[k] = gdjs.Stage10Code.GDCarObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects2.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects2Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDGrassObjects2Objects, true, runtimeScene, false);
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects2 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].setVariableBoolean(gdjs.Stage10Code.GDCarObjects2[i].getVariables().getFromIndex(0), true);
}
}
{ //Subevents
gdjs.Stage10Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects4Objects = Hashtable.newFrom({"RoadRight": gdjs.Stage10Code.GDRoadRightObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRight2Objects4Objects = Hashtable.newFrom({"RoadRight2": gdjs.Stage10Code.GDRoadRight2Objects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects3Objects = Hashtable.newFrom({"RoadDown": gdjs.Stage10Code.GDRoadDownObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects3Objects = Hashtable.newFrom({"RoadUp": gdjs.Stage10Code.GDRoadUpObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects4Objects = Hashtable.newFrom({"RoadDown": gdjs.Stage10Code.GDRoadDownObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDown2Objects4Objects = Hashtable.newFrom({"RoadDown2": gdjs.Stage10Code.GDRoadDown2Objects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects3Objects = Hashtable.newFrom({"RoadRight": gdjs.Stage10Code.GDRoadRightObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects3Objects = Hashtable.newFrom({"RoadLeft": gdjs.Stage10Code.GDRoadLeftObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects4Objects = Hashtable.newFrom({"RoadLeft": gdjs.Stage10Code.GDRoadLeftObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeft2Objects4Objects = Hashtable.newFrom({"RoadLeft2": gdjs.Stage10Code.GDRoadLeft2Objects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects3Objects = Hashtable.newFrom({"RoadDown": gdjs.Stage10Code.GDRoadDownObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects3Objects = Hashtable.newFrom({"RoadUp": gdjs.Stage10Code.GDRoadUpObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects4Objects = Hashtable.newFrom({"RoadUp": gdjs.Stage10Code.GDRoadUpObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUp2Objects4Objects = Hashtable.newFrom({"RoadUp2": gdjs.Stage10Code.GDRoadUp2Objects4});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects3Objects = Hashtable.newFrom({"RoadRight": gdjs.Stage10Code.GDRoadRightObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects3Objects = Hashtable.newFrom({"RoadLeft": gdjs.Stage10Code.GDRoadLeftObjects3});
gdjs.Stage10Code.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.Stage10Code.GDRoadDownObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.Stage10Code.GDRoadUpObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);

gdjs.Stage10Code.GDRoadRightObjects3.length = 0;

gdjs.Stage10Code.GDRoadRight2Objects3.length = 0;


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.GDCarObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadRightObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadRight2Objects3_1final.length = 0;gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.Stage10Code.GDRoadRightObjects4);
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadRightObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadRightObjects3_1final.indexOf(gdjs.Stage10Code.GDRoadRightObjects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadRightObjects3_1final.push(gdjs.Stage10Code.GDRoadRightObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadRight2"), gdjs.Stage10Code.GDRoadRight2Objects4);
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRight2Objects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadRight2Objects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadRight2Objects3_1final.indexOf(gdjs.Stage10Code.GDRoadRight2Objects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadRight2Objects3_1final.push(gdjs.Stage10Code.GDRoadRight2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects3_1final, gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadRightObjects3_1final, gdjs.Stage10Code.GDRoadRightObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadRight2Objects3_1final, gdjs.Stage10Code.GDRoadRight2Objects3);
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects3Objects, true, runtimeScene, false);
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].returnVariable(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")).setString("Right");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.Stage10Code.GDRoadLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.Stage10Code.GDRoadRightObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);

gdjs.Stage10Code.GDRoadDownObjects3.length = 0;

gdjs.Stage10Code.GDRoadDown2Objects3.length = 0;


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.GDCarObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadDownObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadDown2Objects3_1final.length = 0;gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.Stage10Code.GDRoadDownObjects4);
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadDownObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadDownObjects3_1final.indexOf(gdjs.Stage10Code.GDRoadDownObjects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadDownObjects3_1final.push(gdjs.Stage10Code.GDRoadDownObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadDown2"), gdjs.Stage10Code.GDRoadDown2Objects4);
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDown2Objects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadDown2Objects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadDown2Objects3_1final.indexOf(gdjs.Stage10Code.GDRoadDown2Objects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadDown2Objects3_1final.push(gdjs.Stage10Code.GDRoadDown2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects3_1final, gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadDownObjects3_1final, gdjs.Stage10Code.GDRoadDownObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadDown2Objects3_1final, gdjs.Stage10Code.GDRoadDown2Objects3);
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects3Objects, true, runtimeScene, true);
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].returnVariable(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")).setString("Down");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.Stage10Code.GDRoadDownObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.Stage10Code.GDRoadUpObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);

gdjs.Stage10Code.GDRoadLeftObjects3.length = 0;

gdjs.Stage10Code.GDRoadLeft2Objects3.length = 0;


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.GDCarObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadLeftObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadLeft2Objects3_1final.length = 0;gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.Stage10Code.GDRoadLeftObjects4);
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects4Objects, false, runtimeScene, true);
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadLeftObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadLeftObjects3_1final.indexOf(gdjs.Stage10Code.GDRoadLeftObjects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadLeftObjects3_1final.push(gdjs.Stage10Code.GDRoadLeftObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadLeft2"), gdjs.Stage10Code.GDRoadLeft2Objects4);
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeft2Objects4Objects, false, runtimeScene, true);
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadLeft2Objects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadLeft2Objects3_1final.indexOf(gdjs.Stage10Code.GDRoadLeft2Objects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadLeft2Objects3_1final.push(gdjs.Stage10Code.GDRoadLeft2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects3_1final, gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadLeftObjects3_1final, gdjs.Stage10Code.GDRoadLeftObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadLeft2Objects3_1final, gdjs.Stage10Code.GDRoadLeft2Objects3);
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadDownObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects3Objects, true, runtimeScene, false);
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].returnVariable(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")).setString("Left");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.Stage10Code.GDRoadLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.Stage10Code.GDRoadRightObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);

gdjs.Stage10Code.GDRoadUpObjects3.length = 0;

gdjs.Stage10Code.GDRoadUp2Objects3.length = 0;


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.GDCarObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadUpObjects3_1final.length = 0;gdjs.Stage10Code.GDRoadUp2Objects3_1final.length = 0;gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.Stage10Code.GDRoadUpObjects4);
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUpObjects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadUpObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadUpObjects3_1final.indexOf(gdjs.Stage10Code.GDRoadUpObjects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadUpObjects3_1final.push(gdjs.Stage10Code.GDRoadUpObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects4);

gdjs.copyArray(runtimeScene.getObjects("RoadUp2"), gdjs.Stage10Code.GDRoadUp2Objects4);
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects4Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadUp2Objects4Objects, false, runtimeScene, false);
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDCarObjects3_1final.indexOf(gdjs.Stage10Code.GDCarObjects4[j]) === -1 )
            gdjs.Stage10Code.GDCarObjects3_1final.push(gdjs.Stage10Code.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.Stage10Code.GDRoadUp2Objects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDRoadUp2Objects3_1final.indexOf(gdjs.Stage10Code.GDRoadUp2Objects4[j]) === -1 )
            gdjs.Stage10Code.GDRoadUp2Objects3_1final.push(gdjs.Stage10Code.GDRoadUp2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDCarObjects3_1final, gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadUpObjects3_1final, gdjs.Stage10Code.GDRoadUpObjects3);
gdjs.copyArray(gdjs.Stage10Code.GDRoadUp2Objects3_1final, gdjs.Stage10Code.GDRoadUp2Objects3);
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadRightObjects3Objects, true, runtimeScene, false);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDRoadLeftObjects3Objects, true, runtimeScene, true);
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].returnVariable(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")).setString("Up");
}
}}

}


{

gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects3[i].getVariableString(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")) == "Right" ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects3[k] = gdjs.Stage10Code.GDCarObjects3[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects3.length = k;}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.Stage10Code.GDRoadRightObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].rotateTowardAngle(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].setY((( gdjs.Stage10Code.GDRoadRightObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDRoadRightObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{

gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects3[i].getVariableString(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")) == "Down" ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects3[k] = gdjs.Stage10Code.GDCarObjects3[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects3.length = k;}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.Stage10Code.GDRoadDownObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].rotateTowardAngle(90, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].setX((( gdjs.Stage10Code.GDRoadDownObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDRoadDownObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{

gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects3[i].getVariableString(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")) == "Left" ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects3[k] = gdjs.Stage10Code.GDCarObjects3[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects3.length = k;}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.Stage10Code.GDRoadLeftObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].rotateTowardAngle(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].setY((( gdjs.Stage10Code.GDRoadLeftObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDRoadLeftObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityX(-(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed"))));
}
}}

}


{

gdjs.copyArray(gdjs.Stage10Code.GDCarObjects2, gdjs.Stage10Code.GDCarObjects3);


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects3[i].getVariableString(gdjs.Stage10Code.GDCarObjects3[i].getVariables().get("Direction")) == "Up" ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects3[k] = gdjs.Stage10Code.GDCarObjects3[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects3.length = k;}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.Stage10Code.GDRoadUpObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].rotateTowardAngle(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].setX((( gdjs.Stage10Code.GDRoadUpObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDRoadUpObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityY(-(1.5) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{



}


{

/* Reuse gdjs.Stage10Code.GDCarObjects2 */

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects2[i].getY() < 0 ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects2[k] = gdjs.Stage10Code.GDCarObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects2.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13417500);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects2 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Stage10Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects2[i].getVariableBoolean(gdjs.Stage10Code.GDCarObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects2[k] = gdjs.Stage10Code.GDCarObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects2.length = k;}if (gdjs.Stage10Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects1Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects1});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects1Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects1});
gdjs.Stage10Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects1);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects1Objects, "Physics2", gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects1Objects, false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDCarObjects1.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDCarObjects1[i].getVariableBoolean(gdjs.Stage10Code.GDCarObjects1[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Stage10Code.condition1IsTrue_0.val = true;
        gdjs.Stage10Code.GDCarObjects1[k] = gdjs.Stage10Code.GDCarObjects1[i];
        ++k;
    }
}
gdjs.Stage10Code.GDCarObjects1.length = k;}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition2IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13418932);
}
}}
}
if (gdjs.Stage10Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDCarObjects1 */
{for(var i = 0, len = gdjs.Stage10Code.GDCarObjects1.length ;i < len;++i) {
    gdjs.Stage10Code.GDCarObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 10, 10, 0, 0, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Metal_Sheets_Sledgehammer_Hit_02.aac", false, 100, 1);
}}

}


};gdjs.Stage10Code.eventsList24 = function(runtimeScene) {

{


gdjs.Stage10Code.eventsList20(runtimeScene);
}


{


gdjs.Stage10Code.eventsList22(runtimeScene);
}


{


gdjs.Stage10Code.eventsList23(runtimeScene);
}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects = Hashtable.newFrom({"PauseResumeButton": gdjs.Stage10Code.GDPauseResumeButtonObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(runtimeScene.getObjects("GamePausedText"), gdjs.Stage10Code.GDGamePausedTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Stage10Code.GDGrassBGObjects3);
gdjs.copyArray(runtimeScene.getObjects("HomeButton"), gdjs.Stage10Code.GDHomeButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.Stage10Code.GDNewTiledSpriteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Stage10Code.GDPauseBackgroundObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("PauseResumeButton"), gdjs.Stage10Code.GDPauseResumeButtonObjects3);

{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setPosition((( gdjs.Stage10Code.GDGrassBGObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects3[0].getWidth()) / 2 - 100,(( gdjs.Stage10Code.GDGrassBGObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects3[0].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setScale(0.125);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseBackgroundObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseBackgroundObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.Stage10Code.GDGamePausedTextObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDGamePausedTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.Stage10Code.GDHomeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDHomeButtonObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.Stage10Code.GDNewTiledSpriteObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDNewTiledSpriteObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setAnimation(1);
}
}{gdjs.physics2.setTimeScale(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, "Physics2", 0);
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "SecondsTimer");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("GamePaused"), true);
}}

}


};gdjs.Stage10Code.asyncCallback13421140 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Stage10Code.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Stage10Code.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage10Code.GDPauseResumeButtonObjects2) asyncObjectsList.addObject("PauseResumeButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Stage10Code.asyncCallback13421140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage10Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PauseResumeButton"), gdjs.Stage10Code.GDPauseResumeButtonObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
gdjs.Stage10Code.condition3IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("GamePaused"), false);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Stage10Code.condition2IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition3IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13420372);
}
}}
}
}
if (gdjs.Stage10Code.condition3IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects = Hashtable.newFrom({"PauseResumeButton": gdjs.Stage10Code.GDPauseResumeButtonObjects2});
gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.Stage10Code.GDCarObjects3});
gdjs.Stage10Code.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.Stage10Code.GDCarObjects3);
gdjs.copyArray(runtimeScene.getObjects("GamePausedText"), gdjs.Stage10Code.GDGamePausedTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBG"), gdjs.Stage10Code.GDGrassBGObjects3);
gdjs.copyArray(runtimeScene.getObjects("HomeButton"), gdjs.Stage10Code.GDHomeButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.Stage10Code.GDNewTiledSpriteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Stage10Code.GDPauseBackgroundObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("PauseResumeButton"), gdjs.Stage10Code.GDPauseResumeButtonObjects3);

{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setPosition((( gdjs.Stage10Code.GDGrassBGObjects3.length === 0 ) ? 0 :gdjs.Stage10Code.GDGrassBGObjects3[0].getWidth()) - 40,40);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setScale(0.075);
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseBackgroundObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseBackgroundObjects3[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDGamePausedTextObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDGamePausedTextObjects3[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDHomeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDHomeButtonObjects3[i].hide();
}
for(var i = 0, len = gdjs.Stage10Code.GDNewTiledSpriteObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDNewTiledSpriteObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Stage10Code.GDPauseResumeButtonObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDPauseResumeButtonObjects3[i].setAnimation(0);
}
}{gdjs.physics2.setTimeScale(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDCarObjects3Objects, "Physics2", 1);
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "SecondsTimer");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("GamePaused"), false);
}}

}


};gdjs.Stage10Code.asyncCallback13424140 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Stage10Code.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Stage10Code.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage10Code.GDPauseResumeButtonObjects2) asyncObjectsList.addObject("PauseResumeButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Stage10Code.asyncCallback13424140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage10Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PauseResumeButton"), gdjs.Stage10Code.GDPauseResumeButtonObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
gdjs.Stage10Code.condition3IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDPauseResumeButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("GamePaused"), true);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Stage10Code.condition2IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition3IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13424068);
}
}}
}
}
if (gdjs.Stage10Code.condition3IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDHomeButtonObjects1Objects = Hashtable.newFrom({"HomeButton": gdjs.Stage10Code.GDHomeButtonObjects1});
gdjs.Stage10Code.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TitleScreen", false);
}}

}


};gdjs.Stage10Code.asyncCallback13427052 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Stage10Code.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Stage10Code.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Stage10Code.asyncCallback13427052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage10Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HomeButton"), gdjs.Stage10Code.GDHomeButtonObjects1);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
gdjs.Stage10Code.condition2IsTrue_0.val = false;
gdjs.Stage10Code.condition3IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Stage10Code.mapOfGDgdjs_46Stage10Code_46GDHomeButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
gdjs.Stage10Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("GamePaused"), true);
}if ( gdjs.Stage10Code.condition1IsTrue_0.val ) {
{
gdjs.Stage10Code.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Stage10Code.condition2IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition3IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13426980);
}
}}
}
}
if (gdjs.Stage10Code.condition3IsTrue_0.val) {

{ //Subevents
gdjs.Stage10Code.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.Stage10Code.eventsList34 = function(runtimeScene) {

{


gdjs.Stage10Code.eventsList27(runtimeScene);
}


{


gdjs.Stage10Code.eventsList30(runtimeScene);
}


{


gdjs.Stage10Code.eventsList33(runtimeScene);
}


};gdjs.Stage10Code.eventsList35 = function(runtimeScene) {

{

gdjs.Stage10Code.GDLoadingObjects3.length = 0;


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.GDLoadingObjects3_1final.length = 0;gdjs.Stage10Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Loading"), gdjs.Stage10Code.GDLoadingObjects4);
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDLoadingObjects4.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDLoadingObjects4[i].getBehavior("Tween").hasFinished("LoadingIn") ) {
        gdjs.Stage10Code.condition0IsTrue_1.val = true;
        gdjs.Stage10Code.GDLoadingObjects4[k] = gdjs.Stage10Code.GDLoadingObjects4[i];
        ++k;
    }
}
gdjs.Stage10Code.GDLoadingObjects4.length = k;if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Stage10Code.GDLoadingObjects4.length;j<jLen;++j) {
        if ( gdjs.Stage10Code.GDLoadingObjects3_1final.indexOf(gdjs.Stage10Code.GDLoadingObjects4[j]) === -1 )
            gdjs.Stage10Code.GDLoadingObjects3_1final.push(gdjs.Stage10Code.GDLoadingObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage10Code.GDLoadingObjects3_1final, gdjs.Stage10Code.GDLoadingObjects3);
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13428868);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) + 20);
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.random(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)) - 1));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)))), false);
}{gdjs.evtTools.variable.variableRemoveAt(runtimeScene.getGame().getVariables().getFromIndex(0), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}}

}


{



}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = (gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0);
}
}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage1");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage2");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage3");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage4");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage5");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage6");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage7");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage8");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage9");
}}

}


};gdjs.Stage10Code.eventsList36 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
}
}
{
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("SceneTimeLeft")) <= 0;
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13433708);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TitleScreen", false);
}}

}


};gdjs.Stage10Code.eventsList37 = function(runtimeScene) {

{


gdjs.Stage10Code.eventsList35(runtimeScene);
}


{


gdjs.Stage10Code.eventsList36(runtimeScene);
}


};gdjs.Stage10Code.mapOfEmptyGDCarObjects = Hashtable.newFrom({"Car": []});
gdjs.Stage10Code.eventsList38 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Stage10Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Loading"), gdjs.Stage10Code.GDLoadingObjects3);
{for(var i = 0, len = gdjs.Stage10Code.GDLoadingObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDLoadingObjects3[i].getBehavior("Tween").addObjectOpacityTween("LoadingOut", 0, "easeInQuad", 750, false);
}
}}

}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition0IsTrue_0;
gdjs.Stage10Code.condition0IsTrue_1.val = false;
gdjs.Stage10Code.condition1IsTrue_1.val = false;
{
gdjs.Stage10Code.condition0IsTrue_1.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage10Code.mapOfEmptyGDCarObjects) == 0;
if( gdjs.Stage10Code.condition0IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
}
}
{
gdjs.Stage10Code.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
if( gdjs.Stage10Code.condition1IsTrue_1.val ) {
    gdjs.Stage10Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13438716);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Loading"), gdjs.Stage10Code.GDLoadingObjects3);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "SecondsTimer");
}{for(var i = 0, len = gdjs.Stage10Code.GDLoadingObjects3.length ;i < len;++i) {
    gdjs.Stage10Code.GDLoadingObjects3[i].getBehavior("Tween").addObjectOpacityTween("LoadingIn", 255, "easeInQuad", 750, false);
}
}}

}


{



}


};gdjs.Stage10Code.eventsList39 = function(runtimeScene) {

{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13440724);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.Stage10Code.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.Stage10Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDTutorialTextObjects2[i].getBehavior("Tween").addObjectOpacityTween("TutorialOut", 100, "easeInQuad", 1000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.Stage10Code.GDTutorialTextObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDTutorialTextObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDTutorialTextObjects2[i].getBehavior("Tween").hasFinished("TutorialOut") ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDTutorialTextObjects2[k] = gdjs.Stage10Code.GDTutorialTextObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDTutorialTextObjects2.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13441804);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDTutorialTextObjects2 */
{for(var i = 0, len = gdjs.Stage10Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDTutorialTextObjects2[i].getBehavior("Tween").addObjectOpacityTween("TutorialIn", 255, "easeInQuad", 1000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.Stage10Code.GDTutorialTextObjects2);

gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Stage10Code.GDTutorialTextObjects2.length;i<l;++i) {
    if ( gdjs.Stage10Code.GDTutorialTextObjects2[i].getBehavior("Tween").hasFinished("TutorialIn") ) {
        gdjs.Stage10Code.condition0IsTrue_0.val = true;
        gdjs.Stage10Code.GDTutorialTextObjects2[k] = gdjs.Stage10Code.GDTutorialTextObjects2[i];
        ++k;
    }
}
gdjs.Stage10Code.GDTutorialTextObjects2.length = k;}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13442812);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Stage10Code.GDTutorialTextObjects2 */
{for(var i = 0, len = gdjs.Stage10Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.Stage10Code.GDTutorialTextObjects2[i].getBehavior("Tween").addObjectOpacityTween("TutorialOut", 100, "easeInQuad", 1000, false);
}
}}

}


{


gdjs.Stage10Code.condition0IsTrue_0.val = false;
gdjs.Stage10Code.condition1IsTrue_0.val = false;
{
gdjs.Stage10Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), false);
}if ( gdjs.Stage10Code.condition0IsTrue_0.val ) {
{
{gdjs.Stage10Code.conditionTrue_1 = gdjs.Stage10Code.condition1IsTrue_0;
gdjs.Stage10Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13443644);
}
}}
if (gdjs.Stage10Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.Stage10Code.GDTutorialTextObjects1);
{for(var i = 0, len = gdjs.Stage10Code.GDTutorialTextObjects1.length ;i < len;++i) {
    gdjs.Stage10Code.GDTutorialTextObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Stage10Code.eventsList40 = function(runtimeScene) {

{



}


{


gdjs.Stage10Code.eventsList38(runtimeScene);
}


{


gdjs.Stage10Code.eventsList39(runtimeScene);
}


};gdjs.Stage10Code.eventsList41 = function(runtimeScene) {

{


{
}

}


{



}


{


gdjs.Stage10Code.eventsList10(runtimeScene);
}


{


gdjs.Stage10Code.eventsList11(runtimeScene);
}


{


gdjs.Stage10Code.eventsList13(runtimeScene);
}


{


gdjs.Stage10Code.eventsList18(runtimeScene);
}


{


gdjs.Stage10Code.eventsList24(runtimeScene);
}


{


gdjs.Stage10Code.eventsList34(runtimeScene);
}


{


gdjs.Stage10Code.eventsList37(runtimeScene);
}


{


gdjs.Stage10Code.eventsList40(runtimeScene);
}


};

gdjs.Stage10Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Stage10Code.GDPauseResumeButtonObjects1.length = 0;
gdjs.Stage10Code.GDPauseResumeButtonObjects2.length = 0;
gdjs.Stage10Code.GDPauseResumeButtonObjects3.length = 0;
gdjs.Stage10Code.GDPauseResumeButtonObjects4.length = 0;
gdjs.Stage10Code.GDPauseResumeButtonObjects5.length = 0;
gdjs.Stage10Code.GDPauseBackgroundObjects1.length = 0;
gdjs.Stage10Code.GDPauseBackgroundObjects2.length = 0;
gdjs.Stage10Code.GDPauseBackgroundObjects3.length = 0;
gdjs.Stage10Code.GDPauseBackgroundObjects4.length = 0;
gdjs.Stage10Code.GDPauseBackgroundObjects5.length = 0;
gdjs.Stage10Code.GDGamePausedTextObjects1.length = 0;
gdjs.Stage10Code.GDGamePausedTextObjects2.length = 0;
gdjs.Stage10Code.GDGamePausedTextObjects3.length = 0;
gdjs.Stage10Code.GDGamePausedTextObjects4.length = 0;
gdjs.Stage10Code.GDGamePausedTextObjects5.length = 0;
gdjs.Stage10Code.GDHomeButtonObjects1.length = 0;
gdjs.Stage10Code.GDHomeButtonObjects2.length = 0;
gdjs.Stage10Code.GDHomeButtonObjects3.length = 0;
gdjs.Stage10Code.GDHomeButtonObjects4.length = 0;
gdjs.Stage10Code.GDHomeButtonObjects5.length = 0;
gdjs.Stage10Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Stage10Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Stage10Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.Stage10Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.Stage10Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.Stage10Code.GDObstacleObjects1.length = 0;
gdjs.Stage10Code.GDObstacleObjects2.length = 0;
gdjs.Stage10Code.GDObstacleObjects3.length = 0;
gdjs.Stage10Code.GDObstacleObjects4.length = 0;
gdjs.Stage10Code.GDObstacleObjects5.length = 0;
gdjs.Stage10Code.GDTutorialTextObjects1.length = 0;
gdjs.Stage10Code.GDTutorialTextObjects2.length = 0;
gdjs.Stage10Code.GDTutorialTextObjects3.length = 0;
gdjs.Stage10Code.GDTutorialTextObjects4.length = 0;
gdjs.Stage10Code.GDTutorialTextObjects5.length = 0;
gdjs.Stage10Code.GDRoadRightObjects1.length = 0;
gdjs.Stage10Code.GDRoadRightObjects2.length = 0;
gdjs.Stage10Code.GDRoadRightObjects3.length = 0;
gdjs.Stage10Code.GDRoadRightObjects4.length = 0;
gdjs.Stage10Code.GDRoadRightObjects5.length = 0;
gdjs.Stage10Code.GDRoadRight2Objects1.length = 0;
gdjs.Stage10Code.GDRoadRight2Objects2.length = 0;
gdjs.Stage10Code.GDRoadRight2Objects3.length = 0;
gdjs.Stage10Code.GDRoadRight2Objects4.length = 0;
gdjs.Stage10Code.GDRoadRight2Objects5.length = 0;
gdjs.Stage10Code.GDRoadDownObjects1.length = 0;
gdjs.Stage10Code.GDRoadDownObjects2.length = 0;
gdjs.Stage10Code.GDRoadDownObjects3.length = 0;
gdjs.Stage10Code.GDRoadDownObjects4.length = 0;
gdjs.Stage10Code.GDRoadDownObjects5.length = 0;
gdjs.Stage10Code.GDRoadDown2Objects1.length = 0;
gdjs.Stage10Code.GDRoadDown2Objects2.length = 0;
gdjs.Stage10Code.GDRoadDown2Objects3.length = 0;
gdjs.Stage10Code.GDRoadDown2Objects4.length = 0;
gdjs.Stage10Code.GDRoadDown2Objects5.length = 0;
gdjs.Stage10Code.GDRoadLeftObjects1.length = 0;
gdjs.Stage10Code.GDRoadLeftObjects2.length = 0;
gdjs.Stage10Code.GDRoadLeftObjects3.length = 0;
gdjs.Stage10Code.GDRoadLeftObjects4.length = 0;
gdjs.Stage10Code.GDRoadLeftObjects5.length = 0;
gdjs.Stage10Code.GDRoadLeft2Objects1.length = 0;
gdjs.Stage10Code.GDRoadLeft2Objects2.length = 0;
gdjs.Stage10Code.GDRoadLeft2Objects3.length = 0;
gdjs.Stage10Code.GDRoadLeft2Objects4.length = 0;
gdjs.Stage10Code.GDRoadLeft2Objects5.length = 0;
gdjs.Stage10Code.GDRoadUpObjects1.length = 0;
gdjs.Stage10Code.GDRoadUpObjects2.length = 0;
gdjs.Stage10Code.GDRoadUpObjects3.length = 0;
gdjs.Stage10Code.GDRoadUpObjects4.length = 0;
gdjs.Stage10Code.GDRoadUpObjects5.length = 0;
gdjs.Stage10Code.GDRoadUp2Objects1.length = 0;
gdjs.Stage10Code.GDRoadUp2Objects2.length = 0;
gdjs.Stage10Code.GDRoadUp2Objects3.length = 0;
gdjs.Stage10Code.GDRoadUp2Objects4.length = 0;
gdjs.Stage10Code.GDRoadUp2Objects5.length = 0;
gdjs.Stage10Code.GDCarObjects1.length = 0;
gdjs.Stage10Code.GDCarObjects2.length = 0;
gdjs.Stage10Code.GDCarObjects3.length = 0;
gdjs.Stage10Code.GDCarObjects4.length = 0;
gdjs.Stage10Code.GDCarObjects5.length = 0;
gdjs.Stage10Code.GDGrassObjects1.length = 0;
gdjs.Stage10Code.GDGrassObjects2.length = 0;
gdjs.Stage10Code.GDGrassObjects3.length = 0;
gdjs.Stage10Code.GDGrassObjects4.length = 0;
gdjs.Stage10Code.GDGrassObjects5.length = 0;
gdjs.Stage10Code.GDObstacleObjects1.length = 0;
gdjs.Stage10Code.GDObstacleObjects2.length = 0;
gdjs.Stage10Code.GDObstacleObjects3.length = 0;
gdjs.Stage10Code.GDObstacleObjects4.length = 0;
gdjs.Stage10Code.GDObstacleObjects5.length = 0;
gdjs.Stage10Code.GDGrassBGObjects1.length = 0;
gdjs.Stage10Code.GDGrassBGObjects2.length = 0;
gdjs.Stage10Code.GDGrassBGObjects3.length = 0;
gdjs.Stage10Code.GDGrassBGObjects4.length = 0;
gdjs.Stage10Code.GDGrassBGObjects5.length = 0;
gdjs.Stage10Code.GDDecorObjects1.length = 0;
gdjs.Stage10Code.GDDecorObjects2.length = 0;
gdjs.Stage10Code.GDDecorObjects3.length = 0;
gdjs.Stage10Code.GDDecorObjects4.length = 0;
gdjs.Stage10Code.GDDecorObjects5.length = 0;
gdjs.Stage10Code.GDTimerObjects1.length = 0;
gdjs.Stage10Code.GDTimerObjects2.length = 0;
gdjs.Stage10Code.GDTimerObjects3.length = 0;
gdjs.Stage10Code.GDTimerObjects4.length = 0;
gdjs.Stage10Code.GDTimerObjects5.length = 0;
gdjs.Stage10Code.GDStageClearedObjects1.length = 0;
gdjs.Stage10Code.GDStageClearedObjects2.length = 0;
gdjs.Stage10Code.GDStageClearedObjects3.length = 0;
gdjs.Stage10Code.GDStageClearedObjects4.length = 0;
gdjs.Stage10Code.GDStageClearedObjects5.length = 0;
gdjs.Stage10Code.GDNewTextObjects1.length = 0;
gdjs.Stage10Code.GDNewTextObjects2.length = 0;
gdjs.Stage10Code.GDNewTextObjects3.length = 0;
gdjs.Stage10Code.GDNewTextObjects4.length = 0;
gdjs.Stage10Code.GDNewTextObjects5.length = 0;
gdjs.Stage10Code.GDLoadingObjects1.length = 0;
gdjs.Stage10Code.GDLoadingObjects2.length = 0;
gdjs.Stage10Code.GDLoadingObjects3.length = 0;
gdjs.Stage10Code.GDLoadingObjects4.length = 0;
gdjs.Stage10Code.GDLoadingObjects5.length = 0;

gdjs.Stage10Code.eventsList41(runtimeScene);
return;

}

gdjs['Stage10Code'] = gdjs.Stage10Code;
