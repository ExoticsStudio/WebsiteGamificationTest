gdjs.TitleScreenCode = {};
gdjs.TitleScreenCode.GDCarObjects3_1final = [];

gdjs.TitleScreenCode.GDRoadDown2Objects3_1final = [];

gdjs.TitleScreenCode.GDRoadDownObjects3_1final = [];

gdjs.TitleScreenCode.GDRoadLeft2Objects3_1final = [];

gdjs.TitleScreenCode.GDRoadLeftObjects3_1final = [];

gdjs.TitleScreenCode.GDRoadRight2Objects3_1final = [];

gdjs.TitleScreenCode.GDRoadRightObjects3_1final = [];

gdjs.TitleScreenCode.GDRoadUp2Objects3_1final = [];

gdjs.TitleScreenCode.GDRoadUpObjects3_1final = [];

gdjs.TitleScreenCode.GDPauseResumeButtonObjects1= [];
gdjs.TitleScreenCode.GDPauseResumeButtonObjects2= [];
gdjs.TitleScreenCode.GDPauseResumeButtonObjects3= [];
gdjs.TitleScreenCode.GDPauseResumeButtonObjects4= [];
gdjs.TitleScreenCode.GDPauseBackgroundObjects1= [];
gdjs.TitleScreenCode.GDPauseBackgroundObjects2= [];
gdjs.TitleScreenCode.GDPauseBackgroundObjects3= [];
gdjs.TitleScreenCode.GDPauseBackgroundObjects4= [];
gdjs.TitleScreenCode.GDGamePausedTextObjects1= [];
gdjs.TitleScreenCode.GDGamePausedTextObjects2= [];
gdjs.TitleScreenCode.GDGamePausedTextObjects3= [];
gdjs.TitleScreenCode.GDGamePausedTextObjects4= [];
gdjs.TitleScreenCode.GDHomeButtonObjects1= [];
gdjs.TitleScreenCode.GDHomeButtonObjects2= [];
gdjs.TitleScreenCode.GDHomeButtonObjects3= [];
gdjs.TitleScreenCode.GDHomeButtonObjects4= [];
gdjs.TitleScreenCode.GDNewTiledSpriteObjects1= [];
gdjs.TitleScreenCode.GDNewTiledSpriteObjects2= [];
gdjs.TitleScreenCode.GDNewTiledSpriteObjects3= [];
gdjs.TitleScreenCode.GDNewTiledSpriteObjects4= [];
gdjs.TitleScreenCode.GDObstacleObjects1= [];
gdjs.TitleScreenCode.GDObstacleObjects2= [];
gdjs.TitleScreenCode.GDObstacleObjects3= [];
gdjs.TitleScreenCode.GDObstacleObjects4= [];
gdjs.TitleScreenCode.GDTutorialTextObjects1= [];
gdjs.TitleScreenCode.GDTutorialTextObjects2= [];
gdjs.TitleScreenCode.GDTutorialTextObjects3= [];
gdjs.TitleScreenCode.GDTutorialTextObjects4= [];
gdjs.TitleScreenCode.GDRoadRightObjects1= [];
gdjs.TitleScreenCode.GDRoadRightObjects2= [];
gdjs.TitleScreenCode.GDRoadRightObjects3= [];
gdjs.TitleScreenCode.GDRoadRightObjects4= [];
gdjs.TitleScreenCode.GDRoadRight2Objects1= [];
gdjs.TitleScreenCode.GDRoadRight2Objects2= [];
gdjs.TitleScreenCode.GDRoadRight2Objects3= [];
gdjs.TitleScreenCode.GDRoadRight2Objects4= [];
gdjs.TitleScreenCode.GDRoadDownObjects1= [];
gdjs.TitleScreenCode.GDRoadDownObjects2= [];
gdjs.TitleScreenCode.GDRoadDownObjects3= [];
gdjs.TitleScreenCode.GDRoadDownObjects4= [];
gdjs.TitleScreenCode.GDRoadDown2Objects1= [];
gdjs.TitleScreenCode.GDRoadDown2Objects2= [];
gdjs.TitleScreenCode.GDRoadDown2Objects3= [];
gdjs.TitleScreenCode.GDRoadDown2Objects4= [];
gdjs.TitleScreenCode.GDRoadLeftObjects1= [];
gdjs.TitleScreenCode.GDRoadLeftObjects2= [];
gdjs.TitleScreenCode.GDRoadLeftObjects3= [];
gdjs.TitleScreenCode.GDRoadLeftObjects4= [];
gdjs.TitleScreenCode.GDRoadLeft2Objects1= [];
gdjs.TitleScreenCode.GDRoadLeft2Objects2= [];
gdjs.TitleScreenCode.GDRoadLeft2Objects3= [];
gdjs.TitleScreenCode.GDRoadLeft2Objects4= [];
gdjs.TitleScreenCode.GDRoadUpObjects1= [];
gdjs.TitleScreenCode.GDRoadUpObjects2= [];
gdjs.TitleScreenCode.GDRoadUpObjects3= [];
gdjs.TitleScreenCode.GDRoadUpObjects4= [];
gdjs.TitleScreenCode.GDRoadUp2Objects1= [];
gdjs.TitleScreenCode.GDRoadUp2Objects2= [];
gdjs.TitleScreenCode.GDRoadUp2Objects3= [];
gdjs.TitleScreenCode.GDRoadUp2Objects4= [];
gdjs.TitleScreenCode.GDCarObjects1= [];
gdjs.TitleScreenCode.GDCarObjects2= [];
gdjs.TitleScreenCode.GDCarObjects3= [];
gdjs.TitleScreenCode.GDCarObjects4= [];
gdjs.TitleScreenCode.GDButtonObjects1= [];
gdjs.TitleScreenCode.GDButtonObjects2= [];
gdjs.TitleScreenCode.GDButtonObjects3= [];
gdjs.TitleScreenCode.GDButtonObjects4= [];
gdjs.TitleScreenCode.GDTitleLogoObjects1= [];
gdjs.TitleScreenCode.GDTitleLogoObjects2= [];
gdjs.TitleScreenCode.GDTitleLogoObjects3= [];
gdjs.TitleScreenCode.GDTitleLogoObjects4= [];
gdjs.TitleScreenCode.GDGrassBGObjects1= [];
gdjs.TitleScreenCode.GDGrassBGObjects2= [];
gdjs.TitleScreenCode.GDGrassBGObjects3= [];
gdjs.TitleScreenCode.GDGrassBGObjects4= [];
gdjs.TitleScreenCode.GDWhiteBGObjects1= [];
gdjs.TitleScreenCode.GDWhiteBGObjects2= [];
gdjs.TitleScreenCode.GDWhiteBGObjects3= [];
gdjs.TitleScreenCode.GDWhiteBGObjects4= [];

gdjs.TitleScreenCode.conditionTrue_0 = {val:false};
gdjs.TitleScreenCode.condition0IsTrue_0 = {val:false};
gdjs.TitleScreenCode.condition1IsTrue_0 = {val:false};
gdjs.TitleScreenCode.condition2IsTrue_0 = {val:false};
gdjs.TitleScreenCode.condition3IsTrue_0 = {val:false};
gdjs.TitleScreenCode.conditionTrue_1 = {val:false};
gdjs.TitleScreenCode.condition0IsTrue_1 = {val:false};
gdjs.TitleScreenCode.condition1IsTrue_1 = {val:false};
gdjs.TitleScreenCode.condition2IsTrue_1 = {val:false};
gdjs.TitleScreenCode.condition3IsTrue_1 = {val:false};


gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDButtonObjects1Objects = Hashtable.newFrom({"Button": gdjs.TitleScreenCode.GDButtonObjects1});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects4Objects = Hashtable.newFrom({"RoadRight": gdjs.TitleScreenCode.GDRoadRightObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRight2Objects4Objects = Hashtable.newFrom({"RoadRight2": gdjs.TitleScreenCode.GDRoadRight2Objects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects3Objects = Hashtable.newFrom({"RoadDown": gdjs.TitleScreenCode.GDRoadDownObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects3Objects = Hashtable.newFrom({"RoadUp": gdjs.TitleScreenCode.GDRoadUpObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects4Objects = Hashtable.newFrom({"RoadDown": gdjs.TitleScreenCode.GDRoadDownObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDown2Objects4Objects = Hashtable.newFrom({"RoadDown2": gdjs.TitleScreenCode.GDRoadDown2Objects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects3Objects = Hashtable.newFrom({"RoadRight": gdjs.TitleScreenCode.GDRoadRightObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects3Objects = Hashtable.newFrom({"RoadLeft": gdjs.TitleScreenCode.GDRoadLeftObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects4Objects = Hashtable.newFrom({"RoadLeft": gdjs.TitleScreenCode.GDRoadLeftObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeft2Objects4Objects = Hashtable.newFrom({"RoadLeft2": gdjs.TitleScreenCode.GDRoadLeft2Objects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects3Objects = Hashtable.newFrom({"RoadDown": gdjs.TitleScreenCode.GDRoadDownObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects3Objects = Hashtable.newFrom({"RoadUp": gdjs.TitleScreenCode.GDRoadUpObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects4Objects = Hashtable.newFrom({"RoadUp": gdjs.TitleScreenCode.GDRoadUpObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUp2Objects4Objects = Hashtable.newFrom({"RoadUp2": gdjs.TitleScreenCode.GDRoadUp2Objects4});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects3Objects = Hashtable.newFrom({"RoadRight": gdjs.TitleScreenCode.GDRoadRightObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects = Hashtable.newFrom({"Car": gdjs.TitleScreenCode.GDCarObjects3});
gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects3Objects = Hashtable.newFrom({"RoadLeft": gdjs.TitleScreenCode.GDRoadLeftObjects3});
gdjs.TitleScreenCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.TitleScreenCode.GDRoadDownObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.TitleScreenCode.GDRoadUpObjects3);
gdjs.TitleScreenCode.GDCarObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadRightObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadRight2Objects3.length = 0;


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
gdjs.TitleScreenCode.condition2IsTrue_0.val = false;
{
{gdjs.TitleScreenCode.conditionTrue_1 = gdjs.TitleScreenCode.condition0IsTrue_0;
gdjs.TitleScreenCode.GDCarObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadRightObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadRight2Objects3_1final.length = 0;gdjs.TitleScreenCode.condition0IsTrue_1.val = false;
gdjs.TitleScreenCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.TitleScreenCode.GDRoadRightObjects4);
gdjs.TitleScreenCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition0IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadRightObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadRightObjects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadRightObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadRightObjects3_1final.push(gdjs.TitleScreenCode.GDRoadRightObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadRight2"), gdjs.TitleScreenCode.GDRoadRight2Objects4);
gdjs.TitleScreenCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRight2Objects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition1IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadRight2Objects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadRight2Objects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadRight2Objects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadRight2Objects3_1final.push(gdjs.TitleScreenCode.GDRoadRight2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TitleScreenCode.GDCarObjects3_1final, gdjs.TitleScreenCode.GDCarObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadRightObjects3_1final, gdjs.TitleScreenCode.GDRoadRightObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadRight2Objects3_1final, gdjs.TitleScreenCode.GDRoadRight2Objects3);
}
}
}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects3Objects, true, runtimeScene, false);
}if ( gdjs.TitleScreenCode.condition1IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects3Objects, true, runtimeScene, false);
}}
}
if (gdjs.TitleScreenCode.condition2IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].returnVariable(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")).setString("Right");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.TitleScreenCode.GDRoadLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.TitleScreenCode.GDRoadRightObjects3);
gdjs.TitleScreenCode.GDCarObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadDownObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadDown2Objects3.length = 0;


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
gdjs.TitleScreenCode.condition2IsTrue_0.val = false;
{
{gdjs.TitleScreenCode.conditionTrue_1 = gdjs.TitleScreenCode.condition0IsTrue_0;
gdjs.TitleScreenCode.GDCarObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadDownObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadDown2Objects3_1final.length = 0;gdjs.TitleScreenCode.condition0IsTrue_1.val = false;
gdjs.TitleScreenCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.TitleScreenCode.GDRoadDownObjects4);
gdjs.TitleScreenCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition0IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadDownObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadDownObjects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadDownObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadDownObjects3_1final.push(gdjs.TitleScreenCode.GDRoadDownObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadDown2"), gdjs.TitleScreenCode.GDRoadDown2Objects4);
gdjs.TitleScreenCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDown2Objects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition1IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadDown2Objects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadDown2Objects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadDown2Objects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadDown2Objects3_1final.push(gdjs.TitleScreenCode.GDRoadDown2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TitleScreenCode.GDCarObjects3_1final, gdjs.TitleScreenCode.GDCarObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadDownObjects3_1final, gdjs.TitleScreenCode.GDRoadDownObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadDown2Objects3_1final, gdjs.TitleScreenCode.GDRoadDown2Objects3);
}
}
}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects3Objects, true, runtimeScene, false);
}if ( gdjs.TitleScreenCode.condition1IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects3Objects, true, runtimeScene, true);
}}
}
if (gdjs.TitleScreenCode.condition2IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].returnVariable(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")).setString("Down");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.TitleScreenCode.GDRoadDownObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.TitleScreenCode.GDRoadUpObjects3);
gdjs.TitleScreenCode.GDCarObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadLeftObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadLeft2Objects3.length = 0;


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
gdjs.TitleScreenCode.condition2IsTrue_0.val = false;
{
{gdjs.TitleScreenCode.conditionTrue_1 = gdjs.TitleScreenCode.condition0IsTrue_0;
gdjs.TitleScreenCode.GDCarObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadLeftObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadLeft2Objects3_1final.length = 0;gdjs.TitleScreenCode.condition0IsTrue_1.val = false;
gdjs.TitleScreenCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.TitleScreenCode.GDRoadLeftObjects4);
gdjs.TitleScreenCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects4Objects, false, runtimeScene, true);
if( gdjs.TitleScreenCode.condition0IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadLeftObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadLeftObjects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadLeftObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadLeftObjects3_1final.push(gdjs.TitleScreenCode.GDRoadLeftObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadLeft2"), gdjs.TitleScreenCode.GDRoadLeft2Objects4);
gdjs.TitleScreenCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeft2Objects4Objects, false, runtimeScene, true);
if( gdjs.TitleScreenCode.condition1IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadLeft2Objects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadLeft2Objects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadLeft2Objects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadLeft2Objects3_1final.push(gdjs.TitleScreenCode.GDRoadLeft2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TitleScreenCode.GDCarObjects3_1final, gdjs.TitleScreenCode.GDCarObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadLeftObjects3_1final, gdjs.TitleScreenCode.GDRoadLeftObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadLeft2Objects3_1final, gdjs.TitleScreenCode.GDRoadLeft2Objects3);
}
}
}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadDownObjects3Objects, true, runtimeScene, false);
}if ( gdjs.TitleScreenCode.condition1IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects3Objects, true, runtimeScene, false);
}}
}
if (gdjs.TitleScreenCode.condition2IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].returnVariable(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")).setString("Left");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.TitleScreenCode.GDRoadLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.TitleScreenCode.GDRoadRightObjects3);
gdjs.TitleScreenCode.GDCarObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadUpObjects3.length = 0;

gdjs.TitleScreenCode.GDRoadUp2Objects3.length = 0;


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
gdjs.TitleScreenCode.condition2IsTrue_0.val = false;
{
{gdjs.TitleScreenCode.conditionTrue_1 = gdjs.TitleScreenCode.condition0IsTrue_0;
gdjs.TitleScreenCode.GDCarObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadUpObjects3_1final.length = 0;gdjs.TitleScreenCode.GDRoadUp2Objects3_1final.length = 0;gdjs.TitleScreenCode.condition0IsTrue_1.val = false;
gdjs.TitleScreenCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.TitleScreenCode.GDRoadUpObjects4);
gdjs.TitleScreenCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUpObjects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition0IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadUpObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadUpObjects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadUpObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadUpObjects3_1final.push(gdjs.TitleScreenCode.GDRoadUpObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects4);
gdjs.copyArray(runtimeScene.getObjects("RoadUp2"), gdjs.TitleScreenCode.GDRoadUp2Objects4);
gdjs.TitleScreenCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects4Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadUp2Objects4Objects, false, runtimeScene, false);
if( gdjs.TitleScreenCode.condition1IsTrue_1.val ) {
    gdjs.TitleScreenCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDCarObjects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDCarObjects3_1final.indexOf(gdjs.TitleScreenCode.GDCarObjects4[j]) === -1 )
            gdjs.TitleScreenCode.GDCarObjects3_1final.push(gdjs.TitleScreenCode.GDCarObjects4[j]);
    }
    for(var j = 0, jLen = gdjs.TitleScreenCode.GDRoadUp2Objects4.length;j<jLen;++j) {
        if ( gdjs.TitleScreenCode.GDRoadUp2Objects3_1final.indexOf(gdjs.TitleScreenCode.GDRoadUp2Objects4[j]) === -1 )
            gdjs.TitleScreenCode.GDRoadUp2Objects3_1final.push(gdjs.TitleScreenCode.GDRoadUp2Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TitleScreenCode.GDCarObjects3_1final, gdjs.TitleScreenCode.GDCarObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadUpObjects3_1final, gdjs.TitleScreenCode.GDRoadUpObjects3);
gdjs.copyArray(gdjs.TitleScreenCode.GDRoadUp2Objects3_1final, gdjs.TitleScreenCode.GDRoadUp2Objects3);
}
}
}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadRightObjects3Objects, true, runtimeScene, false);
}if ( gdjs.TitleScreenCode.condition1IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDCarObjects3Objects, gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDRoadLeftObjects3Objects, true, runtimeScene, true);
}}
}
if (gdjs.TitleScreenCode.condition2IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].returnVariable(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")).setString("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects3);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TitleScreenCode.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.TitleScreenCode.GDCarObjects3[i].getVariableString(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")) == "Right" ) {
        gdjs.TitleScreenCode.condition0IsTrue_0.val = true;
        gdjs.TitleScreenCode.GDCarObjects3[k] = gdjs.TitleScreenCode.GDCarObjects3[i];
        ++k;
    }
}
gdjs.TitleScreenCode.GDCarObjects3.length = k;}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadRight"), gdjs.TitleScreenCode.GDRoadRightObjects3);
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].rotateTowardAngle(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].setY((( gdjs.TitleScreenCode.GDRoadRightObjects3.length === 0 ) ? 0 :gdjs.TitleScreenCode.GDRoadRightObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects3);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TitleScreenCode.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.TitleScreenCode.GDCarObjects3[i].getVariableString(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")) == "Down" ) {
        gdjs.TitleScreenCode.condition0IsTrue_0.val = true;
        gdjs.TitleScreenCode.GDCarObjects3[k] = gdjs.TitleScreenCode.GDCarObjects3[i];
        ++k;
    }
}
gdjs.TitleScreenCode.GDCarObjects3.length = k;}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadDown"), gdjs.TitleScreenCode.GDRoadDownObjects3);
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].rotateTowardAngle(90, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].setX((( gdjs.TitleScreenCode.GDRoadDownObjects3.length === 0 ) ? 0 :gdjs.TitleScreenCode.GDRoadDownObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects3);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TitleScreenCode.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.TitleScreenCode.GDCarObjects3[i].getVariableString(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")) == "Left" ) {
        gdjs.TitleScreenCode.condition0IsTrue_0.val = true;
        gdjs.TitleScreenCode.GDCarObjects3[k] = gdjs.TitleScreenCode.GDCarObjects3[i];
        ++k;
    }
}
gdjs.TitleScreenCode.GDCarObjects3.length = k;}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadLeft"), gdjs.TitleScreenCode.GDRoadLeftObjects3);
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].rotateTowardAngle(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].setY((( gdjs.TitleScreenCode.GDRoadLeftObjects3.length === 0 ) ? 0 :gdjs.TitleScreenCode.GDRoadLeftObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityX(-(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects3);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TitleScreenCode.GDCarObjects3.length;i<l;++i) {
    if ( gdjs.TitleScreenCode.GDCarObjects3[i].getVariableString(gdjs.TitleScreenCode.GDCarObjects3[i].getVariables().get("Direction")) == "Up" ) {
        gdjs.TitleScreenCode.condition0IsTrue_0.val = true;
        gdjs.TitleScreenCode.GDCarObjects3[k] = gdjs.TitleScreenCode.GDCarObjects3[i];
        ++k;
    }
}
gdjs.TitleScreenCode.GDCarObjects3.length = k;}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RoadUp"), gdjs.TitleScreenCode.GDRoadUpObjects3);
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].rotateTowardAngle(270, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("RotationSpeed")), runtimeScene);
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].setX((( gdjs.TitleScreenCode.GDRoadUpObjects3.length === 0 ) ? 0 :gdjs.TitleScreenCode.GDRoadUpObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects3.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects3[i].getBehavior("Physics2").setLinearVelocityY(-(1.5) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DrivingSpeed")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects2);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.TitleScreenCode.GDCarObjects2.length;i<l;++i) {
    if ( gdjs.TitleScreenCode.GDCarObjects2[i].getY() < 0 ) {
        gdjs.TitleScreenCode.condition0IsTrue_0.val = true;
        gdjs.TitleScreenCode.GDCarObjects2[k] = gdjs.TitleScreenCode.GDCarObjects2[i];
        ++k;
    }
}
gdjs.TitleScreenCode.GDCarObjects2.length = k;}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.TitleScreenCode.conditionTrue_1 = gdjs.TitleScreenCode.condition1IsTrue_0;
gdjs.TitleScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12980108);
}
}}
if (gdjs.TitleScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.TitleScreenCode.GDCarObjects2 */
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects2.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TitleScreenCode.eventsList1 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.TitleScreenCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.TitleScreenCode.eventsList2 = function(runtimeScene) {

{


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
gdjs.TitleScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("DrivingSpeed").setNumber(250);
}{runtimeScene.getVariables().get("RotationSpeed").setNumber(200);
}}

}


};gdjs.TitleScreenCode.eventsList3 = function(runtimeScene) {

{


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
gdjs.TitleScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Car"), gdjs.TitleScreenCode.GDCarObjects1);
{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects1.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects1[i].setAnimationFrame(gdjs.randomInRange(0, 8));
}
}{for(var i = 0, len = gdjs.TitleScreenCode.GDCarObjects1.length ;i < len;++i) {
    gdjs.TitleScreenCode.GDCarObjects1[i].pauseAnimation();
}
}}

}


};gdjs.TitleScreenCode.eventsList4 = function(runtimeScene) {

{


gdjs.TitleScreenCode.eventsList1(runtimeScene);
}


{


gdjs.TitleScreenCode.eventsList2(runtimeScene);
}


{


gdjs.TitleScreenCode.eventsList3(runtimeScene);
}


};gdjs.TitleScreenCode.eventsList5 = function(runtimeScene) {

{



}


{


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
gdjs.TitleScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("CurrentURL").setString(gdjs.evtsExt__URLTools__CurrentURL.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().get("Param_ContractID").setString(gdjs.evtsExt__URLTools__URLQueryStringParameter.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("CurrentURL")), "ContractID", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().get("Username").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Param_ContractID")));
}}

}


};gdjs.TitleScreenCode.eventsList6 = function(runtimeScene) {

{


gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
{
gdjs.TitleScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TitleScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4), true);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(45);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(0));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage1");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage2");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage3");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage4");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage5");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage6");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage7");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage8");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(0), "Stage9");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.TitleScreenCode.GDButtonObjects1);

gdjs.TitleScreenCode.condition0IsTrue_0.val = false;
gdjs.TitleScreenCode.condition1IsTrue_0.val = false;
{
gdjs.TitleScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TitleScreenCode.mapOfGDgdjs_46TitleScreenCode_46GDButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TitleScreenCode.condition0IsTrue_0.val ) {
{
gdjs.TitleScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.TitleScreenCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.random(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)) - 1));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)))), false);
}{gdjs.evtTools.variable.variableRemoveAt(runtimeScene.getGame().getVariables().getFromIndex(0), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}}

}


{


gdjs.TitleScreenCode.eventsList4(runtimeScene);
}


{


gdjs.TitleScreenCode.eventsList5(runtimeScene);
}


};

gdjs.TitleScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TitleScreenCode.GDPauseResumeButtonObjects1.length = 0;
gdjs.TitleScreenCode.GDPauseResumeButtonObjects2.length = 0;
gdjs.TitleScreenCode.GDPauseResumeButtonObjects3.length = 0;
gdjs.TitleScreenCode.GDPauseResumeButtonObjects4.length = 0;
gdjs.TitleScreenCode.GDPauseBackgroundObjects1.length = 0;
gdjs.TitleScreenCode.GDPauseBackgroundObjects2.length = 0;
gdjs.TitleScreenCode.GDPauseBackgroundObjects3.length = 0;
gdjs.TitleScreenCode.GDPauseBackgroundObjects4.length = 0;
gdjs.TitleScreenCode.GDGamePausedTextObjects1.length = 0;
gdjs.TitleScreenCode.GDGamePausedTextObjects2.length = 0;
gdjs.TitleScreenCode.GDGamePausedTextObjects3.length = 0;
gdjs.TitleScreenCode.GDGamePausedTextObjects4.length = 0;
gdjs.TitleScreenCode.GDHomeButtonObjects1.length = 0;
gdjs.TitleScreenCode.GDHomeButtonObjects2.length = 0;
gdjs.TitleScreenCode.GDHomeButtonObjects3.length = 0;
gdjs.TitleScreenCode.GDHomeButtonObjects4.length = 0;
gdjs.TitleScreenCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.TitleScreenCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.TitleScreenCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.TitleScreenCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.TitleScreenCode.GDObstacleObjects1.length = 0;
gdjs.TitleScreenCode.GDObstacleObjects2.length = 0;
gdjs.TitleScreenCode.GDObstacleObjects3.length = 0;
gdjs.TitleScreenCode.GDObstacleObjects4.length = 0;
gdjs.TitleScreenCode.GDTutorialTextObjects1.length = 0;
gdjs.TitleScreenCode.GDTutorialTextObjects2.length = 0;
gdjs.TitleScreenCode.GDTutorialTextObjects3.length = 0;
gdjs.TitleScreenCode.GDTutorialTextObjects4.length = 0;
gdjs.TitleScreenCode.GDRoadRightObjects1.length = 0;
gdjs.TitleScreenCode.GDRoadRightObjects2.length = 0;
gdjs.TitleScreenCode.GDRoadRightObjects3.length = 0;
gdjs.TitleScreenCode.GDRoadRightObjects4.length = 0;
gdjs.TitleScreenCode.GDRoadRight2Objects1.length = 0;
gdjs.TitleScreenCode.GDRoadRight2Objects2.length = 0;
gdjs.TitleScreenCode.GDRoadRight2Objects3.length = 0;
gdjs.TitleScreenCode.GDRoadRight2Objects4.length = 0;
gdjs.TitleScreenCode.GDRoadDownObjects1.length = 0;
gdjs.TitleScreenCode.GDRoadDownObjects2.length = 0;
gdjs.TitleScreenCode.GDRoadDownObjects3.length = 0;
gdjs.TitleScreenCode.GDRoadDownObjects4.length = 0;
gdjs.TitleScreenCode.GDRoadDown2Objects1.length = 0;
gdjs.TitleScreenCode.GDRoadDown2Objects2.length = 0;
gdjs.TitleScreenCode.GDRoadDown2Objects3.length = 0;
gdjs.TitleScreenCode.GDRoadDown2Objects4.length = 0;
gdjs.TitleScreenCode.GDRoadLeftObjects1.length = 0;
gdjs.TitleScreenCode.GDRoadLeftObjects2.length = 0;
gdjs.TitleScreenCode.GDRoadLeftObjects3.length = 0;
gdjs.TitleScreenCode.GDRoadLeftObjects4.length = 0;
gdjs.TitleScreenCode.GDRoadLeft2Objects1.length = 0;
gdjs.TitleScreenCode.GDRoadLeft2Objects2.length = 0;
gdjs.TitleScreenCode.GDRoadLeft2Objects3.length = 0;
gdjs.TitleScreenCode.GDRoadLeft2Objects4.length = 0;
gdjs.TitleScreenCode.GDRoadUpObjects1.length = 0;
gdjs.TitleScreenCode.GDRoadUpObjects2.length = 0;
gdjs.TitleScreenCode.GDRoadUpObjects3.length = 0;
gdjs.TitleScreenCode.GDRoadUpObjects4.length = 0;
gdjs.TitleScreenCode.GDRoadUp2Objects1.length = 0;
gdjs.TitleScreenCode.GDRoadUp2Objects2.length = 0;
gdjs.TitleScreenCode.GDRoadUp2Objects3.length = 0;
gdjs.TitleScreenCode.GDRoadUp2Objects4.length = 0;
gdjs.TitleScreenCode.GDCarObjects1.length = 0;
gdjs.TitleScreenCode.GDCarObjects2.length = 0;
gdjs.TitleScreenCode.GDCarObjects3.length = 0;
gdjs.TitleScreenCode.GDCarObjects4.length = 0;
gdjs.TitleScreenCode.GDButtonObjects1.length = 0;
gdjs.TitleScreenCode.GDButtonObjects2.length = 0;
gdjs.TitleScreenCode.GDButtonObjects3.length = 0;
gdjs.TitleScreenCode.GDButtonObjects4.length = 0;
gdjs.TitleScreenCode.GDTitleLogoObjects1.length = 0;
gdjs.TitleScreenCode.GDTitleLogoObjects2.length = 0;
gdjs.TitleScreenCode.GDTitleLogoObjects3.length = 0;
gdjs.TitleScreenCode.GDTitleLogoObjects4.length = 0;
gdjs.TitleScreenCode.GDGrassBGObjects1.length = 0;
gdjs.TitleScreenCode.GDGrassBGObjects2.length = 0;
gdjs.TitleScreenCode.GDGrassBGObjects3.length = 0;
gdjs.TitleScreenCode.GDGrassBGObjects4.length = 0;
gdjs.TitleScreenCode.GDWhiteBGObjects1.length = 0;
gdjs.TitleScreenCode.GDWhiteBGObjects2.length = 0;
gdjs.TitleScreenCode.GDWhiteBGObjects3.length = 0;
gdjs.TitleScreenCode.GDWhiteBGObjects4.length = 0;

gdjs.TitleScreenCode.eventsList6(runtimeScene);
return;

}

gdjs['TitleScreenCode'] = gdjs.TitleScreenCode;
